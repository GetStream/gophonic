// Copyright 2026 The gophonic authors
// SPDX-License-Identifier: BSD-2-Clause

//go:build goexperiment.simd && arm64

package whispergemm

import ("simd/archsimd";"math")

// Two rows share each broadcast across thirty-two columns. Compared with
// kernel4x16, this halves table lookups per output while retaining sixteen
// independent accumulators. Both packed panels retain their existing layout,
// and each output accumulates in increasing K order.
func kernel2x32(a0, a1, weights0, weights1, d0, d1 []float32) {
	k := len(a0)
	a1 = a1[:k:k]
	weights0 = weights0[: k*16 : k*16]
	weights1 = weights1[: k*16 : k*16]
	var c00, c01, c02, c03, c04, c05, c06, c07 archsimd.Float32x4
	var c10, c11, c12, c13, c14, c15, c16, c17 archsimd.Float32x4
	index0 := archsimd.LoadUint8x16Array(&[16]uint8{0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3})
	index1 := archsimd.LoadUint8x16Array(&[16]uint8{4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7})
	index2 := archsimd.LoadUint8x16Array(&[16]uint8{8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11})
	index3 := archsimd.LoadUint8x16Array(&[16]uint8{12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15})
	p := 0
	for ; p+4 <= k; p += 4 {
		v0 := archsimd.LoadFloat32x4Array((*[4]float32)(a0[p : p+4])).ToBits().ReshapeToUint8s()
		v1 := archsimd.LoadFloat32x4Array((*[4]float32)(a1[p : p+4])).ToBits().ReshapeToUint8s()
		wb0 := (*[64]float32)(weights0[p*16 : p*16+64])
		wb1 := (*[64]float32)(weights1[p*16 : p*16+64])
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[0:4]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[4:8]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[8:12]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[12:16]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[0:4]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[4:8]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[8:12]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[12:16]))
			x0 := v0.LookupOrZero(index0).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index0).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[16:20]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[20:24]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[24:28]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[28:32]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[16:20]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[20:24]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[24:28]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[28:32]))
			x0 := v0.LookupOrZero(index1).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index1).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[32:36]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[36:40]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[40:44]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[44:48]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[32:36]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[36:40]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[40:44]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[44:48]))
			x0 := v0.LookupOrZero(index2).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index2).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[48:52]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[52:56]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[56:60]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[60:64]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[48:52]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[52:56]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[56:60]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[60:64]))
			x0 := v0.LookupOrZero(index3).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index3).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
	}
	for ; p < k; p++ {
		wb0 := (*[16]float32)(weights0[p*16 : p*16+16])
		wb1 := (*[16]float32)(weights1[p*16 : p*16+16])
		w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[0:4]))
		w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[4:8]))
		w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[8:12]))
		w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[12:16]))
		w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[0:4]))
		w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[4:8]))
		w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[8:12]))
		w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[12:16]))
		x0 := archsimd.BroadcastFloat32x4(a0[p])
		c00 = w0.MulAdd(x0, c00)
		c01 = w1.MulAdd(x0, c01)
		c02 = w2.MulAdd(x0, c02)
		c03 = w3.MulAdd(x0, c03)
		c04 = w4.MulAdd(x0, c04)
		c05 = w5.MulAdd(x0, c05)
		c06 = w6.MulAdd(x0, c06)
		c07 = w7.MulAdd(x0, c07)
		x1 := archsimd.BroadcastFloat32x4(a1[p])
		c10 = w0.MulAdd(x1, c10)
		c11 = w1.MulAdd(x1, c11)
		c12 = w2.MulAdd(x1, c12)
		c13 = w3.MulAdd(x1, c13)
		c14 = w4.MulAdd(x1, c14)
		c15 = w5.MulAdd(x1, c15)
		c16 = w6.MulAdd(x1, c16)
		c17 = w7.MulAdd(x1, c17)
	}
	_ = d0[31]
	c00.StoreArray((*[4]float32)(d0[0:4]))
	c01.StoreArray((*[4]float32)(d0[4:8]))
	c02.StoreArray((*[4]float32)(d0[8:12]))
	c03.StoreArray((*[4]float32)(d0[12:16]))
	c04.StoreArray((*[4]float32)(d0[16:20]))
	c05.StoreArray((*[4]float32)(d0[20:24]))
	c06.StoreArray((*[4]float32)(d0[24:28]))
	c07.StoreArray((*[4]float32)(d0[28:32]))
	_ = d1[31]
	c10.StoreArray((*[4]float32)(d1[0:4]))
	c11.StoreArray((*[4]float32)(d1[4:8]))
	c12.StoreArray((*[4]float32)(d1[8:12]))
	c13.StoreArray((*[4]float32)(d1[12:16]))
	c14.StoreArray((*[4]float32)(d1[16:20]))
	c15.StoreArray((*[4]float32)(d1[20:24]))
	c16.StoreArray((*[4]float32)(d1[24:28]))
	c17.StoreArray((*[4]float32)(d1[28:32]))
}

func kernel3x32(a0, a1, a2, weights0, weights1, d0, d1, d2 []float32) {
 k:=len(a0)
a1=a1[:k:k]
a2=a2[:k:k]
weights0=weights0[:k*16:k*16]
weights1=weights1[:k*16:k*16]
var c0_0, c0_1, c0_2, c0_3, c0_4, c0_5, c0_6, c0_7 archsimd.Float32x4
var c1_0, c1_1, c1_2, c1_3, c1_4, c1_5, c1_6, c1_7 archsimd.Float32x4
var c2_0, c2_1, c2_2, c2_3, c2_4, c2_5, c2_6, c2_7 archsimd.Float32x4
for p:=0;p<k;p++ {
x0:=archsimd.BroadcastUint32x4(math.Float32bits(a0[p])).BitsToFloat32()
x1:=archsimd.BroadcastUint32x4(math.Float32bits(a1[p])).BitsToFloat32()
x2:=archsimd.BroadcastUint32x4(math.Float32bits(a2[p])).BitsToFloat32()
wb0:=(*[16]float32)(weights0[p*16:p*16+16])
wb1:=(*[16]float32)(weights1[p*16:p*16+16])
w0:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[0:4]))
c0_0=w0.MulAdd(x0,c0_0)
c1_0=w0.MulAdd(x1,c1_0)
c2_0=w0.MulAdd(x2,c2_0)
w1:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[4:8]))
c0_1=w1.MulAdd(x0,c0_1)
c1_1=w1.MulAdd(x1,c1_1)
c2_1=w1.MulAdd(x2,c2_1)
w2:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[8:12]))
c0_2=w2.MulAdd(x0,c0_2)
c1_2=w2.MulAdd(x1,c1_2)
c2_2=w2.MulAdd(x2,c2_2)
w3:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[12:16]))
c0_3=w3.MulAdd(x0,c0_3)
c1_3=w3.MulAdd(x1,c1_3)
c2_3=w3.MulAdd(x2,c2_3)
w4:=archsimd.LoadFloat32x4Array((*[4]float32)(wb1[0:4]))
c0_4=w4.MulAdd(x0,c0_4)
c1_4=w4.MulAdd(x1,c1_4)
c2_4=w4.MulAdd(x2,c2_4)
w5:=archsimd.LoadFloat32x4Array((*[4]float32)(wb1[4:8]))
c0_5=w5.MulAdd(x0,c0_5)
c1_5=w5.MulAdd(x1,c1_5)
c2_5=w5.MulAdd(x2,c2_5)
w6:=archsimd.LoadFloat32x4Array((*[4]float32)(wb1[8:12]))
c0_6=w6.MulAdd(x0,c0_6)
c1_6=w6.MulAdd(x1,c1_6)
c2_6=w6.MulAdd(x2,c2_6)
w7:=archsimd.LoadFloat32x4Array((*[4]float32)(wb1[12:16]))
c0_7=w7.MulAdd(x0,c0_7)
c1_7=w7.MulAdd(x1,c1_7)
c2_7=w7.MulAdd(x2,c2_7)
}
_ = d0[31]
c0_0.StoreArray((*[4]float32)(d0[0:4]))
c0_1.StoreArray((*[4]float32)(d0[4:8]))
c0_2.StoreArray((*[4]float32)(d0[8:12]))
c0_3.StoreArray((*[4]float32)(d0[12:16]))
c0_4.StoreArray((*[4]float32)(d0[16:20]))
c0_5.StoreArray((*[4]float32)(d0[20:24]))
c0_6.StoreArray((*[4]float32)(d0[24:28]))
c0_7.StoreArray((*[4]float32)(d0[28:32]))
_ = d1[31]
c1_0.StoreArray((*[4]float32)(d1[0:4]))
c1_1.StoreArray((*[4]float32)(d1[4:8]))
c1_2.StoreArray((*[4]float32)(d1[8:12]))
c1_3.StoreArray((*[4]float32)(d1[12:16]))
c1_4.StoreArray((*[4]float32)(d1[16:20]))
c1_5.StoreArray((*[4]float32)(d1[20:24]))
c1_6.StoreArray((*[4]float32)(d1[24:28]))
c1_7.StoreArray((*[4]float32)(d1[28:32]))
_ = d2[31]
c2_0.StoreArray((*[4]float32)(d2[0:4]))
c2_1.StoreArray((*[4]float32)(d2[4:8]))
c2_2.StoreArray((*[4]float32)(d2[8:12]))
c2_3.StoreArray((*[4]float32)(d2[12:16]))
c2_4.StoreArray((*[4]float32)(d2[16:20]))
c2_5.StoreArray((*[4]float32)(d2[20:24]))
c2_6.StoreArray((*[4]float32)(d2[24:28]))
c2_7.StoreArray((*[4]float32)(d2[28:32]))
}

func kernel6x16(a0, a1, a2, a3, a4, a5, weights0, d0, d1, d2, d3, d4, d5 []float32) {
 k:=len(a0)
a1=a1[:k:k]
a2=a2[:k:k]
a3=a3[:k:k]
a4=a4[:k:k]
a5=a5[:k:k]
weights0=weights0[:k*16:k*16]
var c0_0, c0_1, c0_2, c0_3 archsimd.Float32x4
var c1_0, c1_1, c1_2, c1_3 archsimd.Float32x4
var c2_0, c2_1, c2_2, c2_3 archsimd.Float32x4
var c3_0, c3_1, c3_2, c3_3 archsimd.Float32x4
var c4_0, c4_1, c4_2, c4_3 archsimd.Float32x4
var c5_0, c5_1, c5_2, c5_3 archsimd.Float32x4
for p:=0;p<k;p++ {
x0:=archsimd.BroadcastUint32x4(math.Float32bits(a0[p])).BitsToFloat32()
x1:=archsimd.BroadcastUint32x4(math.Float32bits(a1[p])).BitsToFloat32()
x2:=archsimd.BroadcastUint32x4(math.Float32bits(a2[p])).BitsToFloat32()
x3:=archsimd.BroadcastUint32x4(math.Float32bits(a3[p])).BitsToFloat32()
x4:=archsimd.BroadcastUint32x4(math.Float32bits(a4[p])).BitsToFloat32()
x5:=archsimd.BroadcastUint32x4(math.Float32bits(a5[p])).BitsToFloat32()
wb0:=(*[16]float32)(weights0[p*16:p*16+16])
w0:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[0:4]))
c0_0=w0.MulAdd(x0,c0_0)
c1_0=w0.MulAdd(x1,c1_0)
c2_0=w0.MulAdd(x2,c2_0)
c3_0=w0.MulAdd(x3,c3_0)
c4_0=w0.MulAdd(x4,c4_0)
c5_0=w0.MulAdd(x5,c5_0)
w1:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[4:8]))
c0_1=w1.MulAdd(x0,c0_1)
c1_1=w1.MulAdd(x1,c1_1)
c2_1=w1.MulAdd(x2,c2_1)
c3_1=w1.MulAdd(x3,c3_1)
c4_1=w1.MulAdd(x4,c4_1)
c5_1=w1.MulAdd(x5,c5_1)
w2:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[8:12]))
c0_2=w2.MulAdd(x0,c0_2)
c1_2=w2.MulAdd(x1,c1_2)
c2_2=w2.MulAdd(x2,c2_2)
c3_2=w2.MulAdd(x3,c3_2)
c4_2=w2.MulAdd(x4,c4_2)
c5_2=w2.MulAdd(x5,c5_2)
w3:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[12:16]))
c0_3=w3.MulAdd(x0,c0_3)
c1_3=w3.MulAdd(x1,c1_3)
c2_3=w3.MulAdd(x2,c2_3)
c3_3=w3.MulAdd(x3,c3_3)
c4_3=w3.MulAdd(x4,c4_3)
c5_3=w3.MulAdd(x5,c5_3)
}
_ = d0[15]
c0_0.StoreArray((*[4]float32)(d0[0:4]))
c0_1.StoreArray((*[4]float32)(d0[4:8]))
c0_2.StoreArray((*[4]float32)(d0[8:12]))
c0_3.StoreArray((*[4]float32)(d0[12:16]))
_ = d1[15]
c1_0.StoreArray((*[4]float32)(d1[0:4]))
c1_1.StoreArray((*[4]float32)(d1[4:8]))
c1_2.StoreArray((*[4]float32)(d1[8:12]))
c1_3.StoreArray((*[4]float32)(d1[12:16]))
_ = d2[15]
c2_0.StoreArray((*[4]float32)(d2[0:4]))
c2_1.StoreArray((*[4]float32)(d2[4:8]))
c2_2.StoreArray((*[4]float32)(d2[8:12]))
c2_3.StoreArray((*[4]float32)(d2[12:16]))
_ = d3[15]
c3_0.StoreArray((*[4]float32)(d3[0:4]))
c3_1.StoreArray((*[4]float32)(d3[4:8]))
c3_2.StoreArray((*[4]float32)(d3[8:12]))
c3_3.StoreArray((*[4]float32)(d3[12:16]))
_ = d4[15]
c4_0.StoreArray((*[4]float32)(d4[0:4]))
c4_1.StoreArray((*[4]float32)(d4[4:8]))
c4_2.StoreArray((*[4]float32)(d4[8:12]))
c4_3.StoreArray((*[4]float32)(d4[12:16]))
_ = d5[15]
c5_0.StoreArray((*[4]float32)(d5[0:4]))
c5_1.StoreArray((*[4]float32)(d5[4:8]))
c5_2.StoreArray((*[4]float32)(d5[8:12]))
c5_3.StoreArray((*[4]float32)(d5[12:16]))
}

func kernel5x16(a0, a1, a2, a3, a4, weights0, d0, d1, d2, d3, d4 []float32) {
 k:=len(a0)
a1=a1[:k:k]
a2=a2[:k:k]
a3=a3[:k:k]
a4=a4[:k:k]
weights0=weights0[:k*16:k*16]
var c0_0, c0_1, c0_2, c0_3 archsimd.Float32x4
var c1_0, c1_1, c1_2, c1_3 archsimd.Float32x4
var c2_0, c2_1, c2_2, c2_3 archsimd.Float32x4
var c3_0, c3_1, c3_2, c3_3 archsimd.Float32x4
var c4_0, c4_1, c4_2, c4_3 archsimd.Float32x4
for p:=0;p<k;p++ {
x0:=archsimd.BroadcastUint32x4(math.Float32bits(a0[p])).BitsToFloat32()
x1:=archsimd.BroadcastUint32x4(math.Float32bits(a1[p])).BitsToFloat32()
x2:=archsimd.BroadcastUint32x4(math.Float32bits(a2[p])).BitsToFloat32()
x3:=archsimd.BroadcastUint32x4(math.Float32bits(a3[p])).BitsToFloat32()
x4:=archsimd.BroadcastUint32x4(math.Float32bits(a4[p])).BitsToFloat32()
wb0:=(*[16]float32)(weights0[p*16:p*16+16])
w0:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[0:4]))
c0_0=w0.MulAdd(x0,c0_0)
c1_0=w0.MulAdd(x1,c1_0)
c2_0=w0.MulAdd(x2,c2_0)
c3_0=w0.MulAdd(x3,c3_0)
c4_0=w0.MulAdd(x4,c4_0)
w1:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[4:8]))
c0_1=w1.MulAdd(x0,c0_1)
c1_1=w1.MulAdd(x1,c1_1)
c2_1=w1.MulAdd(x2,c2_1)
c3_1=w1.MulAdd(x3,c3_1)
c4_1=w1.MulAdd(x4,c4_1)
w2:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[8:12]))
c0_2=w2.MulAdd(x0,c0_2)
c1_2=w2.MulAdd(x1,c1_2)
c2_2=w2.MulAdd(x2,c2_2)
c3_2=w2.MulAdd(x3,c3_2)
c4_2=w2.MulAdd(x4,c4_2)
w3:=archsimd.LoadFloat32x4Array((*[4]float32)(wb0[12:16]))
c0_3=w3.MulAdd(x0,c0_3)
c1_3=w3.MulAdd(x1,c1_3)
c2_3=w3.MulAdd(x2,c2_3)
c3_3=w3.MulAdd(x3,c3_3)
c4_3=w3.MulAdd(x4,c4_3)
}
_ = d0[15]
c0_0.StoreArray((*[4]float32)(d0[0:4]))
c0_1.StoreArray((*[4]float32)(d0[4:8]))
c0_2.StoreArray((*[4]float32)(d0[8:12]))
c0_3.StoreArray((*[4]float32)(d0[12:16]))
_ = d1[15]
c1_0.StoreArray((*[4]float32)(d1[0:4]))
c1_1.StoreArray((*[4]float32)(d1[4:8]))
c1_2.StoreArray((*[4]float32)(d1[8:12]))
c1_3.StoreArray((*[4]float32)(d1[12:16]))
_ = d2[15]
c2_0.StoreArray((*[4]float32)(d2[0:4]))
c2_1.StoreArray((*[4]float32)(d2[4:8]))
c2_2.StoreArray((*[4]float32)(d2[8:12]))
c2_3.StoreArray((*[4]float32)(d2[12:16]))
_ = d3[15]
c3_0.StoreArray((*[4]float32)(d3[0:4]))
c3_1.StoreArray((*[4]float32)(d3[4:8]))
c3_2.StoreArray((*[4]float32)(d3[8:12]))
c3_3.StoreArray((*[4]float32)(d3[12:16]))
_ = d4[15]
c4_0.StoreArray((*[4]float32)(d4[0:4]))
c4_1.StoreArray((*[4]float32)(d4[4:8]))
c4_2.StoreArray((*[4]float32)(d4[8:12]))
c4_3.StoreArray((*[4]float32)(d4[12:16]))
}
