from pathlib import Path
import json
r=Path('/Users/thesyncim/Documents/ChatGPT/goinfer');d=Path('/private/tmp/gophonic-fast-kernels')
s=(r/'internal/whispergemm/executor.go').read_text().replace('type Executor struct {','type Executor struct {\n strassen *strassenWorkspace')
s=s.replace('if parts == 1 {\n\t\tb.mul(dst, dstStride, a, aStride, m)','if parts == 1 {\n if strassenExperimentMode!=0 && len(e.workers)==0 && m>=128 && b.k>=128 && b.n>=128 && b.k%2==0 && b.n%32==0 {\n if e.strassen==nil {e.strassen=newStrassenWorkspace()}\n e.strassen.mul(b,dst,dstStride,a,aStride,m)\n return nil\n }\n\t\tb.mul(dst, dstStride, a, aStride, m)',1)
(d/'strassen-executor.go').write_text(s)
repl={str(r/'internal/whispergemm/executor.go'):str(d/'strassen-executor.go'),str(r/'internal/whispergemm/strassen_experiment.go'):str(d/'strassen.go')}
(d/'strassen-overlay.json').write_text(json.dumps({'Replace':repl},indent=2))
