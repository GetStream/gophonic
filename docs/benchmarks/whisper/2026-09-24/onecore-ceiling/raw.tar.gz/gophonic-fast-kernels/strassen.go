package whispergemm

// Experimental single-level Strassen. Only dense constant-weight projections
// use it; dynamic attention matrices and row-vector products keep the base path.
type strassenWeights struct { blocks [7]*PackedB }
type strassenWorkspace struct {
 weights map[*PackedB]*strassenWeights
 input, second, product [3][]float32
}
var strassenExperimentMode int
func SetStrassenExperimentMode(mode int) { strassenExperimentMode=mode }
func newStrassenWorkspace() *strassenWorkspace {
 s:= &strassenWorkspace{weights:make(map[*PackedB]*strassenWeights)}
 for level:=0;level<3;level++ {size:=(1500*768)>>(2*level);s.input[level]=make([]float32,size);s.second[level]=make([]float32,size);s.product[level]=make([]float32,size)}
 return s
}
func (s *strassenWorkspace) prepare(b *PackedB) *strassenWeights {
 if w:=s.weights[b];w!=nil{return w}
 k,n:=b.k/2,b.n/2
 w:=new(strassenWeights)
 temp:=make([]float32,k*n)
 for block:=0;block<7;block++ {
  for r:=0;r<k;r++ {for c:=0;c<n;c++ {
   b11:=b.data[c/16*b.k*16+r*16+c%16]
   b12:=b.data[(c+n)/16*b.k*16+r*16+(c+n)%16]
   b21:=b.data[c/16*b.k*16+(r+k)*16+c%16]
   b22:=b.data[(c+n)/16*b.k*16+(r+k)*16+(c+n)%16]
   var v float32
   t1:=b12-b11;t2:=b22-t1
   switch block {case 0:v=b11;case 1:v=b21;case 2:v=t2;case 3:v=t1;case 4:v=b22-b12;case 5:v=b22;case 6:v=t2-b21}
   temp[r*n+c]=v
  }}
  w.blocks[block],_=NewPackedB(k,n)
  if err:=w.blocks[block].Pack(temp,n,false);err!=nil{panic(err)}
 }
 s.weights[b]=w
 return w
}
func (s *strassenWorkspace) mul(b *PackedB,dst []float32,ds int,a []float32,as,m int) {depth:=strassenExperimentMode;if depth==4 {depth=2;if b.k<=384 && b.n<=384{depth=1}};s.mulLevel(b,dst,ds,a,as,m,0,depth)}
func (s *strassenWorkspace) mulLevel(b *PackedB,dst []float32,ds int,a []float32,as,m,level,depth int) {
 mh:=m/8*4
 kh,nh:=b.k/2,b.n/2
 weights:=s.prepare(b)
 input:=s.input[level][:mh*kh]
 second:=s.second[level][:mh*kh]
 prod:=s.product[level][:mh*nh]
 for block:=0;block<7;block++ {
  source,sourceStride:=input,kh
  switch block {
  case 0:source,sourceStride=a,as
  case 1:source,sourceStride=a[kh:],as
  case 2:
   for r:=0;r<mh;r++ {a11:=a[r*as:r*as+kh];a21,a22:=a[(r+mh)*as:(r+mh)*as+kh],a[(r+mh)*as+kh:(r+mh)*as+b.k];lo,hi:=r*kh,(r+1)*kh;strassenSumDifference(second[lo:hi],input[lo:hi],a21,a22,a11)}
  case 3:source=second
  case 4:
   for r:=0;r<mh;r++ {strassenSub(second[r*kh:(r+1)*kh],a[r*as:r*as+kh],a[(r+mh)*as:(r+mh)*as+kh])};source=second
  case 5:
   for r:=0;r<mh;r++ {row:=input[r*kh:(r+1)*kh];strassenSub(row,a[r*as+kh:r*as+b.k],row)}
  case 6:source,sourceStride=a[mh*as+kh:],as
  }
  if level+1 < depth && mh>=64 && kh>=64 && nh>=64 && kh%2==0 && nh%32==0 {s.mulLevel(weights.blocks[block],prod,nh,source,sourceStride,mh,level+1,depth)} else {weights.blocks[block].mul(prod,nh,source,sourceStride,mh)}
  for r:=0;r<mh;r++ {
   c11,c12:=dst[r*ds:r*ds+nh],dst[r*ds+nh:r*ds+b.n]
   c21,c22:=dst[(r+mh)*ds:(r+mh)*ds+nh],dst[(r+mh)*ds+nh:(r+mh)*ds+b.n]
   row:=prod[r*nh:(r+1)*nh]
   switch block {
   case 0:copy(c11,row);copy(c12,row)
   case 1:strassenAdd(c11,c11,row)
   case 2:strassenAdd(c12,c12,row);copy(c21,c12)
   case 3:strassenAdd(c12,c12,row);copy(c22,row)
   case 4:strassenAdd(c21,c21,row);strassenAdd(c22,c22,c21)
   case 5:strassenAdd(c12,c12,row)
   case 6:strassenSub(c21,c21,row)
   }
  }
 }
 if tail:=m-2*mh;tail>0 {b.mul(dst[2*mh*ds:],ds,a[2*mh*as:],as,tail)}
}
