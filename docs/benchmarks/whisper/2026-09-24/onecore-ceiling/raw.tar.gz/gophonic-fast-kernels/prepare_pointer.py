from pathlib import Path
import json,re
r=Path('/Users/thesyncim/Documents/ChatGPT/goinfer');d=Path('/private/tmp/gophonic-fast-kernels')
original=(r/'internal/whispergemm/kernel_wide_arm64.go').read_text()
head=original[:original.index('func kernel2x32(')].replace('import "simd/archsimd"','import ("simd/archsimd";"unsafe")')
body=original[original.index('func kernel2x32('):]
arrays=[]
for n in range(4):arrays.append('var broadIndex'+str(n)+' = [16]uint8{'+','.join(str(x) for x in list(range(n*4,n*4+4))*4)+'}\n')
s=head+'\n'+''.join(arrays)
for mode in range(4):
 b=body.replace('kernel2x32(','kernel2x32Mode'+str(mode)+'(',1)
 if mode in [1,3]:
  for i in range(4):b=re.sub(rf'archsimd.LoadUint8x16Array\(&\[16\]uint8\{{[^}}]+\}}\)',lambda m: f'archsimd.LoadUint8x16Array(&broadIndex{i})',b,count=1) if False else b
  pat=r'index(\d) := archsimd.LoadUint8x16Array\(&\[16\]uint8\{[^}]+\}\)'
  b=re.sub(pat,lambda m:f'index{m[1]} := archsimd.LoadUint8x16Array(&broadIndex{m[1]})',b)
 if mode in [2,3]:
  for row in range(2):b=b.replace(f'(*[4]float32)(a{row}[p : p+4])',f'(*[4]float32)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(a{row})),p*4))')
  for col in range(2):
   b=b.replace(f'(*[64]float32)(weights{col}[p*16 : p*16+64])',f'(*[64]float32)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(weights{col})),p*64))')
   b=b.replace(f'(*[16]float32)(weights{col}[p*16 : p*16+16])',f'(*[16]float32)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(weights{col})),p*64))')
 s+=b
(d/'pointer-wide.go').write_text(s)
s=(r/'internal/whispergemm/kernel_arm64.go').read_text();start=s.index('func mulPacked(');end=s.index('// Four reduction values',start);dispatch=s[start:end]
s=s[:start]+s[end:]
for mode in range(4):s+=dispatch.replace('func mulPacked(','func mulPackedMode'+str(mode)+'(',1).replace('kernel2x32(','kernel2x32Mode'+str(mode)+'(')
s+='''
var pointerExperiment int
func SetPointerExperiment(mode int) {pointerExperiment=mode}
func mulPacked(dst []float32,ds int,a []float32,as int,packed []float32,m,k,n int) {
 switch pointerExperiment {
 case 0:mulPackedMode0(dst,ds,a,as,packed,m,k,n)
 case 1:mulPackedMode1(dst,ds,a,as,packed,m,k,n)
 case 2:mulPackedMode2(dst,ds,a,as,packed,m,k,n)
 case 3:mulPackedMode3(dst,ds,a,as,packed,m,k,n)
 }
}
'''
(d/'pointer-kernel.go').write_text(s)
s=(d/'experiment_test.go').read_text().replace('TestFastKernelShapes','TestPointerShapes').replace('TestFastKernelExact','TestPointerExact').replace('kernelExperimentMode','pointerExperiment').replace('shapes.json','pointer-shapes.json')
s=s.replace('cycle<16','cycle<20')
s=s.replace('{"fast_qk",32,64,608,40},{"fast_pv",32,608,64,40},{"fast_projection",608,384,384,2},{"fast_expand",608,384,1536,1},{"fast_contract",608,1536,384,1},{"fast_conv2",608,1152,384,1},','{"full_qk",32,64,1500,8},{"full_pv",32,1500,64,8},{"full_conv2",1500,1152,384,1},')
(d/'pointer_test.go').write_text(s)
repl={str(r/'internal/whispergemm/kernel_arm64.go'):str(d/'pointer-kernel.go'),str(r/'internal/whispergemm/kernel_wide_arm64.go'):str(d/'pointer-wide.go'),str(r/'internal/whispergemm/pointer_experiment_test.go'):str(d/'pointer_test.go')}
(d/'pointer-overlay.json').write_text(json.dumps({'Replace':repl},indent=2))
