package whispergemm
import("testing";"math";"runtime";"time";"os";"encoding/json")
func TestStrassenNumerical(t *testing.T) {
 e,_:=NewExecutor(1);defer e.Close()
 for _,s:=range [][3]int{{128,128,128},{608,384,384},{608,384,1536},{608,1536,384},{1216,240,384},{608,1152,384},{1500,384,384},{1499,384,384}} {
  m,k,n:=s[0],s[1],s[2];a,_,got,b:=benchmarkData(t,m,k,n);want:=make([]float32,len(got));strassenExperimentMode=0;e.Mul(b,want,n,a,k,m);strassenExperimentMode=1;e.Mul(b,got,n,a,k,m)
  maxErr,maxRel:=0.,0.;for i:=range got {err:=math.Abs(float64(got[i]-want[i]));maxErr=max(maxErr,err);if math.Abs(float64(want[i]))>1{maxRel=max(maxRel,err/math.Abs(float64(want[i])))}}
  if maxErr>2e-3||maxRel>2e-4 {t.Fatalf("shape %v err=%g rel=%g",s,maxErr,maxRel)}
  t.Logf("shape %v maxAbs=%g maxRel(|ref|>1)=%g",s,maxErr,maxRel)
  if allocs:=testing.AllocsPerRun(2,func(){e.Mul(b,got,n,a,k,m)});allocs!=0{t.Fatalf("allocs %g",allocs)}
 }
}
func TestStrassenPairedShapes(t *testing.T) {
 runtime.GOMAXPROCS(1);e,_:=NewExecutor(1);defer e.Close()
 type sample struct{Shape string;Mode int;Nanoseconds int64};var samples []sample
 for _,s:=range []struct{Name string;M,K,N int}{{"fast_projection",608,384,384},{"fast_expand",608,384,1536},{"fast_contract",608,1536,384},{"fast_conv1",1216,240,384},{"fast_conv2",608,1152,384},{"full_projection",1500,384,384},{"full_expand",1500,384,1536},{"full_contract",1500,1536,384}} {
  a,_,dst,b:=benchmarkData(t,s.M,s.K,s.N)
  for cycle:=0;cycle<24;cycle++ {for j:=0;j<4;j++ {
   mode:=(cycle+j)%4;strassenExperimentMode=mode;e.Mul(b,dst,s.N,a,s.K,s.M)
   start:=time.Now();e.Mul(b,dst,s.N,a,s.K,s.M);samples=append(samples,sample{s.Name,mode,time.Since(start).Nanoseconds()})
  }}
  benchmarkSink=dst[len(dst)-1]
 }
 data,err:=json.Marshal(samples);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/strassen-shapes.json",data,0644);err!=nil{t.Fatal(err)}
}
