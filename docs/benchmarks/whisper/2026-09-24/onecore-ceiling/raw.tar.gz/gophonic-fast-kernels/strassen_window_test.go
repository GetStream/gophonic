package whisper
import("testing";"time";"runtime";"encoding/json";"os";"slices";"github.com/GetStream/gophonic/internal/whispergemm")
func TestStrassenFastWindowPaired(t *testing.T) {
 runtime.GOMAXPROCS(1)
 model,pcm:=loadStrassenJFK(t)
 w,err:=NewTranscriberWithWorkers(model,1);if err!=nil{t.Fatal(err)};defer w.Close()
 dst:=make([]byte,0,2048)
 type sample struct{Mode int;Nanoseconds int64}
 var samples []sample
 var expected []int
 var expectedText string
 for _,mode:=range []int{0,4} {
  whispergemm.SetStrassenExperimentMode(mode)
  for i:=0;i<5;i++ {text,err:=w.TranscribeWindowInto(pcm,dst);if err!=nil{t.Fatal(err)};if expected==nil{expected=slices.Clone(w.tokens);expectedText=string(text)};if !slices.Equal(w.tokens,expected)||string(text)!=expectedText{t.Fatalf("mode %d token mismatch\nwant %v\ngot %v\nwant %q\ngot %q",mode,expected,w.tokens,expectedText,text)}}
  alloc:=testing.AllocsPerRun(2,func(){if _,err:=w.TranscribeWindowInto(pcm,dst);err!=nil{panic(err)}});if alloc!=0{t.Fatalf("mode %d allocations %g",mode,alloc)}
 }
 for cycle:=0;cycle<24;cycle++ {for j:=0;j<2;j++ {
  mode:=[]int{0,4}[(cycle+j)%2];whispergemm.SetStrassenExperimentMode(mode)
  start:=time.Now();text,err:=w.TranscribeWindowInto(pcm,dst);elapsed:=time.Since(start).Nanoseconds()
  if err!=nil{t.Fatal(err)};if !slices.Equal(w.tokens,expected)||string(text)!=expectedText{t.Fatalf("mode %d tokens changed",mode)}
  samples=append(samples,sample{mode,elapsed})
 }}
 report:=struct{Text string;Tokens []int;Samples []sample}{expectedText,expected,samples};data,err:=json.Marshal(report);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/strassen-full-window.json",data,0644);err!=nil{t.Fatal(err)}
}

func loadStrassenJFK(t *testing.T) (*Model,[]float32) {
 t.Helper();m,err:=Load(os.Getenv("GOPHONIC_WHISPER_MODEL"));if err!=nil{t.Fatal(err)}
 path:="../testdata/whisper_jfk.pcm.f32le";info,err:=os.Stat(path);if err!=nil{t.Fatal(err)}
 pcm,err:=readFloatFixture(path,int(info.Size()/4));if err!=nil{t.Fatal(err)};return m,pcm
}
