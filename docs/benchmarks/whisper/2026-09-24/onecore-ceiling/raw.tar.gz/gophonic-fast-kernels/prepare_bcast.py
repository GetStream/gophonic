from pathlib import Path
import json
r=Path('/Users/thesyncim/Documents/ChatGPT/goinfer');d=Path('/private/tmp/gophonic-fast-kernels')
s=(r/'internal/whispergemm/kernel_wide_arm64.go').read_text()
s+='\nfunc kernel5x16Broadcast('+','.join([f'a{i}' for i in range(5)]+['weights']+[f'd{i}' for i in range(5)])+' []float32, accumulate bool) {\n k:=len(a0)\n'
for row in range(1,5):s+=f'a{row}=a{row}[:k:k]\n'
s+='weights=weights[:k*4:k*4]\n'
for row in range(5):s+='var '+','.join(f'c{row}{col}' for col in range(4))+' archsimd.Float32x4\n'
s+='if accumulate {\n'
for row in range(5):
 s+=f'_ = d{row}[15]\n'
 for col in range(4):s+=f'c{row}{col}=archsimd.LoadFloat32x4Array((*[4]float32)(d{row}[{col*4}:{col*4+4}]))\n'
s+='}\nfor p:=0;p<k;p+=4 {\n'
for row in range(5):s+=f'x{row}:=archsimd.LoadFloat32x4Array((*[4]float32)(a{row}[p:p+4]))\n'
s+='wb:=(*[16]float32)(weights[p*4:p*4+16])\n'
for col in range(4):
 s+=f'w{col}:=archsimd.LoadFloat32x4Array((*[4]float32)(wb[{col*4}:{col*4+4}]))\n'
 for row in range(5):s+=f'c{row}{col}=w{col}.MulAdd(x{row},c{row}{col})\n'
s+='}\n'
for row in range(5):
 s+=f'_ = d{row}[15]\n'
 for col in range(4):s+=f'c{row}{col}.StoreArray((*[4]float32)(d{row}[{col*4}:{col*4+4}]))\n'
s+='}\n'
(d/'bcast-wide.go').write_text(s)
s=(r/'internal/whispergemm/kernel_arm64.go').read_text().replace('func mulPacked(', 'func mulPackedBaseline(',1)
s+='''
var broadcastExperiment int
func SetBroadcastExperiment(mode int) {broadcastExperiment=mode}
func mulPacked(dst []float32,ds int,a []float32,as int,packed []float32,m,k,n int) {
 if broadcastExperiment==0 || m<20 || n<16 {mulPackedBaseline(dst,ds,a,as,packed,m,k,n);return}
 mulPackedBroadcast(dst,ds,a,as,packed,m,k,n)
}
func mulPackedBroadcast(dst []float32,ds int,a []float32,as int,packed []float32,m,k,n int) {
 var scratch [20*256*4]float32
 block:=256;if broadcastExperiment==2{block=128}
 rows:=m/20*20;cols:=n/16*16
 for firstRow:=0;firstRow<rows;firstRow+=20 {
  for first:=0;first<k;first+=block {
   end:=min(first+block,k);kc:=end-first;stride:=kc*4
   for row:=0;row<20;row++ {
    src:=a[(firstRow+row)*as+first:(firstRow+row)*as+end]
    dst:=scratch[row*stride:(row+1)*stride]
    for p,x:=range src {z:=dst[p*4:p*4+4];z[0],z[1],z[2],z[3]=x,x,x,x}
   }
   for c:=0;c<cols;c+=16 {
    w:=packed[c*k+first*16:c*k+end*16]
    for r:=0;r<20;r+=5 {
     row:=firstRow+r
     kernel5x16Broadcast(scratch[r*stride:(r+1)*stride],scratch[(r+1)*stride:(r+2)*stride],scratch[(r+2)*stride:(r+3)*stride],scratch[(r+3)*stride:(r+4)*stride],scratch[(r+4)*stride:(r+5)*stride],w,
      dst[row*ds+c:row*ds+c+16],dst[(row+1)*ds+c:(row+1)*ds+c+16],dst[(row+2)*ds+c:(row+2)*ds+c+16],dst[(row+3)*ds+c:(row+3)*ds+c+16],dst[(row+4)*ds+c:(row+4)*ds+c+16],first!=0)
    }
   }
  }
 }
 if cols<n {mulPackedBaseline(dst[cols:],ds,a,as,packed[cols*k:],rows,k,n-cols)}
 if rows<m {mulPackedBaseline(dst[rows*ds:],ds,a[rows*as:],as,packed,m-rows,k,n)}
}
'''
(d/'bcast-kernel.go').write_text(s)
s=(d/'experiment_test.go').read_text().replace('TestFastKernelShapes','TestBroadcastShapes').replace('TestFastKernelExact','TestBroadcastExact').replace('kernelExperimentMode','broadcastExperiment').replace('shapes.json','broadcast-shapes.json')
s=s.replace('cycle<16','cycle<18').replace('j<4','j<3').replace('(j+cycle)%4','(j+cycle)%3').replace('[]int{1,2,3}','[]int{1,2}')
s=s.replace('{"fast_qk",32,64,608,40},{"fast_pv",32,608,64,40},{"fast_projection",608,384,384,2},{"fast_expand",608,384,1536,1},{"fast_contract",608,1536,384,1},{"fast_conv2",608,1152,384,1},','{"full_qk",32,64,1500,8},{"full_pv",32,1500,64,8},{"full_conv2",1500,1152,384,1},')
(d/'bcast_test.go').write_text(s)
repl={str(r/'internal/whispergemm/kernel_arm64.go'):str(d/'bcast-kernel.go'),str(r/'internal/whispergemm/kernel_wide_arm64.go'):str(d/'bcast-wide.go'),str(r/'internal/whispergemm/bcast_experiment_test.go'):str(d/'bcast_test.go')}
(d/'bcast-overlay.json').write_text(json.dumps({'Replace':repl},indent=2))
