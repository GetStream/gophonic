//go:build goexperiment.simd && arm64
package whispergemm
import("simd/archsimd";"time";"os";"encoding/json";"testing";"runtime")
func peakFMA(dst,a []float32,iterations int) {
c0:=archsimd.LoadFloat32x4Array((*[4]float32)(a[0:4]))
c1:=archsimd.LoadFloat32x4Array((*[4]float32)(a[4:8]))
c2:=archsimd.LoadFloat32x4Array((*[4]float32)(a[8:12]))
c3:=archsimd.LoadFloat32x4Array((*[4]float32)(a[12:16]))
c4:=archsimd.LoadFloat32x4Array((*[4]float32)(a[16:20]))
c5:=archsimd.LoadFloat32x4Array((*[4]float32)(a[20:24]))
c6:=archsimd.LoadFloat32x4Array((*[4]float32)(a[24:28]))
c7:=archsimd.LoadFloat32x4Array((*[4]float32)(a[28:32]))
c8:=archsimd.LoadFloat32x4Array((*[4]float32)(a[32:36]))
c9:=archsimd.LoadFloat32x4Array((*[4]float32)(a[36:40]))
c10:=archsimd.LoadFloat32x4Array((*[4]float32)(a[40:44]))
c11:=archsimd.LoadFloat32x4Array((*[4]float32)(a[44:48]))
c12:=archsimd.LoadFloat32x4Array((*[4]float32)(a[48:52]))
c13:=archsimd.LoadFloat32x4Array((*[4]float32)(a[52:56]))
c14:=archsimd.LoadFloat32x4Array((*[4]float32)(a[56:60]))
c15:=archsimd.LoadFloat32x4Array((*[4]float32)(a[60:64]))
x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[64:68]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(a[68:72]))
 for i:=0;i<iterations;i++ {
c0=x.MulAdd(y,c0)
c1=x.MulAdd(y,c1)
c2=x.MulAdd(y,c2)
c3=x.MulAdd(y,c3)
c4=x.MulAdd(y,c4)
c5=x.MulAdd(y,c5)
c6=x.MulAdd(y,c6)
c7=x.MulAdd(y,c7)
c8=x.MulAdd(y,c8)
c9=x.MulAdd(y,c9)
c10=x.MulAdd(y,c10)
c11=x.MulAdd(y,c11)
c12=x.MulAdd(y,c12)
c13=x.MulAdd(y,c13)
c14=x.MulAdd(y,c14)
c15=x.MulAdd(y,c15)
}
c0.StoreArray((*[4]float32)(dst[0:4]))
c1.StoreArray((*[4]float32)(dst[4:8]))
c2.StoreArray((*[4]float32)(dst[8:12]))
c3.StoreArray((*[4]float32)(dst[12:16]))
c4.StoreArray((*[4]float32)(dst[16:20]))
c5.StoreArray((*[4]float32)(dst[20:24]))
c6.StoreArray((*[4]float32)(dst[24:28]))
c7.StoreArray((*[4]float32)(dst[28:32]))
c8.StoreArray((*[4]float32)(dst[32:36]))
c9.StoreArray((*[4]float32)(dst[36:40]))
c10.StoreArray((*[4]float32)(dst[40:44]))
c11.StoreArray((*[4]float32)(dst[44:48]))
c12.StoreArray((*[4]float32)(dst[48:52]))
c13.StoreArray((*[4]float32)(dst[52:56]))
c14.StoreArray((*[4]float32)(dst[56:60]))
c15.StoreArray((*[4]float32)(dst[60:64]))
}

func TestPeakFMA(t *testing.T) {
 runtime.GOMAXPROCS(1);a:=make([]float32,72);dst:=make([]float32,64);seed:=uint32(0xc001cafe);for i:=range a{a[i]=nextValue(&seed)}
 const iterations=5000000
 var ns []int64
 for i:=-5;i<40;i++{start:=time.Now();peakFMA(dst,a,iterations);duration:=time.Since(start).Nanoseconds();if i>=0{ns=append(ns,duration)}}
 report:=struct{Iterations int;FLOPs int;Nanoseconds []int64;Result []float32}{iterations,iterations*16*4*2,ns,dst}
 data,err:=json.Marshal(report);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/peak.json",data,0644);err!=nil{t.Fatal(err)}
}
