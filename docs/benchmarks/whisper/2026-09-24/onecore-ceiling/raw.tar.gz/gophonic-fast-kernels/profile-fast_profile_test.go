package whisper
import("testing";"time";"runtime";"runtime/pprof";"os";"slices";"encoding/json")
var fastProfileStages [17]time.Duration
func TestFastStageProfile(t *testing.T) {
 runtime.GOMAXPROCS(1);m,pcm:=loadFastContextJFK(t);w,err:=NewTranscriberWithWorkers(m,1);if err!=nil{t.Fatal(err)};defer w.Close()
 dst:=make([]byte,0,2048);var tokens []int;var transcript string
 type sample struct{Total time.Duration;Stages [17]time.Duration};var samples []sample
 for i:=-5;i<16;i++ {
  if i==0 {f,err:=os.Create("/private/tmp/gophonic-fast-kernels/cpu.pprof");if err!=nil{t.Fatal(err)};defer f.Close();if err:=pprof.StartCPUProfile(f);err!=nil{t.Fatal(err)}}
  fastProfileStages=[17]time.Duration{};start:=time.Now();text,err:=w.TranscribeWindowFastInto(pcm,dst);elapsed:=time.Since(start)
  if err!=nil{t.Fatal(err)};if tokens==nil{tokens=slices.Clone(w.tokens);transcript=string(text)};if !slices.Equal(tokens,w.tokens)||string(text)!=transcript{t.Fatal("tokens changed")};if i>=0{samples=append(samples,sample{elapsed,fastProfileStages})}
 }
 pprof.StopCPUProfile()
 report:=struct{Names []string;Samples []sample;Text string;Tokens []int}{[]string{"frontend","encoder","cross_kv","tokens","encoder_stem","encoder_attn_norm","encoder_qkv","encoder_attention","encoder_out","encoder_mlp_norm","encoder_mlp_expand","encoder_mlp_gelu","encoder_mlp_contract","attention_pack","attention_qk","attention_softmax","attention_pv"},samples,transcript,tokens}
 data,err:=json.Marshal(report);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/profile.json",data,0644);err!=nil{t.Fatal(err)}
}
