TEXT github.com/GetStream/gophonic/internal/whispergemm.peak2x8(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/peak_experiment_test.go
  peak_experiment_test.go:4	0x10017c4e0		f9400b90		MOVD 16(R28), R16							
  peak_experiment_test.go:4	0x10017c4e4		eb3063ff		CMP R16, RSP								
  peak_experiment_test.go:4	0x10017c4e8		54001c49		BLS 226(PC)								
  peak_experiment_test.go:4	0x10017c4ec		f81f0ffe		MOVD.W R30, -16(RSP)							
  peak_experiment_test.go:4	0x10017c4f0		f81f83fd		MOVD R29, -8(RSP)							
  peak_experiment_test.go:4	0x10017c4f4		d10023fd		SUB $8, RSP, R29							
  peak_experiment_test.go:4	0x10017c4f8		f9000fe0		MOVD R0, 24(RSP)							
  peak_experiment_test.go:4	0x10017c4fc		f9001be3		MOVD R3, 48(RSP)							
  peak_experiment_test.go:5	0x10017c500		f10010bf		CMP $4, R5								
  peak_experiment_test.go:5	0x10017c504		54001b23		BCC 217(PC)								
  peak_experiment_test.go:6	0x10017c508		f10020bf		CMP $8, R5								
  peak_experiment_test.go:6	0x10017c50c		54001ac3		BCC 214(PC)								
  peak_experiment_test.go:7	0x10017c510		f10030bf		CMP $12, R5								
  peak_experiment_test.go:7	0x10017c514		54001a63		BCC 211(PC)								
  peak_experiment_test.go:8	0x10017c518		f10040bf		CMP $16, R5								
  peak_experiment_test.go:8	0x10017c51c		54001a03		BCC 208(PC)								
  peak_experiment_test.go:9	0x10017c520		f10050bf		CMP $20, R5								
  peak_experiment_test.go:9	0x10017c524		540019a3		BCC 205(PC)								
  peak_experiment_test.go:10	0x10017c528		f10060bf		CMP $24, R5								
  peak_experiment_test.go:10	0x10017c52c		54001943		BCC 202(PC)								
  peak_experiment_test.go:11	0x10017c530		f10070bf		CMP $28, R5								
  peak_experiment_test.go:11	0x10017c534		540018e3		BCC 199(PC)								
  peak_experiment_test.go:12	0x10017c538		f10080bf		CMP $32, R5								
  peak_experiment_test.go:12	0x10017c53c		54001863		BCC 195(PC)								
  peak_experiment_test.go:13	0x10017c540		f10090bf		CMP $36, R5								
  peak_experiment_test.go:13	0x10017c544		540017e3		BCC 191(PC)								
  peak_experiment_test.go:14	0x10017c548		f100a0bf		CMP $40, R5								
  peak_experiment_test.go:14	0x10017c54c		54001763		BCC 187(PC)								
  peak_experiment_test.go:15	0x10017c550		f100b0bf		CMP $44, R5								
  peak_experiment_test.go:15	0x10017c554		540016e3		BCC 183(PC)								
  peak_experiment_test.go:16	0x10017c558		f100c0bf		CMP $48, R5								
  peak_experiment_test.go:16	0x10017c55c		54001663		BCC 179(PC)								
  peak_experiment_test.go:17	0x10017c560		f100d0bf		CMP $52, R5								
  peak_experiment_test.go:17	0x10017c564		540015e3		BCC 175(PC)								
  peak_experiment_test.go:18	0x10017c568		f100e0bf		CMP $56, R5								
  peak_experiment_test.go:18	0x10017c56c		54001563		BCC 171(PC)								
  peak_experiment_test.go:19	0x10017c570		f100f0bf		CMP $60, R5								
  peak_experiment_test.go:19	0x10017c574		540014e3		BCC 167(PC)								
  peak_experiment_test.go:20	0x10017c578		f10100bf		CMP $64, R5								
  peak_experiment_test.go:20	0x10017c57c		54001463		BCC 163(PC)								
  peak_experiment_test.go:21	0x10017c580		f10110bf		CMP $68, R5								
  peak_experiment_test.go:21	0x10017c584		540013e3		BCC 159(PC)								
  peak_experiment_test.go:22	0x10017c588		f10120bf		CMP $72, R5								
  peak_experiment_test.go:22	0x10017c58c		54001363		BCC 155(PC)								
  peak_experiment_test.go:23	0x10017c590		f10130bf		CMP $76, R5								
  peak_experiment_test.go:23	0x10017c594		540012e3		BCC 151(PC)								
  peak_experiment_test.go:24	0x10017c598		f10140bf		CMP $80, R5								
  peak_experiment_test.go:24	0x10017c59c		54001263		BCC 147(PC)								
  peak_experiment_test.go:25	0x10017c5a0		f10150bf		CMP $84, R5								
  peak_experiment_test.go:25	0x10017c5a4		540011e3		BCC 143(PC)								
  peak_experiment_test.go:26	0x10017c5a8		f10160bf		CMP $88, R5								
  peak_experiment_test.go:26	0x10017c5ac		54001163		BCC 139(PC)								
  peak_experiment_test.go:27	0x10017c5b0		f10170bf		CMP $92, R5								
  peak_experiment_test.go:27	0x10017c5b4		540010e3		BCC 135(PC)								
  peak_experiment_test.go:28	0x10017c5b8		f10180bf		CMP $96, R5								
  peak_experiment_test.go:28	0x10017c5bc		54001063		BCC 131(PC)								
  peak_experiment_test.go:29	0x10017c5c0		f10190bf		CMP $100, R5								
  peak_experiment_test.go:29	0x10017c5c4		54000fe3		BCC 127(PC)								
  peak_experiment_test.go:30	0x10017c5c8		f101a0bf		CMP $104, R5								
  peak_experiment_test.go:30	0x10017c5cc		54000f63		BCC 123(PC)								
  peak_experiment_test.go:5	0x10017c5d0		3dc00060		FMOVQ (R3), F0								
  peak_experiment_test.go:6	0x10017c5d4		3dc00461		FMOVQ 16(R3), F1							
  peak_experiment_test.go:7	0x10017c5d8		3dc00862		FMOVQ 32(R3), F2							
  peak_experiment_test.go:8	0x10017c5dc		3dc00c63		FMOVQ 48(R3), F3							
  peak_experiment_test.go:9	0x10017c5e0		3dc01064		FMOVQ 64(R3), F4							
  peak_experiment_test.go:10	0x10017c5e4		3dc01465		FMOVQ 80(R3), F5							
  peak_experiment_test.go:11	0x10017c5e8		3dc01866		FMOVQ 96(R3), F6							
  peak_experiment_test.go:12	0x10017c5ec		3dc01c67		FMOVQ 112(R3), F7							
  peak_experiment_test.go:13	0x10017c5f0		3dc02068		FMOVQ 128(R3), F8							
  peak_experiment_test.go:14	0x10017c5f4		3dc02469		FMOVQ 144(R3), F9							
  peak_experiment_test.go:15	0x10017c5f8		3dc0286a		FMOVQ 160(R3), F10							
  peak_experiment_test.go:16	0x10017c5fc		3dc02c6b		FMOVQ 176(R3), F11							
  peak_experiment_test.go:17	0x10017c600		3dc0306c		FMOVQ 192(R3), F12							
  peak_experiment_test.go:18	0x10017c604		3dc0346d		FMOVQ 208(R3), F13							
  peak_experiment_test.go:19	0x10017c608		3dc0386e		FMOVQ 224(R3), F14							
  peak_experiment_test.go:20	0x10017c60c		3dc03c6f		FMOVQ 240(R3), F15							
  peak_experiment_test.go:21	0x10017c610		3dc04070		FMOVQ 256(R3), F16							
  peak_experiment_test.go:22	0x10017c614		3dc04471		FMOVQ 272(R3), F17							
  peak_experiment_test.go:23	0x10017c618		3dc04872		FMOVQ 288(R3), F18							
  peak_experiment_test.go:24	0x10017c61c		3dc04c73		FMOVQ 304(R3), F19							
  peak_experiment_test.go:25	0x10017c620		3dc05074		FMOVQ 320(R3), F20							
  peak_experiment_test.go:26	0x10017c624		3dc05475		FMOVQ 336(R3), F21							
  peak_experiment_test.go:27	0x10017c628		3dc05876		FMOVQ 352(R3), F22							
  peak_experiment_test.go:28	0x10017c62c		3dc05c77		FMOVQ 368(R3), F23							
  peak_experiment_test.go:29	0x10017c630		3dc06078		FMOVQ 384(R3), F24							
  peak_experiment_test.go:30	0x10017c634		3dc06479		FMOVQ 400(R3), F25							
  peak_experiment_test.go:31	0x10017c638		14000012		JMP 18(PC)								
  peak_experiment_test.go:32	0x10017c63c		4e38ce00		VFMLA V24.S4, V16.S4, V0.S4						
  peak_experiment_test.go:33	0x10017c640		4e38ce21		VFMLA V24.S4, V17.S4, V1.S4						
  peak_experiment_test.go:34	0x10017c644		4e38ce42		VFMLA V24.S4, V18.S4, V2.S4						
  peak_experiment_test.go:35	0x10017c648		4e38ce63		VFMLA V24.S4, V19.S4, V3.S4						
  peak_experiment_test.go:36	0x10017c64c		4e38ce84		VFMLA V24.S4, V20.S4, V4.S4						
  peak_experiment_test.go:37	0x10017c650		4e38cea5		VFMLA V24.S4, V21.S4, V5.S4						
  peak_experiment_test.go:38	0x10017c654		4e38cec6		VFMLA V24.S4, V22.S4, V6.S4						
  peak_experiment_test.go:39	0x10017c658		4e38cee7		VFMLA V24.S4, V23.S4, V7.S4						
  peak_experiment_test.go:40	0x10017c65c		4e39ce08		VFMLA V25.S4, V16.S4, V8.S4						
  peak_experiment_test.go:41	0x10017c660		4e39ce29		VFMLA V25.S4, V17.S4, V9.S4						
  peak_experiment_test.go:42	0x10017c664		4e39ce4a		VFMLA V25.S4, V18.S4, V10.S4						
  peak_experiment_test.go:43	0x10017c668		4e39ce6b		VFMLA V25.S4, V19.S4, V11.S4						
  peak_experiment_test.go:44	0x10017c66c		4e39ce8c		VFMLA V25.S4, V20.S4, V12.S4						
  peak_experiment_test.go:45	0x10017c670		4e39cead		VFMLA V25.S4, V21.S4, V13.S4						
  peak_experiment_test.go:46	0x10017c674		4e39cece		VFMLA V25.S4, V22.S4, V14.S4						
  peak_experiment_test.go:47	0x10017c678		4e39ceef		VFMLA V25.S4, V23.S4, V15.S4						
  peak_experiment_test.go:31	0x10017c67c		d10004c6		SUB $1, R6, R6								
  peak_experiment_test.go:31	0x10017c680		f10000df		CMP $0, R6								
  peak_experiment_test.go:31	0x10017c684		54fffdcc		BGT -18(PC)								
  peak_experiment_test.go:49	0x10017c688		f100105f		CMP $4, R2								
  peak_experiment_test.go:49	0x10017c68c		54000943		BCC 74(PC)								
  peak_experiment_test.go:49	0x10017c690		3d800000		FMOVQ F0, (R0)								
  peak_experiment_test.go:50	0x10017c694		f100205f		CMP $8, R2								
  peak_experiment_test.go:50	0x10017c698		540008c3		BCC 70(PC)								
  peak_experiment_test.go:50	0x10017c69c		3d800401		FMOVQ F1, 16(R0)							
  peak_experiment_test.go:51	0x10017c6a0		f100305f		CMP $12, R2								
  peak_experiment_test.go:51	0x10017c6a4		54000843		BCC 66(PC)								
  peak_experiment_test.go:51	0x10017c6a8		3d800802		FMOVQ F2, 32(R0)							
  peak_experiment_test.go:52	0x10017c6ac		f100405f		CMP $16, R2								
  peak_experiment_test.go:52	0x10017c6b0		540007c3		BCC 62(PC)								
  peak_experiment_test.go:52	0x10017c6b4		3d800c03		FMOVQ F3, 48(R0)							
  peak_experiment_test.go:53	0x10017c6b8		f100505f		CMP $20, R2								
  peak_experiment_test.go:53	0x10017c6bc		54000743		BCC 58(PC)								
  peak_experiment_test.go:53	0x10017c6c0		3d801004		FMOVQ F4, 64(R0)							
  peak_experiment_test.go:54	0x10017c6c4		f100605f		CMP $24, R2								
  peak_experiment_test.go:54	0x10017c6c8		540006c3		BCC 54(PC)								
  peak_experiment_test.go:54	0x10017c6cc		3d801405		FMOVQ F5, 80(R0)							
  peak_experiment_test.go:55	0x10017c6d0		f100705f		CMP $28, R2								
  peak_experiment_test.go:55	0x10017c6d4		54000643		BCC 50(PC)								
  peak_experiment_test.go:55	0x10017c6d8		3d801806		FMOVQ F6, 96(R0)							
  peak_experiment_test.go:56	0x10017c6dc		f100805f		CMP $32, R2								
  peak_experiment_test.go:56	0x10017c6e0		540005a3		BCC 45(PC)								
  peak_experiment_test.go:56	0x10017c6e4		3d801c07		FMOVQ F7, 112(R0)							
  peak_experiment_test.go:57	0x10017c6e8		f100905f		CMP $36, R2								
  peak_experiment_test.go:57	0x10017c6ec		54000503		BCC 40(PC)								
  peak_experiment_test.go:57	0x10017c6f0		3d802008		FMOVQ F8, 128(R0)							
  peak_experiment_test.go:58	0x10017c6f4		f100a05f		CMP $40, R2								
  peak_experiment_test.go:58	0x10017c6f8		54000463		BCC 35(PC)								
  peak_experiment_test.go:58	0x10017c6fc		3d802409		FMOVQ F9, 144(R0)							
  peak_experiment_test.go:59	0x10017c700		f100b05f		CMP $44, R2								
  peak_experiment_test.go:59	0x10017c704		540003c3		BCC 30(PC)								
  peak_experiment_test.go:59	0x10017c708		3d80280a		FMOVQ F10, 160(R0)							
  peak_experiment_test.go:60	0x10017c70c		f100c05f		CMP $48, R2								
  peak_experiment_test.go:60	0x10017c710		54000323		BCC 25(PC)								
  peak_experiment_test.go:60	0x10017c714		3d802c0b		FMOVQ F11, 176(R0)							
  peak_experiment_test.go:61	0x10017c718		f100d05f		CMP $52, R2								
  peak_experiment_test.go:61	0x10017c71c		54000283		BCC 20(PC)								
  peak_experiment_test.go:61	0x10017c720		3d80300c		FMOVQ F12, 192(R0)							
  peak_experiment_test.go:62	0x10017c724		f100e05f		CMP $56, R2								
  peak_experiment_test.go:62	0x10017c728		540001e3		BCC 15(PC)								
  peak_experiment_test.go:62	0x10017c72c		3d80340d		FMOVQ F13, 208(R0)							
  peak_experiment_test.go:63	0x10017c730		f100f05f		CMP $60, R2								
  peak_experiment_test.go:63	0x10017c734		54000143		BCC 10(PC)								
  peak_experiment_test.go:63	0x10017c738		3d80380e		FMOVQ F14, 224(R0)							
  peak_experiment_test.go:64	0x10017c73c		f101005f		CMP $64, R2								
  peak_experiment_test.go:64	0x10017c740		540000a3		BCC 5(PC)								
  peak_experiment_test.go:64	0x10017c744		3d803c0f		FMOVQ F15, 240(R0)							
  peak_experiment_test.go:65	0x10017c748		f85f83fd		MOVD -8(RSP), R29							
  peak_experiment_test.go:65	0x10017c74c		f84107fe		MOVD.P 16(RSP), R30							
  peak_experiment_test.go:65	0x10017c750		d65f03c0		RET									
  peak_experiment_test.go:64	0x10017c754		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:64	0x10017c758		97fc2422		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:63	0x10017c75c		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:63	0x10017c760		97fc2420		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:62	0x10017c764		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:62	0x10017c768		97fc241e		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:61	0x10017c76c		d2800680		MOVD $52, R0								
  peak_experiment_test.go:61	0x10017c770		97fc241c		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:60	0x10017c774		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:60	0x10017c778		97fc241a		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:59	0x10017c77c		d2800580		MOVD $44, R0								
  peak_experiment_test.go:59	0x10017c780		97fc2418		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:58	0x10017c784		d2800500		MOVD $40, R0								
  peak_experiment_test.go:58	0x10017c788		97fc2416		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:57	0x10017c78c		d2800480		MOVD $36, R0								
  peak_experiment_test.go:57	0x10017c790		97fc2414		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:56	0x10017c794		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:56	0x10017c798		97fc2412		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:55	0x10017c79c		97fc2411		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:54	0x10017c7a0		97fc2410		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:53	0x10017c7a4		97fc240f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:52	0x10017c7a8		97fc240e		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:51	0x10017c7ac		97fc240d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:50	0x10017c7b0		97fc240c		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:49	0x10017c7b4		97fc240b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:30	0x10017c7b8		d2800d00		MOVD $104, R0								
  peak_experiment_test.go:30	0x10017c7bc		97fc2409		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:29	0x10017c7c0		d2800c80		MOVD $100, R0								
  peak_experiment_test.go:29	0x10017c7c4		97fc2407		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:28	0x10017c7c8		b27b07e0		ORR $96, ZR, R0								
  peak_experiment_test.go:28	0x10017c7cc		97fc2405		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:27	0x10017c7d0		d2800b80		MOVD $92, R0								
  peak_experiment_test.go:27	0x10017c7d4		97fc2403		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:26	0x10017c7d8		d2800b00		MOVD $88, R0								
  peak_experiment_test.go:26	0x10017c7dc		97fc2401		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:25	0x10017c7e0		d2800a80		MOVD $84, R0								
  peak_experiment_test.go:25	0x10017c7e4		97fc23ff		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:24	0x10017c7e8		d2800a00		MOVD $80, R0								
  peak_experiment_test.go:24	0x10017c7ec		97fc23fd		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:23	0x10017c7f0		d2800980		MOVD $76, R0								
  peak_experiment_test.go:23	0x10017c7f4		97fc23fb		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:22	0x10017c7f8		d2800900		MOVD $72, R0								
  peak_experiment_test.go:22	0x10017c7fc		97fc23f9		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:21	0x10017c800		d2800880		MOVD $68, R0								
  peak_experiment_test.go:21	0x10017c804		97fc23f7		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:20	0x10017c808		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:20	0x10017c80c		97fc23f5		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:19	0x10017c810		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:19	0x10017c814		97fc23f3		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:18	0x10017c818		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:18	0x10017c81c		97fc23f1		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:17	0x10017c820		d2800680		MOVD $52, R0								
  peak_experiment_test.go:17	0x10017c824		97fc23ef		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:16	0x10017c828		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:16	0x10017c82c		97fc23ed		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:15	0x10017c830		d2800580		MOVD $44, R0								
  peak_experiment_test.go:15	0x10017c834		97fc23eb		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:14	0x10017c838		d2800500		MOVD $40, R0								
  peak_experiment_test.go:14	0x10017c83c		97fc23e9		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:13	0x10017c840		d2800480		MOVD $36, R0								
  peak_experiment_test.go:13	0x10017c844		97fc23e7		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:12	0x10017c848		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:12	0x10017c84c		97fc23e5		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:11	0x10017c850		97fc23e4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:10	0x10017c854		97fc23e3		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:9	0x10017c858		97fc23e2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:8	0x10017c85c		97fc23e1		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:7	0x10017c860		97fc23e0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:6	0x10017c864		97fc23df		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:5	0x10017c868		97fc23de		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:5	0x10017c86c		d503201f		NOOP									
  peak_experiment_test.go:4	0x10017c870		a90087e0		STP (R0, R1), 8(RSP)							
  peak_experiment_test.go:4	0x10017c874		a9018fe2		STP (R2, R3), 24(RSP)							
  peak_experiment_test.go:4	0x10017c878		a90297e4		STP (R4, R5), 40(RSP)							
  peak_experiment_test.go:4	0x10017c87c		f9001fe6		MOVD R6, 56(RSP)							
  peak_experiment_test.go:4	0x10017c880		aa1e03e3		MOVD R30, R3								
  peak_experiment_test.go:4	0x10017c884		97fc1b93		CALL runtime.morestack_noctxt.abi0(SB)					
  peak_experiment_test.go:4	0x10017c888		a94087e0		LDP 8(RSP), (R0, R1)							
  peak_experiment_test.go:4	0x10017c88c		a9418fe2		LDP 24(RSP), (R2, R3)							
  peak_experiment_test.go:4	0x10017c890		a94297e4		LDP 40(RSP), (R4, R5)							
  peak_experiment_test.go:4	0x10017c894		f9401fe6		MOVD 56(RSP), R6							
  peak_experiment_test.go:4	0x10017c898		17ffff12		JMP github.com/GetStream/gophonic/internal/whispergemm.peak2x8(SB)	
  peak_experiment_test.go:4	0x10017c89c		00000000		?									

TEXT github.com/GetStream/gophonic/internal/whispergemm.peak4x4(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/peak_experiment_test.go
  peak_experiment_test.go:66	0x10017c8a0		f9400b90		MOVD 16(R28), R16							
  peak_experiment_test.go:66	0x10017c8a4		eb3063ff		CMP R16, RSP								
  peak_experiment_test.go:66	0x10017c8a8		54001b09		BLS 216(PC)								
  peak_experiment_test.go:66	0x10017c8ac		f81f0ffe		MOVD.W R30, -16(RSP)							
  peak_experiment_test.go:66	0x10017c8b0		f81f83fd		MOVD R29, -8(RSP)							
  peak_experiment_test.go:66	0x10017c8b4		d10023fd		SUB $8, RSP, R29							
  peak_experiment_test.go:66	0x10017c8b8		f9000fe0		MOVD R0, 24(RSP)							
  peak_experiment_test.go:66	0x10017c8bc		f9001be3		MOVD R3, 48(RSP)							
  peak_experiment_test.go:67	0x10017c8c0		f10010bf		CMP $4, R5								
  peak_experiment_test.go:67	0x10017c8c4		540019e3		BCC 207(PC)								
  peak_experiment_test.go:68	0x10017c8c8		f10020bf		CMP $8, R5								
  peak_experiment_test.go:68	0x10017c8cc		54001983		BCC 204(PC)								
  peak_experiment_test.go:69	0x10017c8d0		f10030bf		CMP $12, R5								
  peak_experiment_test.go:69	0x10017c8d4		54001923		BCC 201(PC)								
  peak_experiment_test.go:70	0x10017c8d8		f10040bf		CMP $16, R5								
  peak_experiment_test.go:70	0x10017c8dc		540018c3		BCC 198(PC)								
  peak_experiment_test.go:71	0x10017c8e0		f10050bf		CMP $20, R5								
  peak_experiment_test.go:71	0x10017c8e4		54001863		BCC 195(PC)								
  peak_experiment_test.go:72	0x10017c8e8		f10060bf		CMP $24, R5								
  peak_experiment_test.go:72	0x10017c8ec		54001803		BCC 192(PC)								
  peak_experiment_test.go:73	0x10017c8f0		f10070bf		CMP $28, R5								
  peak_experiment_test.go:73	0x10017c8f4		540017a3		BCC 189(PC)								
  peak_experiment_test.go:74	0x10017c8f8		f10080bf		CMP $32, R5								
  peak_experiment_test.go:74	0x10017c8fc		54001723		BCC 185(PC)								
  peak_experiment_test.go:75	0x10017c900		f10090bf		CMP $36, R5								
  peak_experiment_test.go:75	0x10017c904		540016a3		BCC 181(PC)								
  peak_experiment_test.go:76	0x10017c908		f100a0bf		CMP $40, R5								
  peak_experiment_test.go:76	0x10017c90c		54001623		BCC 177(PC)								
  peak_experiment_test.go:77	0x10017c910		f100b0bf		CMP $44, R5								
  peak_experiment_test.go:77	0x10017c914		540015a3		BCC 173(PC)								
  peak_experiment_test.go:78	0x10017c918		f100c0bf		CMP $48, R5								
  peak_experiment_test.go:78	0x10017c91c		54001523		BCC 169(PC)								
  peak_experiment_test.go:79	0x10017c920		f100d0bf		CMP $52, R5								
  peak_experiment_test.go:79	0x10017c924		540014a3		BCC 165(PC)								
  peak_experiment_test.go:80	0x10017c928		f100e0bf		CMP $56, R5								
  peak_experiment_test.go:80	0x10017c92c		54001423		BCC 161(PC)								
  peak_experiment_test.go:81	0x10017c930		f100f0bf		CMP $60, R5								
  peak_experiment_test.go:81	0x10017c934		540013a3		BCC 157(PC)								
  peak_experiment_test.go:82	0x10017c938		f10100bf		CMP $64, R5								
  peak_experiment_test.go:82	0x10017c93c		54001323		BCC 153(PC)								
  peak_experiment_test.go:83	0x10017c940		f10110bf		CMP $68, R5								
  peak_experiment_test.go:83	0x10017c944		540012a3		BCC 149(PC)								
  peak_experiment_test.go:84	0x10017c948		f10120bf		CMP $72, R5								
  peak_experiment_test.go:84	0x10017c94c		54001223		BCC 145(PC)								
  peak_experiment_test.go:85	0x10017c950		f10130bf		CMP $76, R5								
  peak_experiment_test.go:85	0x10017c954		540011a3		BCC 141(PC)								
  peak_experiment_test.go:86	0x10017c958		f10140bf		CMP $80, R5								
  peak_experiment_test.go:86	0x10017c95c		54001123		BCC 137(PC)								
  peak_experiment_test.go:87	0x10017c960		f10150bf		CMP $84, R5								
  peak_experiment_test.go:87	0x10017c964		540010a3		BCC 133(PC)								
  peak_experiment_test.go:88	0x10017c968		f10160bf		CMP $88, R5								
  peak_experiment_test.go:88	0x10017c96c		54001023		BCC 129(PC)								
  peak_experiment_test.go:89	0x10017c970		f10170bf		CMP $92, R5								
  peak_experiment_test.go:89	0x10017c974		54000fa3		BCC 125(PC)								
  peak_experiment_test.go:90	0x10017c978		f10180bf		CMP $96, R5								
  peak_experiment_test.go:90	0x10017c97c		54000f23		BCC 121(PC)								
  peak_experiment_test.go:67	0x10017c980		3dc00060		FMOVQ (R3), F0								
  peak_experiment_test.go:68	0x10017c984		3dc00461		FMOVQ 16(R3), F1							
  peak_experiment_test.go:69	0x10017c988		3dc00862		FMOVQ 32(R3), F2							
  peak_experiment_test.go:70	0x10017c98c		3dc00c63		FMOVQ 48(R3), F3							
  peak_experiment_test.go:71	0x10017c990		3dc01064		FMOVQ 64(R3), F4							
  peak_experiment_test.go:72	0x10017c994		3dc01465		FMOVQ 80(R3), F5							
  peak_experiment_test.go:73	0x10017c998		3dc01866		FMOVQ 96(R3), F6							
  peak_experiment_test.go:74	0x10017c99c		3dc01c67		FMOVQ 112(R3), F7							
  peak_experiment_test.go:75	0x10017c9a0		3dc02068		FMOVQ 128(R3), F8							
  peak_experiment_test.go:76	0x10017c9a4		3dc02469		FMOVQ 144(R3), F9							
  peak_experiment_test.go:77	0x10017c9a8		3dc0286a		FMOVQ 160(R3), F10							
  peak_experiment_test.go:78	0x10017c9ac		3dc02c6b		FMOVQ 176(R3), F11							
  peak_experiment_test.go:79	0x10017c9b0		3dc0306c		FMOVQ 192(R3), F12							
  peak_experiment_test.go:80	0x10017c9b4		3dc0346d		FMOVQ 208(R3), F13							
  peak_experiment_test.go:81	0x10017c9b8		3dc0386e		FMOVQ 224(R3), F14							
  peak_experiment_test.go:82	0x10017c9bc		3dc03c6f		FMOVQ 240(R3), F15							
  peak_experiment_test.go:83	0x10017c9c0		3dc04070		FMOVQ 256(R3), F16							
  peak_experiment_test.go:84	0x10017c9c4		3dc04471		FMOVQ 272(R3), F17							
  peak_experiment_test.go:85	0x10017c9c8		3dc04872		FMOVQ 288(R3), F18							
  peak_experiment_test.go:86	0x10017c9cc		3dc04c73		FMOVQ 304(R3), F19							
  peak_experiment_test.go:87	0x10017c9d0		3dc05074		FMOVQ 320(R3), F20							
  peak_experiment_test.go:88	0x10017c9d4		3dc05475		FMOVQ 336(R3), F21							
  peak_experiment_test.go:89	0x10017c9d8		3dc05876		FMOVQ 352(R3), F22							
  peak_experiment_test.go:90	0x10017c9dc		3dc05c77		FMOVQ 368(R3), F23							
  peak_experiment_test.go:91	0x10017c9e0		14000012		JMP 18(PC)								
  peak_experiment_test.go:92	0x10017c9e4		4e34ce00		VFMLA V20.S4, V16.S4, V0.S4						
  peak_experiment_test.go:93	0x10017c9e8		4e34ce21		VFMLA V20.S4, V17.S4, V1.S4						
  peak_experiment_test.go:94	0x10017c9ec		4e34ce42		VFMLA V20.S4, V18.S4, V2.S4						
  peak_experiment_test.go:95	0x10017c9f0		4e34ce63		VFMLA V20.S4, V19.S4, V3.S4						
  peak_experiment_test.go:96	0x10017c9f4		4e35ce04		VFMLA V21.S4, V16.S4, V4.S4						
  peak_experiment_test.go:97	0x10017c9f8		4e35ce25		VFMLA V21.S4, V17.S4, V5.S4						
  peak_experiment_test.go:98	0x10017c9fc		4e35ce46		VFMLA V21.S4, V18.S4, V6.S4						
  peak_experiment_test.go:99	0x10017ca00		4e35ce67		VFMLA V21.S4, V19.S4, V7.S4						
  peak_experiment_test.go:100	0x10017ca04		4e36ce08		VFMLA V22.S4, V16.S4, V8.S4						
  peak_experiment_test.go:101	0x10017ca08		4e36ce29		VFMLA V22.S4, V17.S4, V9.S4						
  peak_experiment_test.go:102	0x10017ca0c		4e36ce4a		VFMLA V22.S4, V18.S4, V10.S4						
  peak_experiment_test.go:103	0x10017ca10		4e36ce6b		VFMLA V22.S4, V19.S4, V11.S4						
  peak_experiment_test.go:104	0x10017ca14		4e37ce0c		VFMLA V23.S4, V16.S4, V12.S4						
  peak_experiment_test.go:105	0x10017ca18		4e37ce2d		VFMLA V23.S4, V17.S4, V13.S4						
  peak_experiment_test.go:106	0x10017ca1c		4e37ce4e		VFMLA V23.S4, V18.S4, V14.S4						
  peak_experiment_test.go:107	0x10017ca20		4e37ce6f		VFMLA V23.S4, V19.S4, V15.S4						
  peak_experiment_test.go:91	0x10017ca24		d10004c6		SUB $1, R6, R6								
  peak_experiment_test.go:91	0x10017ca28		f10000df		CMP $0, R6								
  peak_experiment_test.go:91	0x10017ca2c		54fffdcc		BGT -18(PC)								
  peak_experiment_test.go:109	0x10017ca30		f100105f		CMP $4, R2								
  peak_experiment_test.go:109	0x10017ca34		54000943		BCC 74(PC)								
  peak_experiment_test.go:109	0x10017ca38		3d800000		FMOVQ F0, (R0)								
  peak_experiment_test.go:110	0x10017ca3c		f100205f		CMP $8, R2								
  peak_experiment_test.go:110	0x10017ca40		540008c3		BCC 70(PC)								
  peak_experiment_test.go:110	0x10017ca44		3d800401		FMOVQ F1, 16(R0)							
  peak_experiment_test.go:111	0x10017ca48		f100305f		CMP $12, R2								
  peak_experiment_test.go:111	0x10017ca4c		54000843		BCC 66(PC)								
  peak_experiment_test.go:111	0x10017ca50		3d800802		FMOVQ F2, 32(R0)							
  peak_experiment_test.go:112	0x10017ca54		f100405f		CMP $16, R2								
  peak_experiment_test.go:112	0x10017ca58		540007c3		BCC 62(PC)								
  peak_experiment_test.go:112	0x10017ca5c		3d800c03		FMOVQ F3, 48(R0)							
  peak_experiment_test.go:113	0x10017ca60		f100505f		CMP $20, R2								
  peak_experiment_test.go:113	0x10017ca64		54000743		BCC 58(PC)								
  peak_experiment_test.go:113	0x10017ca68		3d801004		FMOVQ F4, 64(R0)							
  peak_experiment_test.go:114	0x10017ca6c		f100605f		CMP $24, R2								
  peak_experiment_test.go:114	0x10017ca70		540006c3		BCC 54(PC)								
  peak_experiment_test.go:114	0x10017ca74		3d801405		FMOVQ F5, 80(R0)							
  peak_experiment_test.go:115	0x10017ca78		f100705f		CMP $28, R2								
  peak_experiment_test.go:115	0x10017ca7c		54000643		BCC 50(PC)								
  peak_experiment_test.go:115	0x10017ca80		3d801806		FMOVQ F6, 96(R0)							
  peak_experiment_test.go:116	0x10017ca84		f100805f		CMP $32, R2								
  peak_experiment_test.go:116	0x10017ca88		540005a3		BCC 45(PC)								
  peak_experiment_test.go:116	0x10017ca8c		3d801c07		FMOVQ F7, 112(R0)							
  peak_experiment_test.go:117	0x10017ca90		f100905f		CMP $36, R2								
  peak_experiment_test.go:117	0x10017ca94		54000503		BCC 40(PC)								
  peak_experiment_test.go:117	0x10017ca98		3d802008		FMOVQ F8, 128(R0)							
  peak_experiment_test.go:118	0x10017ca9c		f100a05f		CMP $40, R2								
  peak_experiment_test.go:118	0x10017caa0		54000463		BCC 35(PC)								
  peak_experiment_test.go:118	0x10017caa4		3d802409		FMOVQ F9, 144(R0)							
  peak_experiment_test.go:119	0x10017caa8		f100b05f		CMP $44, R2								
  peak_experiment_test.go:119	0x10017caac		540003c3		BCC 30(PC)								
  peak_experiment_test.go:119	0x10017cab0		3d80280a		FMOVQ F10, 160(R0)							
  peak_experiment_test.go:120	0x10017cab4		f100c05f		CMP $48, R2								
  peak_experiment_test.go:120	0x10017cab8		54000323		BCC 25(PC)								
  peak_experiment_test.go:120	0x10017cabc		3d802c0b		FMOVQ F11, 176(R0)							
  peak_experiment_test.go:121	0x10017cac0		f100d05f		CMP $52, R2								
  peak_experiment_test.go:121	0x10017cac4		54000283		BCC 20(PC)								
  peak_experiment_test.go:121	0x10017cac8		3d80300c		FMOVQ F12, 192(R0)							
  peak_experiment_test.go:122	0x10017cacc		f100e05f		CMP $56, R2								
  peak_experiment_test.go:122	0x10017cad0		540001e3		BCC 15(PC)								
  peak_experiment_test.go:122	0x10017cad4		3d80340d		FMOVQ F13, 208(R0)							
  peak_experiment_test.go:123	0x10017cad8		f100f05f		CMP $60, R2								
  peak_experiment_test.go:123	0x10017cadc		54000143		BCC 10(PC)								
  peak_experiment_test.go:123	0x10017cae0		3d80380e		FMOVQ F14, 224(R0)							
  peak_experiment_test.go:124	0x10017cae4		f101005f		CMP $64, R2								
  peak_experiment_test.go:124	0x10017cae8		540000a3		BCC 5(PC)								
  peak_experiment_test.go:124	0x10017caec		3d803c0f		FMOVQ F15, 240(R0)							
  peak_experiment_test.go:125	0x10017caf0		f85f83fd		MOVD -8(RSP), R29							
  peak_experiment_test.go:125	0x10017caf4		f84107fe		MOVD.P 16(RSP), R30							
  peak_experiment_test.go:125	0x10017caf8		d65f03c0		RET									
  peak_experiment_test.go:124	0x10017cafc		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:124	0x10017cb00		97fc2338		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:123	0x10017cb04		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:123	0x10017cb08		97fc2336		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:122	0x10017cb0c		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:122	0x10017cb10		97fc2334		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:121	0x10017cb14		d2800680		MOVD $52, R0								
  peak_experiment_test.go:121	0x10017cb18		97fc2332		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:120	0x10017cb1c		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:120	0x10017cb20		97fc2330		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:119	0x10017cb24		d2800580		MOVD $44, R0								
  peak_experiment_test.go:119	0x10017cb28		97fc232e		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:118	0x10017cb2c		d2800500		MOVD $40, R0								
  peak_experiment_test.go:118	0x10017cb30		97fc232c		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:117	0x10017cb34		d2800480		MOVD $36, R0								
  peak_experiment_test.go:117	0x10017cb38		97fc232a		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:116	0x10017cb3c		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:116	0x10017cb40		97fc2328		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:115	0x10017cb44		97fc2327		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:114	0x10017cb48		97fc2326		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:113	0x10017cb4c		97fc2325		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:112	0x10017cb50		97fc2324		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:111	0x10017cb54		97fc2323		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:110	0x10017cb58		97fc2322		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:109	0x10017cb5c		97fc2321		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:90	0x10017cb60		b27b07e0		ORR $96, ZR, R0								
  peak_experiment_test.go:90	0x10017cb64		97fc231f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:89	0x10017cb68		d2800b80		MOVD $92, R0								
  peak_experiment_test.go:89	0x10017cb6c		97fc231d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:88	0x10017cb70		d2800b00		MOVD $88, R0								
  peak_experiment_test.go:88	0x10017cb74		97fc231b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:87	0x10017cb78		d2800a80		MOVD $84, R0								
  peak_experiment_test.go:87	0x10017cb7c		97fc2319		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:86	0x10017cb80		d2800a00		MOVD $80, R0								
  peak_experiment_test.go:86	0x10017cb84		97fc2317		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:85	0x10017cb88		d2800980		MOVD $76, R0								
  peak_experiment_test.go:85	0x10017cb8c		97fc2315		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:84	0x10017cb90		d2800900		MOVD $72, R0								
  peak_experiment_test.go:84	0x10017cb94		97fc2313		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:83	0x10017cb98		d2800880		MOVD $68, R0								
  peak_experiment_test.go:83	0x10017cb9c		97fc2311		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:82	0x10017cba0		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:82	0x10017cba4		97fc230f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:81	0x10017cba8		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:81	0x10017cbac		97fc230d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:80	0x10017cbb0		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:80	0x10017cbb4		97fc230b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:79	0x10017cbb8		d2800680		MOVD $52, R0								
  peak_experiment_test.go:79	0x10017cbbc		97fc2309		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:78	0x10017cbc0		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:78	0x10017cbc4		97fc2307		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:77	0x10017cbc8		d2800580		MOVD $44, R0								
  peak_experiment_test.go:77	0x10017cbcc		97fc2305		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:76	0x10017cbd0		d2800500		MOVD $40, R0								
  peak_experiment_test.go:76	0x10017cbd4		97fc2303		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:75	0x10017cbd8		d2800480		MOVD $36, R0								
  peak_experiment_test.go:75	0x10017cbdc		97fc2301		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:74	0x10017cbe0		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:74	0x10017cbe4		97fc22ff		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:73	0x10017cbe8		97fc22fe		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:72	0x10017cbec		97fc22fd		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:71	0x10017cbf0		97fc22fc		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:70	0x10017cbf4		97fc22fb		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:69	0x10017cbf8		97fc22fa		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:68	0x10017cbfc		97fc22f9		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:67	0x10017cc00		97fc22f8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:67	0x10017cc04		d503201f		NOOP									
  peak_experiment_test.go:66	0x10017cc08		a90087e0		STP (R0, R1), 8(RSP)							
  peak_experiment_test.go:66	0x10017cc0c		a9018fe2		STP (R2, R3), 24(RSP)							
  peak_experiment_test.go:66	0x10017cc10		a90297e4		STP (R4, R5), 40(RSP)							
  peak_experiment_test.go:66	0x10017cc14		f9001fe6		MOVD R6, 56(RSP)							
  peak_experiment_test.go:66	0x10017cc18		aa1e03e3		MOVD R30, R3								
  peak_experiment_test.go:66	0x10017cc1c		97fc1aad		CALL runtime.morestack_noctxt.abi0(SB)					
  peak_experiment_test.go:66	0x10017cc20		a94087e0		LDP 8(RSP), (R0, R1)							
  peak_experiment_test.go:66	0x10017cc24		a9418fe2		LDP 24(RSP), (R2, R3)							
  peak_experiment_test.go:66	0x10017cc28		a94297e4		LDP 40(RSP), (R4, R5)							
  peak_experiment_test.go:66	0x10017cc2c		f9401fe6		MOVD 56(RSP), R6							
  peak_experiment_test.go:66	0x10017cc30		17ffff1c		JMP github.com/GetStream/gophonic/internal/whispergemm.peak4x4(SB)	
  peak_experiment_test.go:66	0x10017cc34		00000000		?									
  peak_experiment_test.go:66	0x10017cc38		00000000		?									
  peak_experiment_test.go:66	0x10017cc3c		00000000		?									

TEXT github.com/GetStream/gophonic/internal/whispergemm.peak5x4(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/peak_experiment_test.go
  peak_experiment_test.go:126	0x10017cc40		f9400b90		MOVD 16(R28), R16							
  peak_experiment_test.go:126	0x10017cc44		eb3063ff		CMP R16, RSP								
  peak_experiment_test.go:126	0x10017cc48		54002129		BLS 265(PC)								
  peak_experiment_test.go:126	0x10017cc4c		f81f0ffe		MOVD.W R30, -16(RSP)							
  peak_experiment_test.go:126	0x10017cc50		f81f83fd		MOVD R29, -8(RSP)							
  peak_experiment_test.go:126	0x10017cc54		d10023fd		SUB $8, RSP, R29							
  peak_experiment_test.go:126	0x10017cc58		f9000fe0		MOVD R0, 24(RSP)							
  peak_experiment_test.go:126	0x10017cc5c		f9001be3		MOVD R3, 48(RSP)							
  peak_experiment_test.go:127	0x10017cc60		f10010bf		CMP $4, R5								
  peak_experiment_test.go:127	0x10017cc64		54002003		BCC 256(PC)								
  peak_experiment_test.go:128	0x10017cc68		f10020bf		CMP $8, R5								
  peak_experiment_test.go:128	0x10017cc6c		54001fa3		BCC 253(PC)								
  peak_experiment_test.go:129	0x10017cc70		f10030bf		CMP $12, R5								
  peak_experiment_test.go:129	0x10017cc74		54001f43		BCC 250(PC)								
  peak_experiment_test.go:130	0x10017cc78		f10040bf		CMP $16, R5								
  peak_experiment_test.go:130	0x10017cc7c		54001ee3		BCC 247(PC)								
  peak_experiment_test.go:131	0x10017cc80		f10050bf		CMP $20, R5								
  peak_experiment_test.go:131	0x10017cc84		54001e83		BCC 244(PC)								
  peak_experiment_test.go:132	0x10017cc88		f10060bf		CMP $24, R5								
  peak_experiment_test.go:132	0x10017cc8c		54001e23		BCC 241(PC)								
  peak_experiment_test.go:133	0x10017cc90		f10070bf		CMP $28, R5								
  peak_experiment_test.go:133	0x10017cc94		54001dc3		BCC 238(PC)								
  peak_experiment_test.go:134	0x10017cc98		f10080bf		CMP $32, R5								
  peak_experiment_test.go:134	0x10017cc9c		54001d43		BCC 234(PC)								
  peak_experiment_test.go:135	0x10017cca0		f10090bf		CMP $36, R5								
  peak_experiment_test.go:135	0x10017cca4		54001cc3		BCC 230(PC)								
  peak_experiment_test.go:136	0x10017cca8		f100a0bf		CMP $40, R5								
  peak_experiment_test.go:136	0x10017ccac		54001c43		BCC 226(PC)								
  peak_experiment_test.go:137	0x10017ccb0		f100b0bf		CMP $44, R5								
  peak_experiment_test.go:137	0x10017ccb4		54001bc3		BCC 222(PC)								
  peak_experiment_test.go:138	0x10017ccb8		f100c0bf		CMP $48, R5								
  peak_experiment_test.go:138	0x10017ccbc		54001b43		BCC 218(PC)								
  peak_experiment_test.go:139	0x10017ccc0		f100d0bf		CMP $52, R5								
  peak_experiment_test.go:139	0x10017ccc4		54001ac3		BCC 214(PC)								
  peak_experiment_test.go:140	0x10017ccc8		f100e0bf		CMP $56, R5								
  peak_experiment_test.go:140	0x10017cccc		54001a43		BCC 210(PC)								
  peak_experiment_test.go:141	0x10017ccd0		f100f0bf		CMP $60, R5								
  peak_experiment_test.go:141	0x10017ccd4		540019c3		BCC 206(PC)								
  peak_experiment_test.go:142	0x10017ccd8		f10100bf		CMP $64, R5								
  peak_experiment_test.go:142	0x10017ccdc		54001943		BCC 202(PC)								
  peak_experiment_test.go:143	0x10017cce0		f10110bf		CMP $68, R5								
  peak_experiment_test.go:143	0x10017cce4		540018c3		BCC 198(PC)								
  peak_experiment_test.go:144	0x10017cce8		f10120bf		CMP $72, R5								
  peak_experiment_test.go:144	0x10017ccec		54001843		BCC 194(PC)								
  peak_experiment_test.go:145	0x10017ccf0		f10130bf		CMP $76, R5								
  peak_experiment_test.go:145	0x10017ccf4		540017c3		BCC 190(PC)								
  peak_experiment_test.go:146	0x10017ccf8		f10140bf		CMP $80, R5								
  peak_experiment_test.go:146	0x10017ccfc		54001743		BCC 186(PC)								
  peak_experiment_test.go:147	0x10017cd00		f10150bf		CMP $84, R5								
  peak_experiment_test.go:147	0x10017cd04		540016c3		BCC 182(PC)								
  peak_experiment_test.go:148	0x10017cd08		f10160bf		CMP $88, R5								
  peak_experiment_test.go:148	0x10017cd0c		54001643		BCC 178(PC)								
  peak_experiment_test.go:149	0x10017cd10		f10170bf		CMP $92, R5								
  peak_experiment_test.go:149	0x10017cd14		540015c3		BCC 174(PC)								
  peak_experiment_test.go:150	0x10017cd18		f10180bf		CMP $96, R5								
  peak_experiment_test.go:150	0x10017cd1c		54001543		BCC 170(PC)								
  peak_experiment_test.go:151	0x10017cd20		f10190bf		CMP $100, R5								
  peak_experiment_test.go:151	0x10017cd24		540014c3		BCC 166(PC)								
  peak_experiment_test.go:152	0x10017cd28		f101a0bf		CMP $104, R5								
  peak_experiment_test.go:152	0x10017cd2c		54001443		BCC 162(PC)								
  peak_experiment_test.go:153	0x10017cd30		f101b0bf		CMP $108, R5								
  peak_experiment_test.go:153	0x10017cd34		540013c3		BCC 158(PC)								
  peak_experiment_test.go:154	0x10017cd38		f101c0bf		CMP $112, R5								
  peak_experiment_test.go:154	0x10017cd3c		54001343		BCC 154(PC)								
  peak_experiment_test.go:155	0x10017cd40		f101d0bf		CMP $116, R5								
  peak_experiment_test.go:155	0x10017cd44		540012c3		BCC 150(PC)								
  peak_experiment_test.go:127	0x10017cd48		3dc00060		FMOVQ (R3), F0								
  peak_experiment_test.go:128	0x10017cd4c		3dc00461		FMOVQ 16(R3), F1							
  peak_experiment_test.go:129	0x10017cd50		3dc00862		FMOVQ 32(R3), F2							
  peak_experiment_test.go:130	0x10017cd54		3dc00c63		FMOVQ 48(R3), F3							
  peak_experiment_test.go:131	0x10017cd58		3dc01064		FMOVQ 64(R3), F4							
  peak_experiment_test.go:132	0x10017cd5c		3dc01465		FMOVQ 80(R3), F5							
  peak_experiment_test.go:133	0x10017cd60		3dc01866		FMOVQ 96(R3), F6							
  peak_experiment_test.go:134	0x10017cd64		3dc01c67		FMOVQ 112(R3), F7							
  peak_experiment_test.go:135	0x10017cd68		3dc02068		FMOVQ 128(R3), F8							
  peak_experiment_test.go:136	0x10017cd6c		3dc02469		FMOVQ 144(R3), F9							
  peak_experiment_test.go:137	0x10017cd70		3dc0286a		FMOVQ 160(R3), F10							
  peak_experiment_test.go:138	0x10017cd74		3dc02c6b		FMOVQ 176(R3), F11							
  peak_experiment_test.go:139	0x10017cd78		3dc0306c		FMOVQ 192(R3), F12							
  peak_experiment_test.go:140	0x10017cd7c		3dc0346d		FMOVQ 208(R3), F13							
  peak_experiment_test.go:141	0x10017cd80		3dc0386e		FMOVQ 224(R3), F14							
  peak_experiment_test.go:142	0x10017cd84		3dc03c6f		FMOVQ 240(R3), F15							
  peak_experiment_test.go:143	0x10017cd88		3dc04070		FMOVQ 256(R3), F16							
  peak_experiment_test.go:144	0x10017cd8c		3dc04471		FMOVQ 272(R3), F17							
  peak_experiment_test.go:145	0x10017cd90		3dc04872		FMOVQ 288(R3), F18							
  peak_experiment_test.go:146	0x10017cd94		3dc04c73		FMOVQ 304(R3), F19							
  peak_experiment_test.go:147	0x10017cd98		3dc05074		FMOVQ 320(R3), F20							
  peak_experiment_test.go:148	0x10017cd9c		3dc05475		FMOVQ 336(R3), F21							
  peak_experiment_test.go:149	0x10017cda0		3dc05876		FMOVQ 352(R3), F22							
  peak_experiment_test.go:150	0x10017cda4		3dc05c77		FMOVQ 368(R3), F23							
  peak_experiment_test.go:151	0x10017cda8		3dc06078		FMOVQ 384(R3), F24							
  peak_experiment_test.go:152	0x10017cdac		3dc06479		FMOVQ 400(R3), F25							
  peak_experiment_test.go:153	0x10017cdb0		3dc0687a		FMOVQ 416(R3), F26							
  peak_experiment_test.go:154	0x10017cdb4		3dc06c7b		FMOVQ 432(R3), F27							
  peak_experiment_test.go:155	0x10017cdb8		3dc0707c		FMOVQ 448(R3), F28							
  peak_experiment_test.go:156	0x10017cdbc		14000016		JMP 22(PC)								
  peak_experiment_test.go:157	0x10017cdc0		4e38ce80		VFMLA V24.S4, V20.S4, V0.S4						
  peak_experiment_test.go:158	0x10017cdc4		4e38cea1		VFMLA V24.S4, V21.S4, V1.S4						
  peak_experiment_test.go:159	0x10017cdc8		4e38cec2		VFMLA V24.S4, V22.S4, V2.S4						
  peak_experiment_test.go:160	0x10017cdcc		4e38cee3		VFMLA V24.S4, V23.S4, V3.S4						
  peak_experiment_test.go:161	0x10017cdd0		4e39ce84		VFMLA V25.S4, V20.S4, V4.S4						
  peak_experiment_test.go:162	0x10017cdd4		4e39cea5		VFMLA V25.S4, V21.S4, V5.S4						
  peak_experiment_test.go:163	0x10017cdd8		4e39cec6		VFMLA V25.S4, V22.S4, V6.S4						
  peak_experiment_test.go:164	0x10017cddc		4e39cee7		VFMLA V25.S4, V23.S4, V7.S4						
  peak_experiment_test.go:165	0x10017cde0		4e3ace88		VFMLA V26.S4, V20.S4, V8.S4						
  peak_experiment_test.go:166	0x10017cde4		4e3acea9		VFMLA V26.S4, V21.S4, V9.S4						
  peak_experiment_test.go:167	0x10017cde8		4e3aceca		VFMLA V26.S4, V22.S4, V10.S4						
  peak_experiment_test.go:168	0x10017cdec		4e3aceeb		VFMLA V26.S4, V23.S4, V11.S4						
  peak_experiment_test.go:169	0x10017cdf0		4e3bce8c		VFMLA V27.S4, V20.S4, V12.S4						
  peak_experiment_test.go:170	0x10017cdf4		4e3bcead		VFMLA V27.S4, V21.S4, V13.S4						
  peak_experiment_test.go:171	0x10017cdf8		4e3bcece		VFMLA V27.S4, V22.S4, V14.S4						
  peak_experiment_test.go:172	0x10017cdfc		4e3bceef		VFMLA V27.S4, V23.S4, V15.S4						
  peak_experiment_test.go:173	0x10017ce00		4e3cce90		VFMLA V28.S4, V20.S4, V16.S4						
  peak_experiment_test.go:174	0x10017ce04		4e3cceb1		VFMLA V28.S4, V21.S4, V17.S4						
  peak_experiment_test.go:175	0x10017ce08		4e3cced2		VFMLA V28.S4, V22.S4, V18.S4						
  peak_experiment_test.go:176	0x10017ce0c		4e3ccef3		VFMLA V28.S4, V23.S4, V19.S4						
  peak_experiment_test.go:156	0x10017ce10		d10004c6		SUB $1, R6, R6								
  peak_experiment_test.go:156	0x10017ce14		f10000df		CMP $0, R6								
  peak_experiment_test.go:156	0x10017ce18		54fffd4c		BGT -22(PC)								
  peak_experiment_test.go:178	0x10017ce1c		f100105f		CMP $4, R2								
  peak_experiment_test.go:178	0x10017ce20		54000bc3		BCC 94(PC)								
  peak_experiment_test.go:178	0x10017ce24		3d800000		FMOVQ F0, (R0)								
  peak_experiment_test.go:179	0x10017ce28		f100205f		CMP $8, R2								
  peak_experiment_test.go:179	0x10017ce2c		54000b43		BCC 90(PC)								
  peak_experiment_test.go:179	0x10017ce30		3d800401		FMOVQ F1, 16(R0)							
  peak_experiment_test.go:180	0x10017ce34		f100305f		CMP $12, R2								
  peak_experiment_test.go:180	0x10017ce38		54000ac3		BCC 86(PC)								
  peak_experiment_test.go:180	0x10017ce3c		3d800802		FMOVQ F2, 32(R0)							
  peak_experiment_test.go:181	0x10017ce40		f100405f		CMP $16, R2								
  peak_experiment_test.go:181	0x10017ce44		54000a43		BCC 82(PC)								
  peak_experiment_test.go:181	0x10017ce48		3d800c03		FMOVQ F3, 48(R0)							
  peak_experiment_test.go:182	0x10017ce4c		f100505f		CMP $20, R2								
  peak_experiment_test.go:182	0x10017ce50		540009c3		BCC 78(PC)								
  peak_experiment_test.go:182	0x10017ce54		3d801004		FMOVQ F4, 64(R0)							
  peak_experiment_test.go:183	0x10017ce58		f100605f		CMP $24, R2								
  peak_experiment_test.go:183	0x10017ce5c		54000943		BCC 74(PC)								
  peak_experiment_test.go:183	0x10017ce60		3d801405		FMOVQ F5, 80(R0)							
  peak_experiment_test.go:184	0x10017ce64		f100705f		CMP $28, R2								
  peak_experiment_test.go:184	0x10017ce68		540008c3		BCC 70(PC)								
  peak_experiment_test.go:184	0x10017ce6c		3d801806		FMOVQ F6, 96(R0)							
  peak_experiment_test.go:185	0x10017ce70		f100805f		CMP $32, R2								
  peak_experiment_test.go:185	0x10017ce74		54000823		BCC 65(PC)								
  peak_experiment_test.go:185	0x10017ce78		3d801c07		FMOVQ F7, 112(R0)							
  peak_experiment_test.go:186	0x10017ce7c		f100905f		CMP $36, R2								
  peak_experiment_test.go:186	0x10017ce80		54000783		BCC 60(PC)								
  peak_experiment_test.go:186	0x10017ce84		3d802008		FMOVQ F8, 128(R0)							
  peak_experiment_test.go:187	0x10017ce88		f100a05f		CMP $40, R2								
  peak_experiment_test.go:187	0x10017ce8c		540006e3		BCC 55(PC)								
  peak_experiment_test.go:187	0x10017ce90		3d802409		FMOVQ F9, 144(R0)							
  peak_experiment_test.go:188	0x10017ce94		f100b05f		CMP $44, R2								
  peak_experiment_test.go:188	0x10017ce98		54000643		BCC 50(PC)								
  peak_experiment_test.go:188	0x10017ce9c		3d80280a		FMOVQ F10, 160(R0)							
  peak_experiment_test.go:189	0x10017cea0		f100c05f		CMP $48, R2								
  peak_experiment_test.go:189	0x10017cea4		540005a3		BCC 45(PC)								
  peak_experiment_test.go:189	0x10017cea8		3d802c0b		FMOVQ F11, 176(R0)							
  peak_experiment_test.go:190	0x10017ceac		f100d05f		CMP $52, R2								
  peak_experiment_test.go:190	0x10017ceb0		54000503		BCC 40(PC)								
  peak_experiment_test.go:190	0x10017ceb4		3d80300c		FMOVQ F12, 192(R0)							
  peak_experiment_test.go:191	0x10017ceb8		f100e05f		CMP $56, R2								
  peak_experiment_test.go:191	0x10017cebc		54000463		BCC 35(PC)								
  peak_experiment_test.go:191	0x10017cec0		3d80340d		FMOVQ F13, 208(R0)							
  peak_experiment_test.go:192	0x10017cec4		f100f05f		CMP $60, R2								
  peak_experiment_test.go:192	0x10017cec8		540003c3		BCC 30(PC)								
  peak_experiment_test.go:192	0x10017cecc		3d80380e		FMOVQ F14, 224(R0)							
  peak_experiment_test.go:193	0x10017ced0		f101005f		CMP $64, R2								
  peak_experiment_test.go:193	0x10017ced4		54000323		BCC 25(PC)								
  peak_experiment_test.go:193	0x10017ced8		3d803c0f		FMOVQ F15, 240(R0)							
  peak_experiment_test.go:194	0x10017cedc		f101105f		CMP $68, R2								
  peak_experiment_test.go:194	0x10017cee0		54000283		BCC 20(PC)								
  peak_experiment_test.go:194	0x10017cee4		3d804010		FMOVQ F16, 256(R0)							
  peak_experiment_test.go:195	0x10017cee8		f101205f		CMP $72, R2								
  peak_experiment_test.go:195	0x10017ceec		540001e3		BCC 15(PC)								
  peak_experiment_test.go:195	0x10017cef0		3d804411		FMOVQ F17, 272(R0)							
  peak_experiment_test.go:196	0x10017cef4		f101305f		CMP $76, R2								
  peak_experiment_test.go:196	0x10017cef8		54000143		BCC 10(PC)								
  peak_experiment_test.go:196	0x10017cefc		3d804812		FMOVQ F18, 288(R0)							
  peak_experiment_test.go:197	0x10017cf00		f101405f		CMP $80, R2								
  peak_experiment_test.go:197	0x10017cf04		540000a3		BCC 5(PC)								
  peak_experiment_test.go:197	0x10017cf08		3d804c13		FMOVQ F19, 304(R0)							
  peak_experiment_test.go:198	0x10017cf0c		f85f83fd		MOVD -8(RSP), R29							
  peak_experiment_test.go:198	0x10017cf10		f84107fe		MOVD.P 16(RSP), R30							
  peak_experiment_test.go:198	0x10017cf14		d65f03c0		RET									
  peak_experiment_test.go:197	0x10017cf18		d2800a00		MOVD $80, R0								
  peak_experiment_test.go:197	0x10017cf1c		97fc2231		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:196	0x10017cf20		d2800980		MOVD $76, R0								
  peak_experiment_test.go:196	0x10017cf24		97fc222f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:195	0x10017cf28		d2800900		MOVD $72, R0								
  peak_experiment_test.go:195	0x10017cf2c		97fc222d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:194	0x10017cf30		d2800880		MOVD $68, R0								
  peak_experiment_test.go:194	0x10017cf34		97fc222b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:193	0x10017cf38		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:193	0x10017cf3c		97fc2229		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:192	0x10017cf40		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:192	0x10017cf44		97fc2227		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:191	0x10017cf48		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:191	0x10017cf4c		97fc2225		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:190	0x10017cf50		d2800680		MOVD $52, R0								
  peak_experiment_test.go:190	0x10017cf54		97fc2223		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:189	0x10017cf58		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:189	0x10017cf5c		97fc2221		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:188	0x10017cf60		d2800580		MOVD $44, R0								
  peak_experiment_test.go:188	0x10017cf64		97fc221f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:187	0x10017cf68		d2800500		MOVD $40, R0								
  peak_experiment_test.go:187	0x10017cf6c		97fc221d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:186	0x10017cf70		d2800480		MOVD $36, R0								
  peak_experiment_test.go:186	0x10017cf74		97fc221b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:185	0x10017cf78		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:185	0x10017cf7c		97fc2219		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:184	0x10017cf80		97fc2218		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:183	0x10017cf84		97fc2217		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:182	0x10017cf88		97fc2216		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:181	0x10017cf8c		97fc2215		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:180	0x10017cf90		97fc2214		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:179	0x10017cf94		97fc2213		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:178	0x10017cf98		97fc2212		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:155	0x10017cf9c		d2800e80		MOVD $116, R0								
  peak_experiment_test.go:155	0x10017cfa0		97fc2210		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:154	0x10017cfa4		b27c0be0		ORR $112, ZR, R0							
  peak_experiment_test.go:154	0x10017cfa8		97fc220e		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:153	0x10017cfac		d2800d80		MOVD $108, R0								
  peak_experiment_test.go:153	0x10017cfb0		97fc220c		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:152	0x10017cfb4		d2800d00		MOVD $104, R0								
  peak_experiment_test.go:152	0x10017cfb8		97fc220a		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:151	0x10017cfbc		d2800c80		MOVD $100, R0								
  peak_experiment_test.go:151	0x10017cfc0		97fc2208		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:150	0x10017cfc4		b27b07e0		ORR $96, ZR, R0								
  peak_experiment_test.go:150	0x10017cfc8		97fc2206		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:149	0x10017cfcc		d2800b80		MOVD $92, R0								
  peak_experiment_test.go:149	0x10017cfd0		97fc2204		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:148	0x10017cfd4		d2800b00		MOVD $88, R0								
  peak_experiment_test.go:148	0x10017cfd8		97fc2202		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:147	0x10017cfdc		d2800a80		MOVD $84, R0								
  peak_experiment_test.go:147	0x10017cfe0		97fc2200		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:146	0x10017cfe4		d2800a00		MOVD $80, R0								
  peak_experiment_test.go:146	0x10017cfe8		97fc21fe		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:145	0x10017cfec		d2800980		MOVD $76, R0								
  peak_experiment_test.go:145	0x10017cff0		97fc21fc		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:144	0x10017cff4		d2800900		MOVD $72, R0								
  peak_experiment_test.go:144	0x10017cff8		97fc21fa		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:143	0x10017cffc		d2800880		MOVD $68, R0								
  peak_experiment_test.go:143	0x10017d000		97fc21f8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:142	0x10017d004		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:142	0x10017d008		97fc21f6		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:141	0x10017d00c		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:141	0x10017d010		97fc21f4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:140	0x10017d014		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:140	0x10017d018		97fc21f2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:139	0x10017d01c		d2800680		MOVD $52, R0								
  peak_experiment_test.go:139	0x10017d020		97fc21f0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:138	0x10017d024		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:138	0x10017d028		97fc21ee		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:137	0x10017d02c		d2800580		MOVD $44, R0								
  peak_experiment_test.go:137	0x10017d030		97fc21ec		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:136	0x10017d034		d2800500		MOVD $40, R0								
  peak_experiment_test.go:136	0x10017d038		97fc21ea		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:135	0x10017d03c		d2800480		MOVD $36, R0								
  peak_experiment_test.go:135	0x10017d040		97fc21e8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:134	0x10017d044		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:134	0x10017d048		97fc21e6		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:133	0x10017d04c		97fc21e5		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:132	0x10017d050		97fc21e4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:131	0x10017d054		97fc21e3		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:130	0x10017d058		97fc21e2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:129	0x10017d05c		97fc21e1		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:128	0x10017d060		97fc21e0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:127	0x10017d064		97fc21df		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:127	0x10017d068		d503201f		NOOP									
  peak_experiment_test.go:126	0x10017d06c		a90087e0		STP (R0, R1), 8(RSP)							
  peak_experiment_test.go:126	0x10017d070		a9018fe2		STP (R2, R3), 24(RSP)							
  peak_experiment_test.go:126	0x10017d074		a90297e4		STP (R4, R5), 40(RSP)							
  peak_experiment_test.go:126	0x10017d078		f9001fe6		MOVD R6, 56(RSP)							
  peak_experiment_test.go:126	0x10017d07c		aa1e03e3		MOVD R30, R3								
  peak_experiment_test.go:126	0x10017d080		97fc1994		CALL runtime.morestack_noctxt.abi0(SB)					
  peak_experiment_test.go:126	0x10017d084		a94087e0		LDP 8(RSP), (R0, R1)							
  peak_experiment_test.go:126	0x10017d088		a9418fe2		LDP 24(RSP), (R2, R3)							
  peak_experiment_test.go:126	0x10017d08c		a94297e4		LDP 40(RSP), (R4, R5)							
  peak_experiment_test.go:126	0x10017d090		f9401fe6		MOVD 56(RSP), R6							
  peak_experiment_test.go:126	0x10017d094		17fffeeb		JMP github.com/GetStream/gophonic/internal/whispergemm.peak5x4(SB)	
  peak_experiment_test.go:126	0x10017d098		00000000		?									
  peak_experiment_test.go:126	0x10017d09c		00000000		?									

TEXT github.com/GetStream/gophonic/internal/whispergemm.peak3x6(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/peak_experiment_test.go
  peak_experiment_test.go:199	0x10017d0a0		f9400b90		MOVD 16(R28), R16							
  peak_experiment_test.go:199	0x10017d0a4		eb3063ff		CMP R16, RSP								
  peak_experiment_test.go:199	0x10017d0a8		54001e69		BLS 243(PC)								
  peak_experiment_test.go:199	0x10017d0ac		f81f0ffe		MOVD.W R30, -16(RSP)							
  peak_experiment_test.go:199	0x10017d0b0		f81f83fd		MOVD R29, -8(RSP)							
  peak_experiment_test.go:199	0x10017d0b4		d10023fd		SUB $8, RSP, R29							
  peak_experiment_test.go:199	0x10017d0b8		f9000fe0		MOVD R0, 24(RSP)							
  peak_experiment_test.go:199	0x10017d0bc		f9001be3		MOVD R3, 48(RSP)							
  peak_experiment_test.go:200	0x10017d0c0		f10010bf		CMP $4, R5								
  peak_experiment_test.go:200	0x10017d0c4		54001d43		BCC 234(PC)								
  peak_experiment_test.go:201	0x10017d0c8		f10020bf		CMP $8, R5								
  peak_experiment_test.go:201	0x10017d0cc		54001ce3		BCC 231(PC)								
  peak_experiment_test.go:202	0x10017d0d0		f10030bf		CMP $12, R5								
  peak_experiment_test.go:202	0x10017d0d4		54001c83		BCC 228(PC)								
  peak_experiment_test.go:203	0x10017d0d8		f10040bf		CMP $16, R5								
  peak_experiment_test.go:203	0x10017d0dc		54001c23		BCC 225(PC)								
  peak_experiment_test.go:204	0x10017d0e0		f10050bf		CMP $20, R5								
  peak_experiment_test.go:204	0x10017d0e4		54001bc3		BCC 222(PC)								
  peak_experiment_test.go:205	0x10017d0e8		f10060bf		CMP $24, R5								
  peak_experiment_test.go:205	0x10017d0ec		54001b63		BCC 219(PC)								
  peak_experiment_test.go:206	0x10017d0f0		f10070bf		CMP $28, R5								
  peak_experiment_test.go:206	0x10017d0f4		54001b03		BCC 216(PC)								
  peak_experiment_test.go:207	0x10017d0f8		f10080bf		CMP $32, R5								
  peak_experiment_test.go:207	0x10017d0fc		54001a83		BCC 212(PC)								
  peak_experiment_test.go:208	0x10017d100		f10090bf		CMP $36, R5								
  peak_experiment_test.go:208	0x10017d104		54001a03		BCC 208(PC)								
  peak_experiment_test.go:209	0x10017d108		f100a0bf		CMP $40, R5								
  peak_experiment_test.go:209	0x10017d10c		54001983		BCC 204(PC)								
  peak_experiment_test.go:210	0x10017d110		f100b0bf		CMP $44, R5								
  peak_experiment_test.go:210	0x10017d114		54001903		BCC 200(PC)								
  peak_experiment_test.go:211	0x10017d118		f100c0bf		CMP $48, R5								
  peak_experiment_test.go:211	0x10017d11c		54001883		BCC 196(PC)								
  peak_experiment_test.go:212	0x10017d120		f100d0bf		CMP $52, R5								
  peak_experiment_test.go:212	0x10017d124		54001803		BCC 192(PC)								
  peak_experiment_test.go:213	0x10017d128		f100e0bf		CMP $56, R5								
  peak_experiment_test.go:213	0x10017d12c		54001783		BCC 188(PC)								
  peak_experiment_test.go:214	0x10017d130		f100f0bf		CMP $60, R5								
  peak_experiment_test.go:214	0x10017d134		54001703		BCC 184(PC)								
  peak_experiment_test.go:215	0x10017d138		f10100bf		CMP $64, R5								
  peak_experiment_test.go:215	0x10017d13c		54001683		BCC 180(PC)								
  peak_experiment_test.go:216	0x10017d140		f10110bf		CMP $68, R5								
  peak_experiment_test.go:216	0x10017d144		54001603		BCC 176(PC)								
  peak_experiment_test.go:217	0x10017d148		f10120bf		CMP $72, R5								
  peak_experiment_test.go:217	0x10017d14c		54001583		BCC 172(PC)								
  peak_experiment_test.go:218	0x10017d150		f10130bf		CMP $76, R5								
  peak_experiment_test.go:218	0x10017d154		54001503		BCC 168(PC)								
  peak_experiment_test.go:219	0x10017d158		f10140bf		CMP $80, R5								
  peak_experiment_test.go:219	0x10017d15c		54001483		BCC 164(PC)								
  peak_experiment_test.go:220	0x10017d160		f10150bf		CMP $84, R5								
  peak_experiment_test.go:220	0x10017d164		54001403		BCC 160(PC)								
  peak_experiment_test.go:221	0x10017d168		f10160bf		CMP $88, R5								
  peak_experiment_test.go:221	0x10017d16c		54001383		BCC 156(PC)								
  peak_experiment_test.go:222	0x10017d170		f10170bf		CMP $92, R5								
  peak_experiment_test.go:222	0x10017d174		54001303		BCC 152(PC)								
  peak_experiment_test.go:223	0x10017d178		f10180bf		CMP $96, R5								
  peak_experiment_test.go:223	0x10017d17c		54001283		BCC 148(PC)								
  peak_experiment_test.go:224	0x10017d180		f10190bf		CMP $100, R5								
  peak_experiment_test.go:224	0x10017d184		54001203		BCC 144(PC)								
  peak_experiment_test.go:225	0x10017d188		f101a0bf		CMP $104, R5								
  peak_experiment_test.go:225	0x10017d18c		54001183		BCC 140(PC)								
  peak_experiment_test.go:226	0x10017d190		f101b0bf		CMP $108, R5								
  peak_experiment_test.go:226	0x10017d194		54001103		BCC 136(PC)								
  peak_experiment_test.go:200	0x10017d198		3dc00060		FMOVQ (R3), F0								
  peak_experiment_test.go:201	0x10017d19c		3dc00461		FMOVQ 16(R3), F1							
  peak_experiment_test.go:202	0x10017d1a0		3dc00862		FMOVQ 32(R3), F2							
  peak_experiment_test.go:203	0x10017d1a4		3dc00c63		FMOVQ 48(R3), F3							
  peak_experiment_test.go:204	0x10017d1a8		3dc01064		FMOVQ 64(R3), F4							
  peak_experiment_test.go:205	0x10017d1ac		3dc01465		FMOVQ 80(R3), F5							
  peak_experiment_test.go:206	0x10017d1b0		3dc01866		FMOVQ 96(R3), F6							
  peak_experiment_test.go:207	0x10017d1b4		3dc01c67		FMOVQ 112(R3), F7							
  peak_experiment_test.go:208	0x10017d1b8		3dc02068		FMOVQ 128(R3), F8							
  peak_experiment_test.go:209	0x10017d1bc		3dc02469		FMOVQ 144(R3), F9							
  peak_experiment_test.go:210	0x10017d1c0		3dc0286a		FMOVQ 160(R3), F10							
  peak_experiment_test.go:211	0x10017d1c4		3dc02c6b		FMOVQ 176(R3), F11							
  peak_experiment_test.go:212	0x10017d1c8		3dc0306c		FMOVQ 192(R3), F12							
  peak_experiment_test.go:213	0x10017d1cc		3dc0346d		FMOVQ 208(R3), F13							
  peak_experiment_test.go:214	0x10017d1d0		3dc0386e		FMOVQ 224(R3), F14							
  peak_experiment_test.go:215	0x10017d1d4		3dc03c6f		FMOVQ 240(R3), F15							
  peak_experiment_test.go:216	0x10017d1d8		3dc04070		FMOVQ 256(R3), F16							
  peak_experiment_test.go:217	0x10017d1dc		3dc04471		FMOVQ 272(R3), F17							
  peak_experiment_test.go:218	0x10017d1e0		3dc04872		FMOVQ 288(R3), F18							
  peak_experiment_test.go:219	0x10017d1e4		3dc04c73		FMOVQ 304(R3), F19							
  peak_experiment_test.go:220	0x10017d1e8		3dc05074		FMOVQ 320(R3), F20							
  peak_experiment_test.go:221	0x10017d1ec		3dc05475		FMOVQ 336(R3), F21							
  peak_experiment_test.go:222	0x10017d1f0		3dc05876		FMOVQ 352(R3), F22							
  peak_experiment_test.go:223	0x10017d1f4		3dc05c77		FMOVQ 368(R3), F23							
  peak_experiment_test.go:224	0x10017d1f8		3dc06078		FMOVQ 384(R3), F24							
  peak_experiment_test.go:225	0x10017d1fc		3dc06479		FMOVQ 400(R3), F25							
  peak_experiment_test.go:226	0x10017d200		3dc0687a		FMOVQ 416(R3), F26							
  peak_experiment_test.go:227	0x10017d204		14000014		JMP 20(PC)								
  peak_experiment_test.go:228	0x10017d208		4e38ce40		VFMLA V24.S4, V18.S4, V0.S4						
  peak_experiment_test.go:229	0x10017d20c		4e38ce61		VFMLA V24.S4, V19.S4, V1.S4						
  peak_experiment_test.go:230	0x10017d210		4e38ce82		VFMLA V24.S4, V20.S4, V2.S4						
  peak_experiment_test.go:231	0x10017d214		4e38cea3		VFMLA V24.S4, V21.S4, V3.S4						
  peak_experiment_test.go:232	0x10017d218		4e38cec4		VFMLA V24.S4, V22.S4, V4.S4						
  peak_experiment_test.go:233	0x10017d21c		4e38cee5		VFMLA V24.S4, V23.S4, V5.S4						
  peak_experiment_test.go:234	0x10017d220		4e39ce46		VFMLA V25.S4, V18.S4, V6.S4						
  peak_experiment_test.go:235	0x10017d224		4e39ce67		VFMLA V25.S4, V19.S4, V7.S4						
  peak_experiment_test.go:236	0x10017d228		4e39ce88		VFMLA V25.S4, V20.S4, V8.S4						
  peak_experiment_test.go:237	0x10017d22c		4e39cea9		VFMLA V25.S4, V21.S4, V9.S4						
  peak_experiment_test.go:238	0x10017d230		4e39ceca		VFMLA V25.S4, V22.S4, V10.S4						
  peak_experiment_test.go:239	0x10017d234		4e39ceeb		VFMLA V25.S4, V23.S4, V11.S4						
  peak_experiment_test.go:240	0x10017d238		4e3ace4c		VFMLA V26.S4, V18.S4, V12.S4						
  peak_experiment_test.go:241	0x10017d23c		4e3ace6d		VFMLA V26.S4, V19.S4, V13.S4						
  peak_experiment_test.go:242	0x10017d240		4e3ace8e		VFMLA V26.S4, V20.S4, V14.S4						
  peak_experiment_test.go:243	0x10017d244		4e3aceaf		VFMLA V26.S4, V21.S4, V15.S4						
  peak_experiment_test.go:244	0x10017d248		4e3aced0		VFMLA V26.S4, V22.S4, V16.S4						
  peak_experiment_test.go:245	0x10017d24c		4e3acef1		VFMLA V26.S4, V23.S4, V17.S4						
  peak_experiment_test.go:227	0x10017d250		d10004c6		SUB $1, R6, R6								
  peak_experiment_test.go:227	0x10017d254		f10000df		CMP $0, R6								
  peak_experiment_test.go:227	0x10017d258		54fffd8c		BGT -20(PC)								
  peak_experiment_test.go:247	0x10017d25c		f100105f		CMP $4, R2								
  peak_experiment_test.go:247	0x10017d260		54000a83		BCC 84(PC)								
  peak_experiment_test.go:247	0x10017d264		3d800000		FMOVQ F0, (R0)								
  peak_experiment_test.go:248	0x10017d268		f100205f		CMP $8, R2								
  peak_experiment_test.go:248	0x10017d26c		54000a03		BCC 80(PC)								
  peak_experiment_test.go:248	0x10017d270		3d800401		FMOVQ F1, 16(R0)							
  peak_experiment_test.go:249	0x10017d274		f100305f		CMP $12, R2								
  peak_experiment_test.go:249	0x10017d278		54000983		BCC 76(PC)								
  peak_experiment_test.go:249	0x10017d27c		3d800802		FMOVQ F2, 32(R0)							
  peak_experiment_test.go:250	0x10017d280		f100405f		CMP $16, R2								
  peak_experiment_test.go:250	0x10017d284		54000903		BCC 72(PC)								
  peak_experiment_test.go:250	0x10017d288		3d800c03		FMOVQ F3, 48(R0)							
  peak_experiment_test.go:251	0x10017d28c		f100505f		CMP $20, R2								
  peak_experiment_test.go:251	0x10017d290		54000883		BCC 68(PC)								
  peak_experiment_test.go:251	0x10017d294		3d801004		FMOVQ F4, 64(R0)							
  peak_experiment_test.go:252	0x10017d298		f100605f		CMP $24, R2								
  peak_experiment_test.go:252	0x10017d29c		54000803		BCC 64(PC)								
  peak_experiment_test.go:252	0x10017d2a0		3d801405		FMOVQ F5, 80(R0)							
  peak_experiment_test.go:253	0x10017d2a4		f100705f		CMP $28, R2								
  peak_experiment_test.go:253	0x10017d2a8		54000783		BCC 60(PC)								
  peak_experiment_test.go:253	0x10017d2ac		3d801806		FMOVQ F6, 96(R0)							
  peak_experiment_test.go:254	0x10017d2b0		f100805f		CMP $32, R2								
  peak_experiment_test.go:254	0x10017d2b4		540006e3		BCC 55(PC)								
  peak_experiment_test.go:254	0x10017d2b8		3d801c07		FMOVQ F7, 112(R0)							
  peak_experiment_test.go:255	0x10017d2bc		f100905f		CMP $36, R2								
  peak_experiment_test.go:255	0x10017d2c0		54000643		BCC 50(PC)								
  peak_experiment_test.go:255	0x10017d2c4		3d802008		FMOVQ F8, 128(R0)							
  peak_experiment_test.go:256	0x10017d2c8		f100a05f		CMP $40, R2								
  peak_experiment_test.go:256	0x10017d2cc		540005a3		BCC 45(PC)								
  peak_experiment_test.go:256	0x10017d2d0		3d802409		FMOVQ F9, 144(R0)							
  peak_experiment_test.go:257	0x10017d2d4		f100b05f		CMP $44, R2								
  peak_experiment_test.go:257	0x10017d2d8		54000503		BCC 40(PC)								
  peak_experiment_test.go:257	0x10017d2dc		3d80280a		FMOVQ F10, 160(R0)							
  peak_experiment_test.go:258	0x10017d2e0		f100c05f		CMP $48, R2								
  peak_experiment_test.go:258	0x10017d2e4		54000463		BCC 35(PC)								
  peak_experiment_test.go:258	0x10017d2e8		3d802c0b		FMOVQ F11, 176(R0)							
  peak_experiment_test.go:259	0x10017d2ec		f100d05f		CMP $52, R2								
  peak_experiment_test.go:259	0x10017d2f0		540003c3		BCC 30(PC)								
  peak_experiment_test.go:259	0x10017d2f4		3d80300c		FMOVQ F12, 192(R0)							
  peak_experiment_test.go:260	0x10017d2f8		f100e05f		CMP $56, R2								
  peak_experiment_test.go:260	0x10017d2fc		54000323		BCC 25(PC)								
  peak_experiment_test.go:260	0x10017d300		3d80340d		FMOVQ F13, 208(R0)							
  peak_experiment_test.go:261	0x10017d304		f100f05f		CMP $60, R2								
  peak_experiment_test.go:261	0x10017d308		54000283		BCC 20(PC)								
  peak_experiment_test.go:261	0x10017d30c		3d80380e		FMOVQ F14, 224(R0)							
  peak_experiment_test.go:262	0x10017d310		f101005f		CMP $64, R2								
  peak_experiment_test.go:262	0x10017d314		540001e3		BCC 15(PC)								
  peak_experiment_test.go:262	0x10017d318		3d803c0f		FMOVQ F15, 240(R0)							
  peak_experiment_test.go:263	0x10017d31c		f101105f		CMP $68, R2								
  peak_experiment_test.go:263	0x10017d320		54000143		BCC 10(PC)								
  peak_experiment_test.go:263	0x10017d324		3d804010		FMOVQ F16, 256(R0)							
  peak_experiment_test.go:264	0x10017d328		f101205f		CMP $72, R2								
  peak_experiment_test.go:264	0x10017d32c		540000a3		BCC 5(PC)								
  peak_experiment_test.go:264	0x10017d330		3d804411		FMOVQ F17, 272(R0)							
  peak_experiment_test.go:265	0x10017d334		f85f83fd		MOVD -8(RSP), R29							
  peak_experiment_test.go:265	0x10017d338		f84107fe		MOVD.P 16(RSP), R30							
  peak_experiment_test.go:265	0x10017d33c		d65f03c0		RET									
  peak_experiment_test.go:264	0x10017d340		d2800900		MOVD $72, R0								
  peak_experiment_test.go:264	0x10017d344		97fc2127		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:263	0x10017d348		d2800880		MOVD $68, R0								
  peak_experiment_test.go:263	0x10017d34c		97fc2125		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:262	0x10017d350		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:262	0x10017d354		97fc2123		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:261	0x10017d358		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:261	0x10017d35c		97fc2121		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:260	0x10017d360		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:260	0x10017d364		97fc211f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:259	0x10017d368		d2800680		MOVD $52, R0								
  peak_experiment_test.go:259	0x10017d36c		97fc211d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:258	0x10017d370		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:258	0x10017d374		97fc211b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:257	0x10017d378		d2800580		MOVD $44, R0								
  peak_experiment_test.go:257	0x10017d37c		97fc2119		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:256	0x10017d380		d2800500		MOVD $40, R0								
  peak_experiment_test.go:256	0x10017d384		97fc2117		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:255	0x10017d388		d2800480		MOVD $36, R0								
  peak_experiment_test.go:255	0x10017d38c		97fc2115		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:254	0x10017d390		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:254	0x10017d394		97fc2113		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:253	0x10017d398		97fc2112		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:252	0x10017d39c		97fc2111		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:251	0x10017d3a0		97fc2110		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:250	0x10017d3a4		97fc210f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:249	0x10017d3a8		97fc210e		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:248	0x10017d3ac		97fc210d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:247	0x10017d3b0		97fc210c		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:226	0x10017d3b4		d2800d80		MOVD $108, R0								
  peak_experiment_test.go:226	0x10017d3b8		97fc210a		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:225	0x10017d3bc		d2800d00		MOVD $104, R0								
  peak_experiment_test.go:225	0x10017d3c0		97fc2108		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:224	0x10017d3c4		d2800c80		MOVD $100, R0								
  peak_experiment_test.go:224	0x10017d3c8		97fc2106		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:223	0x10017d3cc		b27b07e0		ORR $96, ZR, R0								
  peak_experiment_test.go:223	0x10017d3d0		97fc2104		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:222	0x10017d3d4		d2800b80		MOVD $92, R0								
  peak_experiment_test.go:222	0x10017d3d8		97fc2102		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:221	0x10017d3dc		d2800b00		MOVD $88, R0								
  peak_experiment_test.go:221	0x10017d3e0		97fc2100		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:220	0x10017d3e4		d2800a80		MOVD $84, R0								
  peak_experiment_test.go:220	0x10017d3e8		97fc20fe		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:219	0x10017d3ec		d2800a00		MOVD $80, R0								
  peak_experiment_test.go:219	0x10017d3f0		97fc20fc		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:218	0x10017d3f4		d2800980		MOVD $76, R0								
  peak_experiment_test.go:218	0x10017d3f8		97fc20fa		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:217	0x10017d3fc		d2800900		MOVD $72, R0								
  peak_experiment_test.go:217	0x10017d400		97fc20f8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:216	0x10017d404		d2800880		MOVD $68, R0								
  peak_experiment_test.go:216	0x10017d408		97fc20f6		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:215	0x10017d40c		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:215	0x10017d410		97fc20f4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:214	0x10017d414		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:214	0x10017d418		97fc20f2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:213	0x10017d41c		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:213	0x10017d420		97fc20f0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:212	0x10017d424		d2800680		MOVD $52, R0								
  peak_experiment_test.go:212	0x10017d428		97fc20ee		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:211	0x10017d42c		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:211	0x10017d430		97fc20ec		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:210	0x10017d434		d2800580		MOVD $44, R0								
  peak_experiment_test.go:210	0x10017d438		97fc20ea		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:209	0x10017d43c		d2800500		MOVD $40, R0								
  peak_experiment_test.go:209	0x10017d440		97fc20e8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:208	0x10017d444		d2800480		MOVD $36, R0								
  peak_experiment_test.go:208	0x10017d448		97fc20e6		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:207	0x10017d44c		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:207	0x10017d450		97fc20e4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:206	0x10017d454		97fc20e3		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:205	0x10017d458		97fc20e2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:204	0x10017d45c		97fc20e1		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:203	0x10017d460		97fc20e0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:202	0x10017d464		97fc20df		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:201	0x10017d468		97fc20de		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:200	0x10017d46c		97fc20dd		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:200	0x10017d470		d503201f		NOOP									
  peak_experiment_test.go:199	0x10017d474		a90087e0		STP (R0, R1), 8(RSP)							
  peak_experiment_test.go:199	0x10017d478		a9018fe2		STP (R2, R3), 24(RSP)							
  peak_experiment_test.go:199	0x10017d47c		a90297e4		STP (R4, R5), 40(RSP)							
  peak_experiment_test.go:199	0x10017d480		f9001fe6		MOVD R6, 56(RSP)							
  peak_experiment_test.go:199	0x10017d484		aa1e03e3		MOVD R30, R3								
  peak_experiment_test.go:199	0x10017d488		97fc1892		CALL runtime.morestack_noctxt.abi0(SB)					
  peak_experiment_test.go:199	0x10017d48c		a94087e0		LDP 8(RSP), (R0, R1)							
  peak_experiment_test.go:199	0x10017d490		a9418fe2		LDP 24(RSP), (R2, R3)							
  peak_experiment_test.go:199	0x10017d494		a94297e4		LDP 40(RSP), (R4, R5)							
  peak_experiment_test.go:199	0x10017d498		f9401fe6		MOVD 56(RSP), R6							
  peak_experiment_test.go:199	0x10017d49c		17ffff01		JMP github.com/GetStream/gophonic/internal/whispergemm.peak3x6(SB)	

TEXT github.com/GetStream/gophonic/internal/whispergemm.peak7x3(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/peak_experiment_test.go
  peak_experiment_test.go:266	0x10017d4a0		f9400b90		MOVD 16(R28), R16							
  peak_experiment_test.go:266	0x10017d4a4		eb3063ff		CMP R16, RSP								
  peak_experiment_test.go:266	0x10017d4a8		54002329		BLS 281(PC)								
  peak_experiment_test.go:266	0x10017d4ac		f81f0ffe		MOVD.W R30, -16(RSP)							
  peak_experiment_test.go:266	0x10017d4b0		f81f83fd		MOVD R29, -8(RSP)							
  peak_experiment_test.go:266	0x10017d4b4		d10023fd		SUB $8, RSP, R29							
  peak_experiment_test.go:266	0x10017d4b8		f9000fe0		MOVD R0, 24(RSP)							
  peak_experiment_test.go:266	0x10017d4bc		f9001be3		MOVD R3, 48(RSP)							
  peak_experiment_test.go:267	0x10017d4c0		f10010bf		CMP $4, R5								
  peak_experiment_test.go:267	0x10017d4c4		54002203		BCC 272(PC)								
  peak_experiment_test.go:268	0x10017d4c8		f10020bf		CMP $8, R5								
  peak_experiment_test.go:268	0x10017d4cc		540021a3		BCC 269(PC)								
  peak_experiment_test.go:269	0x10017d4d0		f10030bf		CMP $12, R5								
  peak_experiment_test.go:269	0x10017d4d4		54002143		BCC 266(PC)								
  peak_experiment_test.go:270	0x10017d4d8		f10040bf		CMP $16, R5								
  peak_experiment_test.go:270	0x10017d4dc		540020e3		BCC 263(PC)								
  peak_experiment_test.go:271	0x10017d4e0		f10050bf		CMP $20, R5								
  peak_experiment_test.go:271	0x10017d4e4		54002083		BCC 260(PC)								
  peak_experiment_test.go:272	0x10017d4e8		f10060bf		CMP $24, R5								
  peak_experiment_test.go:272	0x10017d4ec		54002023		BCC 257(PC)								
  peak_experiment_test.go:273	0x10017d4f0		f10070bf		CMP $28, R5								
  peak_experiment_test.go:273	0x10017d4f4		54001fc3		BCC 254(PC)								
  peak_experiment_test.go:274	0x10017d4f8		f10080bf		CMP $32, R5								
  peak_experiment_test.go:274	0x10017d4fc		54001f43		BCC 250(PC)								
  peak_experiment_test.go:275	0x10017d500		f10090bf		CMP $36, R5								
  peak_experiment_test.go:275	0x10017d504		54001ec3		BCC 246(PC)								
  peak_experiment_test.go:276	0x10017d508		f100a0bf		CMP $40, R5								
  peak_experiment_test.go:276	0x10017d50c		54001e43		BCC 242(PC)								
  peak_experiment_test.go:277	0x10017d510		f100b0bf		CMP $44, R5								
  peak_experiment_test.go:277	0x10017d514		54001dc3		BCC 238(PC)								
  peak_experiment_test.go:278	0x10017d518		f100c0bf		CMP $48, R5								
  peak_experiment_test.go:278	0x10017d51c		54001d43		BCC 234(PC)								
  peak_experiment_test.go:279	0x10017d520		f100d0bf		CMP $52, R5								
  peak_experiment_test.go:279	0x10017d524		54001cc3		BCC 230(PC)								
  peak_experiment_test.go:280	0x10017d528		f100e0bf		CMP $56, R5								
  peak_experiment_test.go:280	0x10017d52c		54001c43		BCC 226(PC)								
  peak_experiment_test.go:281	0x10017d530		f100f0bf		CMP $60, R5								
  peak_experiment_test.go:281	0x10017d534		54001bc3		BCC 222(PC)								
  peak_experiment_test.go:282	0x10017d538		f10100bf		CMP $64, R5								
  peak_experiment_test.go:282	0x10017d53c		54001b43		BCC 218(PC)								
  peak_experiment_test.go:283	0x10017d540		f10110bf		CMP $68, R5								
  peak_experiment_test.go:283	0x10017d544		54001ac3		BCC 214(PC)								
  peak_experiment_test.go:284	0x10017d548		f10120bf		CMP $72, R5								
  peak_experiment_test.go:284	0x10017d54c		54001a43		BCC 210(PC)								
  peak_experiment_test.go:285	0x10017d550		f10130bf		CMP $76, R5								
  peak_experiment_test.go:285	0x10017d554		540019c3		BCC 206(PC)								
  peak_experiment_test.go:286	0x10017d558		f10140bf		CMP $80, R5								
  peak_experiment_test.go:286	0x10017d55c		54001943		BCC 202(PC)								
  peak_experiment_test.go:287	0x10017d560		f10150bf		CMP $84, R5								
  peak_experiment_test.go:287	0x10017d564		540018c3		BCC 198(PC)								
  peak_experiment_test.go:288	0x10017d568		f10160bf		CMP $88, R5								
  peak_experiment_test.go:288	0x10017d56c		54001843		BCC 194(PC)								
  peak_experiment_test.go:289	0x10017d570		f10170bf		CMP $92, R5								
  peak_experiment_test.go:289	0x10017d574		540017c3		BCC 190(PC)								
  peak_experiment_test.go:290	0x10017d578		f10180bf		CMP $96, R5								
  peak_experiment_test.go:290	0x10017d57c		54001743		BCC 186(PC)								
  peak_experiment_test.go:291	0x10017d580		f10190bf		CMP $100, R5								
  peak_experiment_test.go:291	0x10017d584		540016c3		BCC 182(PC)								
  peak_experiment_test.go:292	0x10017d588		f101a0bf		CMP $104, R5								
  peak_experiment_test.go:292	0x10017d58c		54001643		BCC 178(PC)								
  peak_experiment_test.go:293	0x10017d590		f101b0bf		CMP $108, R5								
  peak_experiment_test.go:293	0x10017d594		540015c3		BCC 174(PC)								
  peak_experiment_test.go:294	0x10017d598		f101c0bf		CMP $112, R5								
  peak_experiment_test.go:294	0x10017d59c		54001543		BCC 170(PC)								
  peak_experiment_test.go:295	0x10017d5a0		f101d0bf		CMP $116, R5								
  peak_experiment_test.go:295	0x10017d5a4		540014c3		BCC 166(PC)								
  peak_experiment_test.go:296	0x10017d5a8		f101e0bf		CMP $120, R5								
  peak_experiment_test.go:296	0x10017d5ac		54001443		BCC 162(PC)								
  peak_experiment_test.go:297	0x10017d5b0		f101f0bf		CMP $124, R5								
  peak_experiment_test.go:297	0x10017d5b4		540013c3		BCC 158(PC)								
  peak_experiment_test.go:267	0x10017d5b8		3dc00060		FMOVQ (R3), F0								
  peak_experiment_test.go:268	0x10017d5bc		3dc00461		FMOVQ 16(R3), F1							
  peak_experiment_test.go:269	0x10017d5c0		3dc00862		FMOVQ 32(R3), F2							
  peak_experiment_test.go:270	0x10017d5c4		3dc00c63		FMOVQ 48(R3), F3							
  peak_experiment_test.go:271	0x10017d5c8		3dc01064		FMOVQ 64(R3), F4							
  peak_experiment_test.go:272	0x10017d5cc		3dc01465		FMOVQ 80(R3), F5							
  peak_experiment_test.go:273	0x10017d5d0		3dc01866		FMOVQ 96(R3), F6							
  peak_experiment_test.go:274	0x10017d5d4		3dc01c67		FMOVQ 112(R3), F7							
  peak_experiment_test.go:275	0x10017d5d8		3dc02068		FMOVQ 128(R3), F8							
  peak_experiment_test.go:276	0x10017d5dc		3dc02469		FMOVQ 144(R3), F9							
  peak_experiment_test.go:277	0x10017d5e0		3dc0286a		FMOVQ 160(R3), F10							
  peak_experiment_test.go:278	0x10017d5e4		3dc02c6b		FMOVQ 176(R3), F11							
  peak_experiment_test.go:279	0x10017d5e8		3dc0306c		FMOVQ 192(R3), F12							
  peak_experiment_test.go:280	0x10017d5ec		3dc0346d		FMOVQ 208(R3), F13							
  peak_experiment_test.go:281	0x10017d5f0		3dc0386e		FMOVQ 224(R3), F14							
  peak_experiment_test.go:282	0x10017d5f4		3dc03c6f		FMOVQ 240(R3), F15							
  peak_experiment_test.go:283	0x10017d5f8		3dc04070		FMOVQ 256(R3), F16							
  peak_experiment_test.go:284	0x10017d5fc		3dc04471		FMOVQ 272(R3), F17							
  peak_experiment_test.go:285	0x10017d600		3dc04872		FMOVQ 288(R3), F18							
  peak_experiment_test.go:286	0x10017d604		3dc04c73		FMOVQ 304(R3), F19							
  peak_experiment_test.go:287	0x10017d608		3dc05074		FMOVQ 320(R3), F20							
  peak_experiment_test.go:288	0x10017d60c		3dc05475		FMOVQ 336(R3), F21							
  peak_experiment_test.go:289	0x10017d610		3dc05876		FMOVQ 352(R3), F22							
  peak_experiment_test.go:290	0x10017d614		3dc05c77		FMOVQ 368(R3), F23							
  peak_experiment_test.go:291	0x10017d618		3dc06078		FMOVQ 384(R3), F24							
  peak_experiment_test.go:292	0x10017d61c		3dc06479		FMOVQ 400(R3), F25							
  peak_experiment_test.go:293	0x10017d620		3dc0687a		FMOVQ 416(R3), F26							
  peak_experiment_test.go:294	0x10017d624		3dc06c7b		FMOVQ 432(R3), F27							
  peak_experiment_test.go:295	0x10017d628		3dc0707c		FMOVQ 448(R3), F28							
  peak_experiment_test.go:296	0x10017d62c		3dc0747d		FMOVQ 464(R3), F29							
  peak_experiment_test.go:297	0x10017d630		3dc0787e		FMOVQ 480(R3), F30							
  peak_experiment_test.go:298	0x10017d634		14000017		JMP 23(PC)								
  peak_experiment_test.go:299	0x10017d638		4e38cea0		VFMLA V24.S4, V21.S4, V0.S4						
  peak_experiment_test.go:300	0x10017d63c		4e38cec1		VFMLA V24.S4, V22.S4, V1.S4						
  peak_experiment_test.go:301	0x10017d640		4e38cee2		VFMLA V24.S4, V23.S4, V2.S4						
  peak_experiment_test.go:302	0x10017d644		4e39cea3		VFMLA V25.S4, V21.S4, V3.S4						
  peak_experiment_test.go:303	0x10017d648		4e39cec4		VFMLA V25.S4, V22.S4, V4.S4						
  peak_experiment_test.go:304	0x10017d64c		4e39cee5		VFMLA V25.S4, V23.S4, V5.S4						
  peak_experiment_test.go:305	0x10017d650		4e3acea6		VFMLA V26.S4, V21.S4, V6.S4						
  peak_experiment_test.go:306	0x10017d654		4e3acec7		VFMLA V26.S4, V22.S4, V7.S4						
  peak_experiment_test.go:307	0x10017d658		4e3acee8		VFMLA V26.S4, V23.S4, V8.S4						
  peak_experiment_test.go:308	0x10017d65c		4e3bcea9		VFMLA V27.S4, V21.S4, V9.S4						
  peak_experiment_test.go:309	0x10017d660		4e3bceca		VFMLA V27.S4, V22.S4, V10.S4						
  peak_experiment_test.go:310	0x10017d664		4e3bceeb		VFMLA V27.S4, V23.S4, V11.S4						
  peak_experiment_test.go:311	0x10017d668		4e3cceac		VFMLA V28.S4, V21.S4, V12.S4						
  peak_experiment_test.go:312	0x10017d66c		4e3ccecd		VFMLA V28.S4, V22.S4, V13.S4						
  peak_experiment_test.go:313	0x10017d670		4e3cceee		VFMLA V28.S4, V23.S4, V14.S4						
  peak_experiment_test.go:314	0x10017d674		4e3dceaf		VFMLA V29.S4, V21.S4, V15.S4						
  peak_experiment_test.go:315	0x10017d678		4e3dced0		VFMLA V29.S4, V22.S4, V16.S4						
  peak_experiment_test.go:316	0x10017d67c		4e3dcef1		VFMLA V29.S4, V23.S4, V17.S4						
  peak_experiment_test.go:317	0x10017d680		4e3eceb2		VFMLA V30.S4, V21.S4, V18.S4						
  peak_experiment_test.go:318	0x10017d684		4e3eced3		VFMLA V30.S4, V22.S4, V19.S4						
  peak_experiment_test.go:319	0x10017d688		4e3ecef4		VFMLA V30.S4, V23.S4, V20.S4						
  peak_experiment_test.go:298	0x10017d68c		d10004c6		SUB $1, R6, R6								
  peak_experiment_test.go:298	0x10017d690		f10000df		CMP $0, R6								
  peak_experiment_test.go:298	0x10017d694		54fffd2c		BGT -23(PC)								
  peak_experiment_test.go:321	0x10017d698		f100105f		CMP $4, R2								
  peak_experiment_test.go:321	0x10017d69c		54000c63		BCC 99(PC)								
  peak_experiment_test.go:321	0x10017d6a0		3d800000		FMOVQ F0, (R0)								
  peak_experiment_test.go:322	0x10017d6a4		f100205f		CMP $8, R2								
  peak_experiment_test.go:322	0x10017d6a8		54000be3		BCC 95(PC)								
  peak_experiment_test.go:322	0x10017d6ac		3d800401		FMOVQ F1, 16(R0)							
  peak_experiment_test.go:323	0x10017d6b0		f100305f		CMP $12, R2								
  peak_experiment_test.go:323	0x10017d6b4		54000b63		BCC 91(PC)								
  peak_experiment_test.go:323	0x10017d6b8		3d800802		FMOVQ F2, 32(R0)							
  peak_experiment_test.go:324	0x10017d6bc		f100405f		CMP $16, R2								
  peak_experiment_test.go:324	0x10017d6c0		54000ae3		BCC 87(PC)								
  peak_experiment_test.go:324	0x10017d6c4		3d800c03		FMOVQ F3, 48(R0)							
  peak_experiment_test.go:325	0x10017d6c8		f100505f		CMP $20, R2								
  peak_experiment_test.go:325	0x10017d6cc		54000a63		BCC 83(PC)								
  peak_experiment_test.go:325	0x10017d6d0		3d801004		FMOVQ F4, 64(R0)							
  peak_experiment_test.go:326	0x10017d6d4		f100605f		CMP $24, R2								
  peak_experiment_test.go:326	0x10017d6d8		540009e3		BCC 79(PC)								
  peak_experiment_test.go:326	0x10017d6dc		3d801405		FMOVQ F5, 80(R0)							
  peak_experiment_test.go:327	0x10017d6e0		f100705f		CMP $28, R2								
  peak_experiment_test.go:327	0x10017d6e4		54000963		BCC 75(PC)								
  peak_experiment_test.go:327	0x10017d6e8		3d801806		FMOVQ F6, 96(R0)							
  peak_experiment_test.go:328	0x10017d6ec		f100805f		CMP $32, R2								
  peak_experiment_test.go:328	0x10017d6f0		540008c3		BCC 70(PC)								
  peak_experiment_test.go:328	0x10017d6f4		3d801c07		FMOVQ F7, 112(R0)							
  peak_experiment_test.go:329	0x10017d6f8		f100905f		CMP $36, R2								
  peak_experiment_test.go:329	0x10017d6fc		54000823		BCC 65(PC)								
  peak_experiment_test.go:329	0x10017d700		3d802008		FMOVQ F8, 128(R0)							
  peak_experiment_test.go:330	0x10017d704		f100a05f		CMP $40, R2								
  peak_experiment_test.go:330	0x10017d708		54000783		BCC 60(PC)								
  peak_experiment_test.go:330	0x10017d70c		3d802409		FMOVQ F9, 144(R0)							
  peak_experiment_test.go:331	0x10017d710		f100b05f		CMP $44, R2								
  peak_experiment_test.go:331	0x10017d714		540006e3		BCC 55(PC)								
  peak_experiment_test.go:331	0x10017d718		3d80280a		FMOVQ F10, 160(R0)							
  peak_experiment_test.go:332	0x10017d71c		f100c05f		CMP $48, R2								
  peak_experiment_test.go:332	0x10017d720		54000643		BCC 50(PC)								
  peak_experiment_test.go:332	0x10017d724		3d802c0b		FMOVQ F11, 176(R0)							
  peak_experiment_test.go:333	0x10017d728		f100d05f		CMP $52, R2								
  peak_experiment_test.go:333	0x10017d72c		540005a3		BCC 45(PC)								
  peak_experiment_test.go:333	0x10017d730		3d80300c		FMOVQ F12, 192(R0)							
  peak_experiment_test.go:334	0x10017d734		f100e05f		CMP $56, R2								
  peak_experiment_test.go:334	0x10017d738		54000503		BCC 40(PC)								
  peak_experiment_test.go:334	0x10017d73c		3d80340d		FMOVQ F13, 208(R0)							
  peak_experiment_test.go:335	0x10017d740		f100f05f		CMP $60, R2								
  peak_experiment_test.go:335	0x10017d744		54000463		BCC 35(PC)								
  peak_experiment_test.go:335	0x10017d748		3d80380e		FMOVQ F14, 224(R0)							
  peak_experiment_test.go:336	0x10017d74c		f101005f		CMP $64, R2								
  peak_experiment_test.go:336	0x10017d750		540003c3		BCC 30(PC)								
  peak_experiment_test.go:336	0x10017d754		3d803c0f		FMOVQ F15, 240(R0)							
  peak_experiment_test.go:337	0x10017d758		f101105f		CMP $68, R2								
  peak_experiment_test.go:337	0x10017d75c		54000323		BCC 25(PC)								
  peak_experiment_test.go:337	0x10017d760		3d804010		FMOVQ F16, 256(R0)							
  peak_experiment_test.go:338	0x10017d764		f101205f		CMP $72, R2								
  peak_experiment_test.go:338	0x10017d768		54000283		BCC 20(PC)								
  peak_experiment_test.go:338	0x10017d76c		3d804411		FMOVQ F17, 272(R0)							
  peak_experiment_test.go:339	0x10017d770		f101305f		CMP $76, R2								
  peak_experiment_test.go:339	0x10017d774		540001e3		BCC 15(PC)								
  peak_experiment_test.go:339	0x10017d778		3d804812		FMOVQ F18, 288(R0)							
  peak_experiment_test.go:340	0x10017d77c		f101405f		CMP $80, R2								
  peak_experiment_test.go:340	0x10017d780		54000143		BCC 10(PC)								
  peak_experiment_test.go:340	0x10017d784		3d804c13		FMOVQ F19, 304(R0)							
  peak_experiment_test.go:341	0x10017d788		f101505f		CMP $84, R2								
  peak_experiment_test.go:341	0x10017d78c		540000a3		BCC 5(PC)								
  peak_experiment_test.go:341	0x10017d790		3d805014		FMOVQ F20, 320(R0)							
  peak_experiment_test.go:342	0x10017d794		f85f83fd		MOVD -8(RSP), R29							
  peak_experiment_test.go:342	0x10017d798		f84107fe		MOVD.P 16(RSP), R30							
  peak_experiment_test.go:342	0x10017d79c		d65f03c0		RET									
  peak_experiment_test.go:341	0x10017d7a0		d2800a80		MOVD $84, R0								
  peak_experiment_test.go:341	0x10017d7a4		97fc200f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:340	0x10017d7a8		d2800a00		MOVD $80, R0								
  peak_experiment_test.go:340	0x10017d7ac		97fc200d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:339	0x10017d7b0		d2800980		MOVD $76, R0								
  peak_experiment_test.go:339	0x10017d7b4		97fc200b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:338	0x10017d7b8		d2800900		MOVD $72, R0								
  peak_experiment_test.go:338	0x10017d7bc		97fc2009		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:337	0x10017d7c0		d2800880		MOVD $68, R0								
  peak_experiment_test.go:337	0x10017d7c4		97fc2007		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:336	0x10017d7c8		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:336	0x10017d7cc		97fc2005		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:335	0x10017d7d0		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:335	0x10017d7d4		97fc2003		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:334	0x10017d7d8		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:334	0x10017d7dc		97fc2001		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:333	0x10017d7e0		d2800680		MOVD $52, R0								
  peak_experiment_test.go:333	0x10017d7e4		97fc1fff		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:332	0x10017d7e8		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:332	0x10017d7ec		97fc1ffd		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:331	0x10017d7f0		d2800580		MOVD $44, R0								
  peak_experiment_test.go:331	0x10017d7f4		97fc1ffb		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:330	0x10017d7f8		d2800500		MOVD $40, R0								
  peak_experiment_test.go:330	0x10017d7fc		97fc1ff9		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:329	0x10017d800		d2800480		MOVD $36, R0								
  peak_experiment_test.go:329	0x10017d804		97fc1ff7		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:328	0x10017d808		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:328	0x10017d80c		97fc1ff5		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:327	0x10017d810		97fc1ff4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:326	0x10017d814		97fc1ff3		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:325	0x10017d818		97fc1ff2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:324	0x10017d81c		97fc1ff1		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:323	0x10017d820		97fc1ff0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:322	0x10017d824		97fc1fef		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:321	0x10017d828		97fc1fee		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:297	0x10017d82c		b27e13e0		ORR $124, ZR, R0							
  peak_experiment_test.go:297	0x10017d830		97fc1fec		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:296	0x10017d834		b27d0fe0		ORR $120, ZR, R0							
  peak_experiment_test.go:296	0x10017d838		97fc1fea		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:295	0x10017d83c		d2800e80		MOVD $116, R0								
  peak_experiment_test.go:295	0x10017d840		97fc1fe8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:294	0x10017d844		b27c0be0		ORR $112, ZR, R0							
  peak_experiment_test.go:294	0x10017d848		97fc1fe6		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:293	0x10017d84c		d2800d80		MOVD $108, R0								
  peak_experiment_test.go:293	0x10017d850		97fc1fe4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:292	0x10017d854		d2800d00		MOVD $104, R0								
  peak_experiment_test.go:292	0x10017d858		97fc1fe2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:291	0x10017d85c		d2800c80		MOVD $100, R0								
  peak_experiment_test.go:291	0x10017d860		97fc1fe0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:290	0x10017d864		b27b07e0		ORR $96, ZR, R0								
  peak_experiment_test.go:290	0x10017d868		97fc1fde		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:289	0x10017d86c		d2800b80		MOVD $92, R0								
  peak_experiment_test.go:289	0x10017d870		97fc1fdc		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:288	0x10017d874		d2800b00		MOVD $88, R0								
  peak_experiment_test.go:288	0x10017d878		97fc1fda		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:287	0x10017d87c		d2800a80		MOVD $84, R0								
  peak_experiment_test.go:287	0x10017d880		97fc1fd8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:286	0x10017d884		d2800a00		MOVD $80, R0								
  peak_experiment_test.go:286	0x10017d888		97fc1fd6		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:285	0x10017d88c		d2800980		MOVD $76, R0								
  peak_experiment_test.go:285	0x10017d890		97fc1fd4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:284	0x10017d894		d2800900		MOVD $72, R0								
  peak_experiment_test.go:284	0x10017d898		97fc1fd2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:283	0x10017d89c		d2800880		MOVD $68, R0								
  peak_experiment_test.go:283	0x10017d8a0		97fc1fd0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:282	0x10017d8a4		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:282	0x10017d8a8		97fc1fce		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:281	0x10017d8ac		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:281	0x10017d8b0		97fc1fcc		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:280	0x10017d8b4		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:280	0x10017d8b8		97fc1fca		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:279	0x10017d8bc		d2800680		MOVD $52, R0								
  peak_experiment_test.go:279	0x10017d8c0		97fc1fc8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:278	0x10017d8c4		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:278	0x10017d8c8		97fc1fc6		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:277	0x10017d8cc		d2800580		MOVD $44, R0								
  peak_experiment_test.go:277	0x10017d8d0		97fc1fc4		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:276	0x10017d8d4		d2800500		MOVD $40, R0								
  peak_experiment_test.go:276	0x10017d8d8		97fc1fc2		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:275	0x10017d8dc		d2800480		MOVD $36, R0								
  peak_experiment_test.go:275	0x10017d8e0		97fc1fc0		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:274	0x10017d8e4		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:274	0x10017d8e8		97fc1fbe		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:273	0x10017d8ec		97fc1fbd		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:272	0x10017d8f0		97fc1fbc		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:271	0x10017d8f4		97fc1fbb		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:270	0x10017d8f8		97fc1fba		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:269	0x10017d8fc		97fc1fb9		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:268	0x10017d900		97fc1fb8		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:267	0x10017d904		97fc1fb7		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:267	0x10017d908		d503201f		NOOP									
  peak_experiment_test.go:266	0x10017d90c		a90087e0		STP (R0, R1), 8(RSP)							
  peak_experiment_test.go:266	0x10017d910		a9018fe2		STP (R2, R3), 24(RSP)							
  peak_experiment_test.go:266	0x10017d914		a90297e4		STP (R4, R5), 40(RSP)							
  peak_experiment_test.go:266	0x10017d918		f9001fe6		MOVD R6, 56(RSP)							
  peak_experiment_test.go:266	0x10017d91c		aa1e03e3		MOVD R30, R3								
  peak_experiment_test.go:266	0x10017d920		97fc176c		CALL runtime.morestack_noctxt.abi0(SB)					
  peak_experiment_test.go:266	0x10017d924		a94087e0		LDP 8(RSP), (R0, R1)							
  peak_experiment_test.go:266	0x10017d928		a9418fe2		LDP 24(RSP), (R2, R3)							
  peak_experiment_test.go:266	0x10017d92c		a94297e4		LDP 40(RSP), (R4, R5)							
  peak_experiment_test.go:266	0x10017d930		f9401fe6		MOVD 56(RSP), R6							
  peak_experiment_test.go:266	0x10017d934		17fffedb		JMP github.com/GetStream/gophonic/internal/whispergemm.peak7x3(SB)	
  peak_experiment_test.go:266	0x10017d938		00000000		?									
  peak_experiment_test.go:266	0x10017d93c		00000000		?									
