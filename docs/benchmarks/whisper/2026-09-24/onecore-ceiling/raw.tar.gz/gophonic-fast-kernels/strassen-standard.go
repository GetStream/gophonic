package whispergemm

// Experimental single-level Strassen. Only dense constant-weight projections
// use it; dynamic attention matrices and row-vector products keep the base path.
type strassenWeights struct { blocks [7]*PackedB }
type strassenWorkspace struct {
 weights map[*PackedB]*strassenWeights
 input, product [3][]float32
}
var strassenExperimentMode int
func SetStrassenExperimentMode(mode int) { strassenExperimentMode=mode }
func newStrassenWorkspace() *strassenWorkspace {
 s:= &strassenWorkspace{weights:make(map[*PackedB]*strassenWeights)}
 for level:=0;level<3;level++ {size:=(1500*768)>>(2*level);s.input[level]=make([]float32,size);s.product[level]=make([]float32,size)}
 return s
}
func (s *strassenWorkspace) prepare(b *PackedB) *strassenWeights {
 if w:=s.weights[b];w!=nil{return w}
 k,n:=b.k/2,b.n/2
 w:=new(strassenWeights)
 temp:=make([]float32,k*n)
 for block:=0;block<7;block++ {
  for r:=0;r<k;r++ {for c:=0;c<n;c++ {
   b11:=b.data[c/16*b.k*16+r*16+c%16]
   b12:=b.data[(c+n)/16*b.k*16+r*16+(c+n)%16]
   b21:=b.data[c/16*b.k*16+(r+k)*16+c%16]
   b22:=b.data[(c+n)/16*b.k*16+(r+k)*16+(c+n)%16]
   var v float32
   switch block {case 0:v=b11+b22;case 1:v=b11;case 2:v=b12-b22;case 3:v=b21-b11;case 4:v=b22;case 5:v=b11+b12;case 6:v=b21+b22}
   temp[r*n+c]=v
  }}
  w.blocks[block],_=NewPackedB(k,n)
  if err:=w.blocks[block].Pack(temp,n,false);err!=nil{panic(err)}
 }
 s.weights[b]=w
 return w
}
func (s *strassenWorkspace) mul(b *PackedB,dst []float32,ds int,a []float32,as,m int) {s.mulLevel(b,dst,ds,a,as,m,0)}
func (s *strassenWorkspace) mulLevel(b *PackedB,dst []float32,ds int,a []float32,as,m,level int) {
 mh:=m/8*4
 kh,nh:=b.k/2,b.n/2
 weights:=s.prepare(b)
 input:=s.input[level][:mh*kh]
 prod:=s.product[level][:mh*nh]
 for block:=0;block<7;block++ {
  for r:=0;r<mh;r++ {
   a11,a12:=a[r*as:r*as+kh],a[r*as+kh:r*as+b.k]
   a21,a22:=a[(r+mh)*as:(r+mh)*as+kh],a[(r+mh)*as+kh:(r+mh)*as+b.k]
   row:=input[r*kh:(r+1)*kh]
   switch block {
   case 0:strassenAdd(row,a11,a22)
   case 1:strassenAdd(row,a21,a22)
   case 2:copy(row,a11)
   case 3:copy(row,a22)
   case 4:strassenAdd(row,a11,a12)
   case 5:strassenSub(row,a21,a11)
   case 6:strassenSub(row,a12,a22)
   }
  }
  if level+1 < strassenExperimentMode && mh>=64 && kh>=64 && nh>=64 && kh%2==0 && nh%32==0 {s.mulLevel(weights.blocks[block],prod,nh,input,kh,mh,level+1)} else {weights.blocks[block].mul(prod,nh,input,kh,mh)}
  for r:=0;r<mh;r++ {
   c11,c12:=dst[r*ds:r*ds+nh],dst[r*ds+nh:r*ds+b.n]
   c21,c22:=dst[(r+mh)*ds:(r+mh)*ds+nh],dst[(r+mh)*ds+nh:(r+mh)*ds+b.n]
   row:=prod[r*nh:(r+1)*nh]
   switch block {
   case 0:copy(c11,row);copy(c22,row)
   case 1:copy(c21,row);strassenSub(c22,c22,row)
   case 2:copy(c12,row);strassenAdd(c22,c22,row)
   case 3:strassenAddPair(c11,c21,row)
   case 4:strassenSubAddPair(c11,c12,row)
   case 5:strassenAdd(c22,c22,row)
   case 6:strassenAdd(c11,c11,row)
   }
  }
 }
 if tail:=m-2*mh;tail>0 {b.mul(dst[2*mh*ds:],ds,a[2*mh*as:],as,tail)}
}
