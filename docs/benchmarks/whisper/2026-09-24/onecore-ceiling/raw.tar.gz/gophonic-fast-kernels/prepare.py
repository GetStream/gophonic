from pathlib import Path
import json
repo=Path('/Users/thesyncim/Documents/ChatGPT/goinfer')
out=Path('/private/tmp/gophonic-fast-kernels')
base=(repo/'internal/whispergemm/kernel_arm64.go').read_text().replace('func mulPacked(', 'func mulPackedBaseline(',1)
wrapper='''
var kernelExperimentMode int
func SetKernelExperimentMode(mode int) { kernelExperimentMode = mode }
func mulPacked(dst []float32, dstStride int, a []float32, aStride int, packed []float32, m, k, n int) {
 if kernelExperimentMode==0 || m<12 { mulPackedBaseline(dst,dstStride,a,aStride,packed,m,k,n);return }
 rows:=m/12*12
 if kernelExperimentMode==3 { rows=m/20*20 }
 c:=0
 switch kernelExperimentMode {
 case 1:
  for ; c+32<=n;c+=32 {
   w0,w1:=packed[c*k:(c+16)*k],packed[(c+16)*k:(c+32)*k]
   for r:=0;r<rows;r+=3 { kernel3x32(a[r*aStride:r*aStride+k],a[(r+1)*aStride:(r+1)*aStride+k],a[(r+2)*aStride:(r+2)*aStride+k],w0,w1,dst[r*dstStride+c:r*dstStride+c+32],dst[(r+1)*dstStride+c:(r+1)*dstStride+c+32],dst[(r+2)*dstStride+c:(r+2)*dstStride+c+32]) }
  }
 case 3:
  for ; c+16<=n;c+=16 {
   w0:=packed[c*k:(c+16)*k]
   for r:=0;r<rows;r+=5 { kernel5x16(a[r*aStride:r*aStride+k],a[(r+1)*aStride:(r+1)*aStride+k],a[(r+2)*aStride:(r+2)*aStride+k],a[(r+3)*aStride:(r+3)*aStride+k],a[(r+4)*aStride:(r+4)*aStride+k],w0,dst[r*dstStride+c:r*dstStride+c+16],dst[(r+1)*dstStride+c:(r+1)*dstStride+c+16],dst[(r+2)*dstStride+c:(r+2)*dstStride+c+16],dst[(r+3)*dstStride+c:(r+3)*dstStride+c+16],dst[(r+4)*dstStride+c:(r+4)*dstStride+c+16]) }
  }
 case 2:
  for ; c+16<=n;c+=16 {
   w0:=packed[c*k:(c+16)*k]
   for r:=0;r<rows;r+=6 { kernel6x16(a[r*aStride:r*aStride+k],a[(r+1)*aStride:(r+1)*aStride+k],a[(r+2)*aStride:(r+2)*aStride+k],a[(r+3)*aStride:(r+3)*aStride+k],a[(r+4)*aStride:(r+4)*aStride+k],a[(r+5)*aStride:(r+5)*aStride+k],w0,dst[r*dstStride+c:r*dstStride+c+16],dst[(r+1)*dstStride+c:(r+1)*dstStride+c+16],dst[(r+2)*dstStride+c:(r+2)*dstStride+c+16],dst[(r+3)*dstStride+c:(r+3)*dstStride+c+16],dst[(r+4)*dstStride+c:(r+4)*dstStride+c+16],dst[(r+5)*dstStride+c:(r+5)*dstStride+c+16]) }
  }
 }
 if c<n { mulPackedBaseline(dst[c:],dstStride,a,aStride,packed[c*k:],rows,k,n-c) }
 if rows<m { mulPackedBaseline(dst[rows*dstStride:],dstStride,a[rows*aStride:],aStride,packed,m-rows,k,n) }
}
'''
(out/'kernel_arm64.go').write_text(base+wrapper)
s=(repo/'internal/whispergemm/kernel_wide_arm64.go').read_text().replace('import "simd/archsimd"', 'import ("simd/archsimd";"math")')
for rows,cols in [(3,32),(6,16),(5,16)]:
 name=f'kernel{rows}x{cols}'
 args=[f'a{i}' for i in range(rows)]+[f'weights{i}' for i in range(cols//16)]+[f'd{i}' for i in range(rows)]
 s+='\nfunc '+name+'('+', '.join(args)+' []float32) {\n k:=len(a0)\n'
 for r in range(1,rows):s+=f'a{r}=a{r}[:k:k]\n'
 for c in range(cols//16):s+=f'weights{c}=weights{c}[:k*16:k*16]\n'
 for r in range(rows):s+='var '+', '.join(f'c{r}_{c}' for c in range(cols//4))+' archsimd.Float32x4\n'
 s+='for p:=0;p<k;p++ {\n'
 for r in range(rows):s+=f'x{r}:=archsimd.BroadcastUint32x4(math.Float32bits(a{r}[p])).BitsToFloat32()\n'
 for c in range(cols//16):s+=f'wb{c}:=(*[16]float32)(weights{c}[p*16:p*16+16])\n'
 for c in range(cols//4):
  i=c//4;j=c%4*4
  s+=f'w{c}:=archsimd.LoadFloat32x4Array((*[4]float32)(wb{i}[{j}:{j+4}]))\n'
  for r in range(rows):s+=f'c{r}_{c}=w{c}.MulAdd(x{r},c{r}_{c})\n'
 s+='}\n'
 for r in range(rows):
  s+=f'_ = d{r}[{cols-1}]\n'
  for c in range(cols//4):s+=f'c{r}_{c}.StoreArray((*[4]float32)(d{r}[{c*4}:{c*4+4}]))\n'
 s+='}\n'
(out/'kernel_wide_arm64.go').write_text(s)
test='''//go:build goexperiment.simd && arm64
package whispergemm
import("encoding/json";"os";"runtime";"testing";"time")
func TestFastKernelShapes(t *testing.T) {
 runtime.GOMAXPROCS(1)
 type sample struct{Shape string;Mode int;Nanoseconds int64}
 var samples []sample
 for _,s:=range []struct{Name string;M,K,N,Reps int}{
 {"fast_qk",32,64,608,40},{"fast_pv",32,608,64,40},{"fast_projection",608,384,384,2},{"fast_expand",608,384,1536,1},{"fast_contract",608,1536,384,1},{"fast_conv2",608,1152,384,1},{"full_projection",1500,384,384,1},{"full_expand",1500,384,1536,1},{"full_contract",1500,1536,384,1},
 } {
  a,_,dst,b:=benchmarkData(t,s.M,s.K,s.N)
  for cycle:=0;cycle<16;cycle++ {for j:=0;j<4;j++ {
   mode:=(j+cycle)%4;kernelExperimentMode=mode
   if err:=b.Mul(dst,s.N,a,s.K,s.M);err!=nil{t.Fatal(err)}
   start:=time.Now();for r:=0;r<s.Reps;r++ {if err:=b.Mul(dst,s.N,a,s.K,s.M);err!=nil{t.Fatal(err)}}
   samples=append(samples,sample{s.Name,mode,time.Since(start).Nanoseconds()/int64(s.Reps)})
  }}
  benchmarkSink=dst[len(dst)-1]
 }
 data,err:=json.Marshal(samples);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/shapes.json",data,0644);err!=nil{t.Fatal(err)}
}
func TestFastKernelExact(t *testing.T) {
 for _,mode:=range []int{1,2,3} {kernelExperimentMode=mode;t.Run("order",TestWideGEMMPreservesFourRowOrder);t.Run("special",TestWideGEMMSpecialValues)}
}
'''
(out/'experiment_test.go').write_text(test)
repl={str(repo/'internal/whispergemm'/f):str(out/f) for f in ['kernel_arm64.go','kernel_wide_arm64.go','experiment_test.go']}
(out/'overlay.json').write_text(json.dumps({'Replace':repl},indent=2))
