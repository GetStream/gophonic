TEXT github.com/GetStream/gophonic/internal/whispergemm.kernel3x32(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/kernel_wide_arm64.go
  kernel_wide_arm64.go:194	0x100175cb0		f9400b90		MOVD 16(R28), R16							
  kernel_wide_arm64.go:194	0x100175cb4		eb3063ff		CMP R16, RSP								
  kernel_wide_arm64.go:194	0x100175cb8		54001429		BLS 161(PC)								
  kernel_wide_arm64.go:194	0x100175cbc		f81b0ffe		MOVD.W R30, -80(RSP)							
  kernel_wide_arm64.go:194	0x100175cc0		f81f83fd		MOVD R29, -8(RSP)							
  kernel_wide_arm64.go:194	0x100175cc4		d10023fd		SUB $8, RSP, R29							
  kernel_wide_arm64.go:194	0x100175cc8		f90053e0		MOVD R0, 160(RSP)							
  kernel_wide_arm64.go:194	0x100175ccc		f9005fe3		MOVD R3, 184(RSP)							
  kernel_wide_arm64.go:194	0x100175cd0		f9006be6		MOVD R6, 208(RSP)							
  kernel_wide_arm64.go:194	0x100175cd4		f90077e9		MOVD R9, 232(RSP)							
  kernel_wide_arm64.go:194	0x100175cd8		f90083ec		MOVD R12, 256(RSP)							
  kernel_wide_arm64.go:196	0x100175cdc		eb05003f		CMP R5, R1								
  kernel_wide_arm64.go:196	0x100175ce0		540012a8		BHI 149(PC)								
  kernel_wide_arm64.go:197	0x100175ce4		eb08003f		CMP R8, R1								
  kernel_wide_arm64.go:197	0x100175ce8		54001248		BHI 146(PC)								
  kernel_wide_arm64.go:198	0x100175cec		d37cec22		LSL $4, R1, R2								
  kernel_wide_arm64.go:198	0x100175cf0		eb01117f		CMP R1<<4, R11								
  kernel_wide_arm64.go:198	0x100175cf4		540011c3		BCC 142(PC)								
  kernel_wide_arm64.go:199	0x100175cf8		eb0111df		CMP R1<<4, R14								
  kernel_wide_arm64.go:199	0x100175cfc		54001163		BCC 139(PC)								
  kernel_wide_arm64.go:200	0x100175d00		4f00e400		VMOVI $0, V0.B16							
  other_gen_arm64.go:52		0x100175d04		4f00e401		VMOVI $0, V1.B16							
  other_gen_arm64.go:52		0x100175d08		3c8083e1		FMOVQ F1, 8(RSP)							
  kernel_wide_arm64.go:203	0x100175d0c		aa1f03e4		MOVD ZR, R4								
  kernel_wide_arm64.go:203	0x100175d10		4ea01c02		VMOV V0.B16, V2.B16							
  kernel_wide_arm64.go:203	0x100175d14		4ea21c43		VMOV V2.B16, V3.B16							
  kernel_wide_arm64.go:203	0x100175d18		4ea31c64		VMOV V3.B16, V4.B16							
  kernel_wide_arm64.go:203	0x100175d1c		4ea41c85		VMOV V4.B16, V5.B16							
  kernel_wide_arm64.go:203	0x100175d20		4ea51ca6		VMOV V5.B16, V6.B16							
  kernel_wide_arm64.go:203	0x100175d24		4ea61cc7		VMOV V6.B16, V7.B16							
  kernel_wide_arm64.go:203	0x100175d28		4ea71ce8		VMOV V7.B16, V8.B16							
  kernel_wide_arm64.go:203	0x100175d2c		4ea81d09		VMOV V8.B16, V9.B16							
  kernel_wide_arm64.go:203	0x100175d30		4ea91d2a		VMOV V9.B16, V10.B16							
  kernel_wide_arm64.go:203	0x100175d34		4eaa1d4b		VMOV V10.B16, V11.B16							
  kernel_wide_arm64.go:203	0x100175d38		4eab1d6c		VMOV V11.B16, V12.B16							
  kernel_wide_arm64.go:203	0x100175d3c		4eac1d8d		VMOV V12.B16, V13.B16							
  kernel_wide_arm64.go:203	0x100175d40		4ead1dae		VMOV V13.B16, V14.B16							
  kernel_wide_arm64.go:203	0x100175d44		4eae1dcf		VMOV V14.B16, V15.B16							
  kernel_wide_arm64.go:203	0x100175d48		4eaf1df0		VMOV V15.B16, V16.B16							
  kernel_wide_arm64.go:203	0x100175d4c		4eb01e11		VMOV V16.B16, V17.B16							
  kernel_wide_arm64.go:203	0x100175d50		4eb11e32		VMOV V17.B16, V18.B16							
  kernel_wide_arm64.go:203	0x100175d54		4eb21e53		VMOV V18.B16, V19.B16							
  kernel_wide_arm64.go:203	0x100175d58		4eb31e74		VMOV V19.B16, V20.B16							
  kernel_wide_arm64.go:203	0x100175d5c		4eb41e95		VMOV V20.B16, V21.B16							
  kernel_wide_arm64.go:203	0x100175d60		4eb51eb6		VMOV V21.B16, V22.B16							
  kernel_wide_arm64.go:203	0x100175d64		4eb61ed7		VMOV V22.B16, V23.B16							
  kernel_wide_arm64.go:203	0x100175d68		4eb71ef8		VMOV V23.B16, V24.B16							
  kernel_wide_arm64.go:203	0x100175d6c		1400002f		JMP 47(PC)								
  kernel_wide_arm64.go:203	0x100175d70		3c8183e0		FMOVQ F0, 24(RSP)							
  kernel_wide_arm64.go:203	0x100175d74		3c8283e9		FMOVQ F9, 40(RSP)							
  kernel_wide_arm64.go:203	0x100175d78		3c8383f1		FMOVQ F17, 56(RSP)							
  kernel_wide_arm64.go:207	0x100175d7c		8b041925		ADD R4<<6, R9, R5							
  kernel_wide_arm64.go:208	0x100175d80		8b041987		ADD R4<<6, R12, R7							
  kernel_wide_arm64.go:209	0x100175d84		3dc000bc		FMOVQ (R5), F28								
  kernel_wide_arm64.go:213	0x100175d88		3dc004bd		FMOVQ 16(R5), F29							
  kernel_wide_arm64.go:217	0x100175d8c		3dc008be		FMOVQ 32(R5), F30							
  kernel_wide_arm64.go:221	0x100175d90		3dc00cbf		FMOVQ 48(R5), F31							
  kernel_wide_arm64.go:225	0x100175d94		3dc000fb		FMOVQ (R7), F27								
  kernel_wide_arm64.go:229	0x100175d98		3dc004e0		FMOVQ 16(R7), F0							
  kernel_wide_arm64.go:233	0x100175d9c		3dc008e9		FMOVQ 32(R7), F9							
  kernel_wide_arm64.go:237	0x100175da0		3dc00cf1		FMOVQ 48(R7), F17							
  other_gen_arm64.go:53		0x100175da4		4e040421		VDUP V1.S[0], V1.S4							
  other_gen_arm64.go:53		0x100175da8		4e040739		VDUP V25.S[0], V25.S4							
  other_gen_arm64.go:53		0x100175dac		4e04075a		VDUP V26.S[0], V26.S4							
  kernel_wide_arm64.go:210	0x100175db0		4e21cf98		VFMLA V1.S4, V28.S4, V24.S4						
  kernel_wide_arm64.go:211	0x100175db4		4e39cf90		VFMLA V25.S4, V28.S4, V16.S4						
  kernel_wide_arm64.go:212	0x100175db8		4e3acf88		VFMLA V26.S4, V28.S4, V8.S4						
  kernel_wide_arm64.go:214	0x100175dbc		4e21cfb7		VFMLA V1.S4, V29.S4, V23.S4						
  kernel_wide_arm64.go:215	0x100175dc0		4e39cfaf		VFMLA V25.S4, V29.S4, V15.S4						
  kernel_wide_arm64.go:216	0x100175dc4		4e3acfa7		VFMLA V26.S4, V29.S4, V7.S4						
  kernel_wide_arm64.go:218	0x100175dc8		4e21cfd6		VFMLA V1.S4, V30.S4, V22.S4						
  kernel_wide_arm64.go:219	0x100175dcc		4e39cfce		VFMLA V25.S4, V30.S4, V14.S4						
  kernel_wide_arm64.go:220	0x100175dd0		4e3acfc6		VFMLA V26.S4, V30.S4, V6.S4						
  kernel_wide_arm64.go:222	0x100175dd4		4e21cff5		VFMLA V1.S4, V31.S4, V21.S4						
  kernel_wide_arm64.go:223	0x100175dd8		4e39cfed		VFMLA V25.S4, V31.S4, V13.S4						
  kernel_wide_arm64.go:224	0x100175ddc		4e3acfe5		VFMLA V26.S4, V31.S4, V5.S4						
  kernel_wide_arm64.go:226	0x100175de0		4e21cf74		VFMLA V1.S4, V27.S4, V20.S4						
  kernel_wide_arm64.go:227	0x100175de4		4e39cf6c		VFMLA V25.S4, V27.S4, V12.S4						
  kernel_wide_arm64.go:228	0x100175de8		4e3acf64		VFMLA V26.S4, V27.S4, V4.S4						
  kernel_wide_arm64.go:230	0x100175dec		4e21cc13		VFMLA V1.S4, V0.S4, V19.S4						
  kernel_wide_arm64.go:231	0x100175df0		4e39cc0b		VFMLA V25.S4, V0.S4, V11.S4						
  kernel_wide_arm64.go:232	0x100175df4		4e3acc03		VFMLA V26.S4, V0.S4, V3.S4						
  kernel_wide_arm64.go:234	0x100175df8		4e21cd32		VFMLA V1.S4, V9.S4, V18.S4						
  kernel_wide_arm64.go:235	0x100175dfc		4e39cd2a		VFMLA V25.S4, V9.S4, V10.S4						
  kernel_wide_arm64.go:236	0x100175e00		4e3acd22		VFMLA V26.S4, V9.S4, V2.S4						
  kernel_wide_arm64.go:238	0x100175e04		3cc383fb		FMOVQ 56(RSP), F27							
  kernel_wide_arm64.go:238	0x100175e08		4e21ce3b		VFMLA V1.S4, V17.S4, V27.S4						
  kernel_wide_arm64.go:239	0x100175e0c		3cc283e9		FMOVQ 40(RSP), F9							
  kernel_wide_arm64.go:239	0x100175e10		4e39ce29		VFMLA V25.S4, V17.S4, V9.S4						
  kernel_wide_arm64.go:240	0x100175e14		3cc183e0		FMOVQ 24(RSP), F0							
  kernel_wide_arm64.go:240	0x100175e18		4e3ace20		VFMLA V26.S4, V17.S4, V0.S4						
  kernel_wide_arm64.go:203	0x100175e1c		91000484		ADD $1, R4, R4								
  other_gen_arm64.go:53		0x100175e20		3cc083e1		FMOVQ 8(RSP), F1							
  kernel_wide_arm64.go:203	0x100175e24		4ebb1f71		VMOV V27.B16, V17.B16							
  kernel_wide_arm64.go:203	0x100175e28		eb04003f		CMP R4, R1								
  kernel_wide_arm64.go:203	0x100175e2c		5400026d		BLE 19(PC)								
  kernel_wide_arm64.go:204	0x100175e30		bc647819		FMOVS (R0)(R4<<2), F25							
  kernel_wide_arm64.go:205	0x100175e34		bc64787a		FMOVS (R3)(R4<<2), F26							
  kernel_wide_arm64.go:206	0x100175e38		bc6478db		FMOVS (R6)(R4<<2), F27							
  kernel_wide_arm64.go:207	0x100175e3c		d37cec85		LSL $4, R4, R5								
  kernel_wide_arm64.go:207	0x100175e40		910040a7		ADD $16, R5, R7								
  unsafe.go:24			0x100175e44		1e260328		FMOVS F25, R8								
  unsafe.go:24			0x100175e48		1e26034a		FMOVS F26, R10								
  unsafe.go:24			0x100175e4c		1e26036b		FMOVS F27, R11								
  other_gen_arm64.go:53		0x100175e50		4ea11c39		VMOV V1.B16, V25.B16							
  other_gen_arm64.go:53		0x100175e54		4e041d01		VMOV R8, V1.S[0]							
  other_gen_arm64.go:53		0x100175e58		4eb91f3a		VMOV V25.B16, V26.B16							
  other_gen_arm64.go:53		0x100175e5c		4e041d59		VMOV R10, V25.S[0]							
  other_gen_arm64.go:53		0x100175e60		4e041d7a		VMOV R11, V26.S[0]							
  kernel_wide_arm64.go:207	0x100175e64		eb0110ff		CMP R1<<4, R7								
  kernel_wide_arm64.go:207	0x100175e68		540005e8		BHI 47(PC)								
  kernel_wide_arm64.go:207	0x100175e6c		eb0410ff		CMP R4<<4, R7								
  kernel_wide_arm64.go:207	0x100175e70		54fff802		BCS -64(PC)								
  kernel_wide_arm64.go:207	0x100175e74		1400002b		JMP 43(PC)								
  kernel_wide_arm64.go:242	0x100175e78		f94033e0		MOVD 96(RSP), R0							
  kernel_wide_arm64.go:242	0x100175e7c		f1007c1f		CMP $31, R0								
  kernel_wide_arm64.go:242	0x100175e80		540004e9		BLS 39(PC)								
  kernel_wide_arm64.go:243	0x100175e84		f9402fe0		MOVD 88(RSP), R0							
  kernel_wide_arm64.go:243	0x100175e88		3d800018		FMOVQ F24, (R0)								
  kernel_wide_arm64.go:244	0x100175e8c		3d800417		FMOVQ F23, 16(R0)							
  kernel_wide_arm64.go:245	0x100175e90		3d800816		FMOVQ F22, 32(R0)							
  kernel_wide_arm64.go:246	0x100175e94		3d800c15		FMOVQ F21, 48(R0)							
  kernel_wide_arm64.go:247	0x100175e98		3d801014		FMOVQ F20, 64(R0)							
  kernel_wide_arm64.go:248	0x100175e9c		3d801413		FMOVQ F19, 80(R0)							
  kernel_wide_arm64.go:249	0x100175ea0		3d801812		FMOVQ F18, 96(R0)							
  kernel_wide_arm64.go:250	0x100175ea4		3d801c11		FMOVQ F17, 112(R0)							
  kernel_wide_arm64.go:251	0x100175ea8		f9403fe0		MOVD 120(RSP), R0							
  kernel_wide_arm64.go:251	0x100175eac		f1007c1f		CMP $31, R0								
  kernel_wide_arm64.go:251	0x100175eb0		54000349		BLS 26(PC)								
  kernel_wide_arm64.go:252	0x100175eb4		f9403be0		MOVD 112(RSP), R0							
  kernel_wide_arm64.go:252	0x100175eb8		3d800010		FMOVQ F16, (R0)								
  kernel_wide_arm64.go:253	0x100175ebc		3d80040f		FMOVQ F15, 16(R0)							
  kernel_wide_arm64.go:254	0x100175ec0		3d80080e		FMOVQ F14, 32(R0)							
  kernel_wide_arm64.go:255	0x100175ec4		3d800c0d		FMOVQ F13, 48(R0)							
  kernel_wide_arm64.go:256	0x100175ec8		3d80100c		FMOVQ F12, 64(R0)							
  kernel_wide_arm64.go:257	0x100175ecc		3d80140b		FMOVQ F11, 80(R0)							
  kernel_wide_arm64.go:258	0x100175ed0		3d80180a		FMOVQ F10, 96(R0)							
  kernel_wide_arm64.go:259	0x100175ed4		3d801c09		FMOVQ F9, 112(R0)							
  kernel_wide_arm64.go:260	0x100175ed8		f9404be0		MOVD 144(RSP), R0							
  kernel_wide_arm64.go:260	0x100175edc		f1007c1f		CMP $31, R0								
  kernel_wide_arm64.go:260	0x100175ee0		540001a9		BLS 13(PC)								
  kernel_wide_arm64.go:261	0x100175ee4		f94047e0		MOVD 136(RSP), R0							
  kernel_wide_arm64.go:261	0x100175ee8		3d800008		FMOVQ F8, (R0)								
  kernel_wide_arm64.go:262	0x100175eec		3d800407		FMOVQ F7, 16(R0)							
  kernel_wide_arm64.go:263	0x100175ef0		3d800806		FMOVQ F6, 32(R0)							
  kernel_wide_arm64.go:264	0x100175ef4		3d800c05		FMOVQ F5, 48(R0)							
  kernel_wide_arm64.go:265	0x100175ef8		3d801004		FMOVQ F4, 64(R0)							
  kernel_wide_arm64.go:266	0x100175efc		3d801403		FMOVQ F3, 80(R0)							
  kernel_wide_arm64.go:267	0x100175f00		3d801802		FMOVQ F2, 96(R0)							
  kernel_wide_arm64.go:268	0x100175f04		3d801c00		FMOVQ F0, 112(R0)							
  kernel_wide_arm64.go:269	0x100175f08		f85f83fd		MOVD -8(RSP), R29							
  kernel_wide_arm64.go:269	0x100175f0c		f84507fe		MOVD.P 80(RSP), R30							
  kernel_wide_arm64.go:269	0x100175f10		d65f03c0		RET									
  kernel_wide_arm64.go:260	0x100175f14		97fc3e33		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:251	0x100175f18		97fc3e32		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:242	0x100175f1c		97fc3e31		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:207	0x100175f20		97fc3e30		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:207	0x100175f24		97fc3e2f		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:199	0x100175f28		97fc3e2e		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:198	0x100175f2c		97fc3e2d		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:197	0x100175f30		97fc3e2c		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:196	0x100175f34		97fc3e2b		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:196	0x100175f38		d503201f		NOOP									
  kernel_wide_arm64.go:194	0x100175f3c		a90507e0		STP (R0, R1), 80(RSP)							
  kernel_wide_arm64.go:194	0x100175f40		a9060fe2		STP (R2, R3), 96(RSP)							
  kernel_wide_arm64.go:194	0x100175f44		a90717e4		STP (R4, R5), 112(RSP)							
  kernel_wide_arm64.go:194	0x100175f48		a9081fe6		STP (R6, R7), 128(RSP)							
  kernel_wide_arm64.go:194	0x100175f4c		a90927e8		STP (R8, R9), 144(RSP)							
  kernel_wide_arm64.go:194	0x100175f50		a90a2fea		STP (R10, R11), 160(RSP)						
  kernel_wide_arm64.go:194	0x100175f54		a90b37ec		STP (R12, R13), 176(RSP)						
  kernel_wide_arm64.go:194	0x100175f58		f90063ee		MOVD R14, 192(RSP)							
  kernel_wide_arm64.go:194	0x100175f5c		aa1e03e3		MOVD R30, R3								
  kernel_wide_arm64.go:194	0x100175f60		97fc35dc		CALL runtime.morestack_noctxt.abi0(SB)					
  kernel_wide_arm64.go:194	0x100175f64		a94507e0		LDP 80(RSP), (R0, R1)							
  kernel_wide_arm64.go:194	0x100175f68		a9460fe2		LDP 96(RSP), (R2, R3)							
  kernel_wide_arm64.go:194	0x100175f6c		a94717e4		LDP 112(RSP), (R4, R5)							
  kernel_wide_arm64.go:194	0x100175f70		a9481fe6		LDP 128(RSP), (R6, R7)							
  kernel_wide_arm64.go:194	0x100175f74		a94927e8		LDP 144(RSP), (R8, R9)							
  kernel_wide_arm64.go:194	0x100175f78		a94a2fea		LDP 160(RSP), (R10, R11)						
  kernel_wide_arm64.go:194	0x100175f7c		a94b37ec		LDP 176(RSP), (R12, R13)						
  kernel_wide_arm64.go:194	0x100175f80		f94063ee		MOVD 192(RSP), R14							
  kernel_wide_arm64.go:194	0x100175f84		17ffff4b		JMP github.com/GetStream/gophonic/internal/whispergemm.kernel3x32(SB)	
  kernel_wide_arm64.go:194	0x100175f88		00000000		?									
  kernel_wide_arm64.go:194	0x100175f8c		00000000		?									

TEXT github.com/GetStream/gophonic/internal/whispergemm.kernel6x16(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/kernel_wide_arm64.go
  kernel_wide_arm64.go:271	0x100175f90		f9400b90		MOVD 16(R28), R16							
  kernel_wide_arm64.go:271	0x100175f94		eb3063ff		CMP R16, RSP								
  kernel_wide_arm64.go:271	0x100175f98		54001849		BLS 194(PC)								
  kernel_wide_arm64.go:271	0x100175f9c		f81c0ffe		MOVD.W R30, -64(RSP)							
  kernel_wide_arm64.go:271	0x100175fa0		f81f83fd		MOVD R29, -8(RSP)							
  kernel_wide_arm64.go:271	0x100175fa4		d10023fd		SUB $8, RSP, R29							
  kernel_wide_arm64.go:271	0x100175fa8		f90087e0		MOVD R0, 264(RSP)							
  kernel_wide_arm64.go:271	0x100175fac		f90093e3		MOVD R3, 288(RSP)							
  kernel_wide_arm64.go:271	0x100175fb0		f9009fe6		MOVD R6, 312(RSP)							
  kernel_wide_arm64.go:271	0x100175fb4		f900abe9		MOVD R9, 336(RSP)							
  kernel_wide_arm64.go:271	0x100175fb8		f900b7ec		MOVD R12, 360(RSP)							
  kernel_wide_arm64.go:273	0x100175fbc		eb05003f		CMP R5, R1								
  kernel_wide_arm64.go:273	0x100175fc0		540016c8		BHI 182(PC)								
  kernel_wide_arm64.go:274	0x100175fc4		eb08003f		CMP R8, R1								
  kernel_wide_arm64.go:274	0x100175fc8		54001668		BHI 179(PC)								
  kernel_wide_arm64.go:275	0x100175fcc		eb0b003f		CMP R11, R1								
  kernel_wide_arm64.go:275	0x100175fd0		54001608		BHI 176(PC)								
  kernel_wide_arm64.go:276	0x100175fd4		eb0e003f		CMP R14, R1								
  kernel_wide_arm64.go:276	0x100175fd8		540015a8		BHI 173(PC)								
  kernel_wide_arm64.go:277	0x100175fdc		f9402fe2		MOVD 88(RSP), R2							
  kernel_wide_arm64.go:277	0x100175fe0		eb02003f		CMP R2, R1								
  kernel_wide_arm64.go:277	0x100175fe4		54001528		BHI 169(PC)								
  kernel_wide_arm64.go:278	0x100175fe8		d37cec22		LSL $4, R1, R2								
  kernel_wide_arm64.go:278	0x100175fec		f9403be4		MOVD 112(RSP), R4							
  kernel_wide_arm64.go:278	0x100175ff0		eb01109f		CMP R1<<4, R4								
  kernel_wide_arm64.go:278	0x100175ff4		54001483		BCC 164(PC)								
  kernel_wide_arm64.go:279	0x100175ff8		4f00e400		VMOVI $0, V0.B16							
  other_gen_arm64.go:52		0x100175ffc		4f00e401		VMOVI $0, V1.B16							
  other_gen_arm64.go:52		0x100176000		3c8083e1		FMOVQ F1, 8(RSP)							
  kernel_wide_arm64.go:285	0x100176004		aa1f03e4		MOVD ZR, R4								
  kernel_wide_arm64.go:285	0x100176008		f94027e5		MOVD 72(RSP), R5							
  kernel_wide_arm64.go:285	0x10017600c		f94033e7		MOVD 96(RSP), R7							
  kernel_wide_arm64.go:285	0x100176010		4ea01c02		VMOV V0.B16, V2.B16							
  kernel_wide_arm64.go:285	0x100176014		4ea21c43		VMOV V2.B16, V3.B16							
  kernel_wide_arm64.go:285	0x100176018		4ea31c64		VMOV V3.B16, V4.B16							
  kernel_wide_arm64.go:285	0x10017601c		4ea41c85		VMOV V4.B16, V5.B16							
  kernel_wide_arm64.go:285	0x100176020		4ea51ca6		VMOV V5.B16, V6.B16							
  kernel_wide_arm64.go:285	0x100176024		4ea61cc7		VMOV V6.B16, V7.B16							
  kernel_wide_arm64.go:285	0x100176028		4ea71ce8		VMOV V7.B16, V8.B16							
  kernel_wide_arm64.go:285	0x10017602c		4ea81d09		VMOV V8.B16, V9.B16							
  kernel_wide_arm64.go:285	0x100176030		4ea91d2a		VMOV V9.B16, V10.B16							
  kernel_wide_arm64.go:285	0x100176034		4eaa1d4b		VMOV V10.B16, V11.B16							
  kernel_wide_arm64.go:285	0x100176038		4eab1d6c		VMOV V11.B16, V12.B16							
  kernel_wide_arm64.go:285	0x10017603c		4eac1d8d		VMOV V12.B16, V13.B16							
  kernel_wide_arm64.go:285	0x100176040		4ead1dae		VMOV V13.B16, V14.B16							
  kernel_wide_arm64.go:285	0x100176044		4eae1dcf		VMOV V14.B16, V15.B16							
  kernel_wide_arm64.go:285	0x100176048		4eaf1df0		VMOV V15.B16, V16.B16							
  kernel_wide_arm64.go:285	0x10017604c		4eb01e11		VMOV V16.B16, V17.B16							
  kernel_wide_arm64.go:285	0x100176050		4eb11e32		VMOV V17.B16, V18.B16							
  kernel_wide_arm64.go:285	0x100176054		4eb21e53		VMOV V18.B16, V19.B16							
  kernel_wide_arm64.go:285	0x100176058		4eb31e74		VMOV V19.B16, V20.B16							
  kernel_wide_arm64.go:285	0x10017605c		4eb41e95		VMOV V20.B16, V21.B16							
  kernel_wide_arm64.go:285	0x100176060		4eb51eb6		VMOV V21.B16, V22.B16							
  kernel_wide_arm64.go:285	0x100176064		4eb61ed7		VMOV V22.B16, V23.B16							
  kernel_wide_arm64.go:285	0x100176068		4eb71ef8		VMOV V23.B16, V24.B16							
  kernel_wide_arm64.go:285	0x10017606c		1400002b		JMP 43(PC)								
  kernel_wide_arm64.go:285	0x100176070		3c8183e0		FMOVQ F0, 24(RSP)							
  kernel_wide_arm64.go:285	0x100176074		3c8283e5		FMOVQ F5, 40(RSP)							
  kernel_wide_arm64.go:292	0x100176078		8b0418e8		ADD R4<<6, R7, R8							
  kernel_wide_arm64.go:293	0x10017607c		3dc0011f		FMOVQ (R8), F31								
  kernel_wide_arm64.go:300	0x100176080		3dc0051e		FMOVQ 16(R8), F30							
  kernel_wide_arm64.go:307	0x100176084		3dc00900		FMOVQ 32(R8), F0							
  kernel_wide_arm64.go:314	0x100176088		3dc00d05		FMOVQ 48(R8), F5							
  other_gen_arm64.go:53		0x10017608c		4e040421		VDUP V1.S[0], V1.S4							
  other_gen_arm64.go:53		0x100176090		4e040739		VDUP V25.S[0], V25.S4							
  other_gen_arm64.go:53		0x100176094		4e04075a		VDUP V26.S[0], V26.S4							
  other_gen_arm64.go:53		0x100176098		4e04077b		VDUP V27.S[0], V27.S4							
  other_gen_arm64.go:53		0x10017609c		4e04079c		VDUP V28.S[0], V28.S4							
  other_gen_arm64.go:53		0x1001760a0		4e0407bd		VDUP V29.S[0], V29.S4							
  kernel_wide_arm64.go:294	0x1001760a4		4e21cff8		VFMLA V1.S4, V31.S4, V24.S4						
  kernel_wide_arm64.go:295	0x1001760a8		4e39cff4		VFMLA V25.S4, V31.S4, V20.S4						
  kernel_wide_arm64.go:296	0x1001760ac		4e3acff0		VFMLA V26.S4, V31.S4, V16.S4						
  kernel_wide_arm64.go:297	0x1001760b0		4e3bcfec		VFMLA V27.S4, V31.S4, V12.S4						
  kernel_wide_arm64.go:298	0x1001760b4		4e3ccfe8		VFMLA V28.S4, V31.S4, V8.S4						
  kernel_wide_arm64.go:299	0x1001760b8		4e3dcfe4		VFMLA V29.S4, V31.S4, V4.S4						
  kernel_wide_arm64.go:301	0x1001760bc		4e21cfd7		VFMLA V1.S4, V30.S4, V23.S4						
  kernel_wide_arm64.go:302	0x1001760c0		4e39cfd3		VFMLA V25.S4, V30.S4, V19.S4						
  kernel_wide_arm64.go:303	0x1001760c4		4e3acfcf		VFMLA V26.S4, V30.S4, V15.S4						
  kernel_wide_arm64.go:304	0x1001760c8		4e3bcfcb		VFMLA V27.S4, V30.S4, V11.S4						
  kernel_wide_arm64.go:305	0x1001760cc		4e3ccfc7		VFMLA V28.S4, V30.S4, V7.S4						
  kernel_wide_arm64.go:306	0x1001760d0		4e3dcfc3		VFMLA V29.S4, V30.S4, V3.S4						
  kernel_wide_arm64.go:308	0x1001760d4		4e21cc16		VFMLA V1.S4, V0.S4, V22.S4						
  kernel_wide_arm64.go:309	0x1001760d8		4e39cc12		VFMLA V25.S4, V0.S4, V18.S4						
  kernel_wide_arm64.go:310	0x1001760dc		4e3acc0e		VFMLA V26.S4, V0.S4, V14.S4						
  kernel_wide_arm64.go:311	0x1001760e0		4e3bcc0a		VFMLA V27.S4, V0.S4, V10.S4						
  kernel_wide_arm64.go:312	0x1001760e4		4e3ccc06		VFMLA V28.S4, V0.S4, V6.S4						
  kernel_wide_arm64.go:313	0x1001760e8		4e3dcc02		VFMLA V29.S4, V0.S4, V2.S4						
  kernel_wide_arm64.go:315	0x1001760ec		4e21ccb5		VFMLA V1.S4, V5.S4, V21.S4						
  kernel_wide_arm64.go:316	0x1001760f0		4e39ccb1		VFMLA V25.S4, V5.S4, V17.S4						
  kernel_wide_arm64.go:317	0x1001760f4		4e3accad		VFMLA V26.S4, V5.S4, V13.S4						
  kernel_wide_arm64.go:318	0x1001760f8		4e3bcca9		VFMLA V27.S4, V5.S4, V9.S4						
  kernel_wide_arm64.go:319	0x1001760fc		3cc283f9		FMOVQ 40(RSP), F25							
  kernel_wide_arm64.go:319	0x100176100		4e3cccb9		VFMLA V28.S4, V5.S4, V25.S4						
  kernel_wide_arm64.go:320	0x100176104		3cc183e0		FMOVQ 24(RSP), F0							
  kernel_wide_arm64.go:320	0x100176108		4e3dcca0		VFMLA V29.S4, V5.S4, V0.S4						
  kernel_wide_arm64.go:285	0x10017610c		91000484		ADD $1, R4, R4								
  other_gen_arm64.go:53		0x100176110		3cc083e1		FMOVQ 8(RSP), F1							
  kernel_wide_arm64.go:285	0x100176114		4eb91f25		VMOV V25.B16, V5.B16							
  kernel_wide_arm64.go:285	0x100176118		eb04003f		CMP R4, R1								
  kernel_wide_arm64.go:285	0x10017611c		540003ed		BLE 31(PC)								
  kernel_wide_arm64.go:286	0x100176120		bc647819		FMOVS (R0)(R4<<2), F25							
  kernel_wide_arm64.go:287	0x100176124		bc64787a		FMOVS (R3)(R4<<2), F26							
  kernel_wide_arm64.go:288	0x100176128		bc6478db		FMOVS (R6)(R4<<2), F27							
  kernel_wide_arm64.go:289	0x10017612c		bc64793c		FMOVS (R9)(R4<<2), F28							
  kernel_wide_arm64.go:290	0x100176130		bc64799d		FMOVS (R12)(R4<<2), F29							
  kernel_wide_arm64.go:291	0x100176134		bc6478be		FMOVS (R5)(R4<<2), F30							
  kernel_wide_arm64.go:292	0x100176138		d37cec88		LSL $4, R4, R8								
  kernel_wide_arm64.go:292	0x10017613c		9100410a		ADD $16, R8, R10							
  unsafe.go:24			0x100176140		1e26032b		FMOVS F25, R11								
  unsafe.go:24			0x100176144		1e26034d		FMOVS F26, R13								
  unsafe.go:24			0x100176148		1e26036e		FMOVS F27, R14								
  unsafe.go:24			0x10017614c		1e26038f		FMOVS F28, R15								
  unsafe.go:24			0x100176150		1e2603b0		FMOVS F29, R16								
  unsafe.go:24			0x100176154		1e2603d1		FMOVS F30, R17								
  other_gen_arm64.go:53		0x100176158		4ea11c39		VMOV V1.B16, V25.B16							
  other_gen_arm64.go:53		0x10017615c		4e041d61		VMOV R11, V1.S[0]							
  other_gen_arm64.go:53		0x100176160		4eb91f3a		VMOV V25.B16, V26.B16							
  other_gen_arm64.go:53		0x100176164		4e041db9		VMOV R13, V25.S[0]							
  other_gen_arm64.go:53		0x100176168		4eba1f5b		VMOV V26.B16, V27.B16							
  other_gen_arm64.go:53		0x10017616c		4e041dda		VMOV R14, V26.S[0]							
  other_gen_arm64.go:53		0x100176170		4ebb1f7c		VMOV V27.B16, V28.B16							
  other_gen_arm64.go:53		0x100176174		4e041dfb		VMOV R15, V27.S[0]							
  other_gen_arm64.go:53		0x100176178		4ebc1f9d		VMOV V28.B16, V29.B16							
  other_gen_arm64.go:53		0x10017617c		4e041e1c		VMOV R16, V28.S[0]							
  other_gen_arm64.go:53		0x100176180		4e041e3d		VMOV R17, V29.S[0]							
  kernel_wide_arm64.go:292	0x100176184		eb01115f		CMP R1<<4, R10								
  kernel_wide_arm64.go:292	0x100176188		540007c8		BHI 62(PC)								
  kernel_wide_arm64.go:292	0x10017618c		eb04115f		CMP R4<<4, R10								
  kernel_wide_arm64.go:292	0x100176190		54fff702		BCS -72(PC)								
  kernel_wide_arm64.go:292	0x100176194		1400003a		JMP 58(PC)								
  kernel_wide_arm64.go:322	0x100176198		f94043e0		MOVD 128(RSP), R0							
  kernel_wide_arm64.go:322	0x10017619c		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:322	0x1001761a0		540006c9		BLS 54(PC)								
  kernel_wide_arm64.go:323	0x1001761a4		f9403fe0		MOVD 120(RSP), R0							
  kernel_wide_arm64.go:323	0x1001761a8		3d800018		FMOVQ F24, (R0)								
  kernel_wide_arm64.go:324	0x1001761ac		3d800417		FMOVQ F23, 16(R0)							
  kernel_wide_arm64.go:325	0x1001761b0		3d800816		FMOVQ F22, 32(R0)							
  kernel_wide_arm64.go:326	0x1001761b4		3d800c15		FMOVQ F21, 48(R0)							
  kernel_wide_arm64.go:327	0x1001761b8		f9404fe0		MOVD 152(RSP), R0							
  kernel_wide_arm64.go:327	0x1001761bc		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:327	0x1001761c0		540005a9		BLS 45(PC)								
  kernel_wide_arm64.go:328	0x1001761c4		f9404be0		MOVD 144(RSP), R0							
  kernel_wide_arm64.go:328	0x1001761c8		3d800014		FMOVQ F20, (R0)								
  kernel_wide_arm64.go:329	0x1001761cc		3d800413		FMOVQ F19, 16(R0)							
  kernel_wide_arm64.go:330	0x1001761d0		3d800812		FMOVQ F18, 32(R0)							
  kernel_wide_arm64.go:331	0x1001761d4		3d800c11		FMOVQ F17, 48(R0)							
  kernel_wide_arm64.go:332	0x1001761d8		f9405be0		MOVD 176(RSP), R0							
  kernel_wide_arm64.go:332	0x1001761dc		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:332	0x1001761e0		54000489		BLS 36(PC)								
  kernel_wide_arm64.go:333	0x1001761e4		f94057e0		MOVD 168(RSP), R0							
  kernel_wide_arm64.go:333	0x1001761e8		3d800010		FMOVQ F16, (R0)								
  kernel_wide_arm64.go:334	0x1001761ec		3d80040f		FMOVQ F15, 16(R0)							
  kernel_wide_arm64.go:335	0x1001761f0		3d80080e		FMOVQ F14, 32(R0)							
  kernel_wide_arm64.go:336	0x1001761f4		3d800c0d		FMOVQ F13, 48(R0)							
  kernel_wide_arm64.go:337	0x1001761f8		f94067e0		MOVD 200(RSP), R0							
  kernel_wide_arm64.go:337	0x1001761fc		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:337	0x100176200		54000369		BLS 27(PC)								
  kernel_wide_arm64.go:338	0x100176204		f94063e0		MOVD 192(RSP), R0							
  kernel_wide_arm64.go:338	0x100176208		3d80000c		FMOVQ F12, (R0)								
  kernel_wide_arm64.go:339	0x10017620c		3d80040b		FMOVQ F11, 16(R0)							
  kernel_wide_arm64.go:340	0x100176210		3d80080a		FMOVQ F10, 32(R0)							
  kernel_wide_arm64.go:341	0x100176214		3d800c09		FMOVQ F9, 48(R0)							
  kernel_wide_arm64.go:342	0x100176218		f94073e0		MOVD 224(RSP), R0							
  kernel_wide_arm64.go:342	0x10017621c		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:342	0x100176220		54000249		BLS 18(PC)								
  kernel_wide_arm64.go:343	0x100176224		f9406fe0		MOVD 216(RSP), R0							
  kernel_wide_arm64.go:343	0x100176228		3d800008		FMOVQ F8, (R0)								
  kernel_wide_arm64.go:344	0x10017622c		3d800407		FMOVQ F7, 16(R0)							
  kernel_wide_arm64.go:345	0x100176230		3d800806		FMOVQ F6, 32(R0)							
  kernel_wide_arm64.go:346	0x100176234		3d800c05		FMOVQ F5, 48(R0)							
  kernel_wide_arm64.go:347	0x100176238		f9407fe0		MOVD 248(RSP), R0							
  kernel_wide_arm64.go:347	0x10017623c		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:347	0x100176240		54000129		BLS 9(PC)								
  kernel_wide_arm64.go:348	0x100176244		f9407be0		MOVD 240(RSP), R0							
  kernel_wide_arm64.go:348	0x100176248		3d800004		FMOVQ F4, (R0)								
  kernel_wide_arm64.go:349	0x10017624c		3d800403		FMOVQ F3, 16(R0)							
  kernel_wide_arm64.go:350	0x100176250		3d800802		FMOVQ F2, 32(R0)							
  kernel_wide_arm64.go:351	0x100176254		3d800c00		FMOVQ F0, 48(R0)							
  kernel_wide_arm64.go:352	0x100176258		f85f83fd		MOVD -8(RSP), R29							
  kernel_wide_arm64.go:352	0x10017625c		f84407fe		MOVD.P 64(RSP), R30							
  kernel_wide_arm64.go:352	0x100176260		d65f03c0		RET									
  kernel_wide_arm64.go:347	0x100176264		97fc3d5f		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:342	0x100176268		97fc3d5e		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:337	0x10017626c		97fc3d5d		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:332	0x100176270		97fc3d5c		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:327	0x100176274		97fc3d5b		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:322	0x100176278		97fc3d5a		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:292	0x10017627c		97fc3d59		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:292	0x100176280		97fc3d58		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:278	0x100176284		97fc3d57		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:277	0x100176288		97fc3d56		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:276	0x10017628c		97fc3d55		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:275	0x100176290		97fc3d54		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:274	0x100176294		97fc3d53		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:273	0x100176298		97fc3d52		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:273	0x10017629c		d503201f		NOOP									
  kernel_wide_arm64.go:271	0x1001762a0		a90c87e0		STP (R0, R1), 200(RSP)							
  kernel_wide_arm64.go:271	0x1001762a4		a90d8fe2		STP (R2, R3), 216(RSP)							
  kernel_wide_arm64.go:271	0x1001762a8		a90e97e4		STP (R4, R5), 232(RSP)							
  kernel_wide_arm64.go:271	0x1001762ac		a90f9fe6		STP (R6, R7), 248(RSP)							
  kernel_wide_arm64.go:271	0x1001762b0		a910a7e8		STP (R8, R9), 264(RSP)							
  kernel_wide_arm64.go:271	0x1001762b4		a911afea		STP (R10, R11), 280(RSP)						
  kernel_wide_arm64.go:271	0x1001762b8		a912b7ec		STP (R12, R13), 296(RSP)						
  kernel_wide_arm64.go:271	0x1001762bc		f9009fee		MOVD R14, 312(RSP)							
  kernel_wide_arm64.go:271	0x1001762c0		aa1e03e3		MOVD R30, R3								
  kernel_wide_arm64.go:271	0x1001762c4		97fc3503		CALL runtime.morestack_noctxt.abi0(SB)					
  kernel_wide_arm64.go:271	0x1001762c8		a94c87e0		LDP 200(RSP), (R0, R1)							
  kernel_wide_arm64.go:271	0x1001762cc		a94d8fe2		LDP 216(RSP), (R2, R3)							
  kernel_wide_arm64.go:271	0x1001762d0		a94e97e4		LDP 232(RSP), (R4, R5)							
  kernel_wide_arm64.go:271	0x1001762d4		a94f9fe6		LDP 248(RSP), (R6, R7)							
  kernel_wide_arm64.go:271	0x1001762d8		a950a7e8		LDP 264(RSP), (R8, R9)							
  kernel_wide_arm64.go:271	0x1001762dc		a951afea		LDP 280(RSP), (R10, R11)						
  kernel_wide_arm64.go:271	0x1001762e0		a952b7ec		LDP 296(RSP), (R12, R13)						
  kernel_wide_arm64.go:271	0x1001762e4		f9409fee		MOVD 312(RSP), R14							
  kernel_wide_arm64.go:271	0x1001762e8		17ffff2a		JMP github.com/GetStream/gophonic/internal/whispergemm.kernel6x16(SB)	
  kernel_wide_arm64.go:271	0x1001762ec		00000000		?									

TEXT github.com/GetStream/gophonic/internal/whispergemm.kernel5x16(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/kernel_wide_arm64.go
  kernel_wide_arm64.go:354	0x1001762f0		f9400b90		MOVD 16(R28), R16							
  kernel_wide_arm64.go:354	0x1001762f4		eb3063ff		CMP R16, RSP								
  kernel_wide_arm64.go:354	0x1001762f8		54001449		BLS 162(PC)								
  kernel_wide_arm64.go:354	0x1001762fc		f81f0ffe		MOVD.W R30, -16(RSP)							
  kernel_wide_arm64.go:354	0x100176300		f81f83fd		MOVD R29, -8(RSP)							
  kernel_wide_arm64.go:354	0x100176304		d10023fd		SUB $8, RSP, R29							
  kernel_wide_arm64.go:354	0x100176308		f90057e0		MOVD R0, 168(RSP)							
  kernel_wide_arm64.go:354	0x10017630c		f90063e3		MOVD R3, 192(RSP)							
  kernel_wide_arm64.go:354	0x100176310		f9006fe6		MOVD R6, 216(RSP)							
  kernel_wide_arm64.go:354	0x100176314		f9007be9		MOVD R9, 240(RSP)							
  kernel_wide_arm64.go:354	0x100176318		f90087ec		MOVD R12, 264(RSP)							
  kernel_wide_arm64.go:356	0x10017631c		eb05003f		CMP R5, R1								
  kernel_wide_arm64.go:356	0x100176320		540012c8		BHI 150(PC)								
  kernel_wide_arm64.go:357	0x100176324		eb08003f		CMP R8, R1								
  kernel_wide_arm64.go:357	0x100176328		54001268		BHI 147(PC)								
  kernel_wide_arm64.go:358	0x10017632c		eb0b003f		CMP R11, R1								
  kernel_wide_arm64.go:358	0x100176330		54001208		BHI 144(PC)								
  kernel_wide_arm64.go:359	0x100176334		eb0e003f		CMP R14, R1								
  kernel_wide_arm64.go:359	0x100176338		540011a8		BHI 141(PC)								
  kernel_wide_arm64.go:360	0x10017633c		d37cec22		LSL $4, R1, R2								
  kernel_wide_arm64.go:360	0x100176340		f94017e4		MOVD 40(RSP), R4							
  kernel_wide_arm64.go:360	0x100176344		eb01109f		CMP R1<<4, R4								
  kernel_wide_arm64.go:360	0x100176348		54001103		BCC 136(PC)								
  kernel_wide_arm64.go:361	0x10017634c		4f00e400		VMOVI $0, V0.B16							
  other_gen_arm64.go:52		0x100176350		4f00e401		VMOVI $0, V1.B16							
  kernel_wide_arm64.go:366	0x100176354		aa1f03e4		MOVD ZR, R4								
  kernel_wide_arm64.go:366	0x100176358		f9400fe5		MOVD 24(RSP), R5							
  kernel_wide_arm64.go:366	0x10017635c		4ea01c02		VMOV V0.B16, V2.B16							
  kernel_wide_arm64.go:366	0x100176360		4ea21c43		VMOV V2.B16, V3.B16							
  kernel_wide_arm64.go:366	0x100176364		4ea31c64		VMOV V3.B16, V4.B16							
  kernel_wide_arm64.go:366	0x100176368		4ea41c85		VMOV V4.B16, V5.B16							
  kernel_wide_arm64.go:366	0x10017636c		4ea51ca6		VMOV V5.B16, V6.B16							
  kernel_wide_arm64.go:366	0x100176370		4ea61cc7		VMOV V6.B16, V7.B16							
  kernel_wide_arm64.go:366	0x100176374		4ea71ce8		VMOV V7.B16, V8.B16							
  kernel_wide_arm64.go:366	0x100176378		4ea81d09		VMOV V8.B16, V9.B16							
  kernel_wide_arm64.go:366	0x10017637c		4ea91d2a		VMOV V9.B16, V10.B16							
  kernel_wide_arm64.go:366	0x100176380		4eaa1d4b		VMOV V10.B16, V11.B16							
  kernel_wide_arm64.go:366	0x100176384		4eab1d6c		VMOV V11.B16, V12.B16							
  kernel_wide_arm64.go:366	0x100176388		4eac1d8d		VMOV V12.B16, V13.B16							
  kernel_wide_arm64.go:366	0x10017638c		4ead1dae		VMOV V13.B16, V14.B16							
  kernel_wide_arm64.go:366	0x100176390		4eae1dcf		VMOV V14.B16, V15.B16							
  kernel_wide_arm64.go:366	0x100176394		4eaf1df0		VMOV V15.B16, V16.B16							
  kernel_wide_arm64.go:366	0x100176398		4eb01e11		VMOV V16.B16, V17.B16							
  kernel_wide_arm64.go:366	0x10017639c		4eb11e32		VMOV V17.B16, V18.B16							
  kernel_wide_arm64.go:366	0x1001763a0		4eb21e53		VMOV V18.B16, V19.B16							
  kernel_wide_arm64.go:366	0x1001763a4		4eb31e74		VMOV V19.B16, V20.B16							
  kernel_wide_arm64.go:366	0x1001763a8		14000021		JMP 33(PC)								
  kernel_wide_arm64.go:372	0x1001763ac		8b0418a7		ADD R4<<6, R5, R7							
  kernel_wide_arm64.go:373	0x1001763b0		3dc000fa		FMOVQ (R7), F26								
  kernel_wide_arm64.go:379	0x1001763b4		3dc004fb		FMOVQ 16(R7), F27							
  kernel_wide_arm64.go:385	0x1001763b8		3dc008fc		FMOVQ 32(R7), F28							
  kernel_wide_arm64.go:391	0x1001763bc		3dc00cfd		FMOVQ 48(R7), F29							
  other_gen_arm64.go:53		0x1001763c0		4e04043e		VDUP V1.S[0], V30.S4							
  other_gen_arm64.go:53		0x1001763c4		4e0406b5		VDUP V21.S[0], V21.S4							
  other_gen_arm64.go:53		0x1001763c8		4e0406d6		VDUP V22.S[0], V22.S4							
  other_gen_arm64.go:53		0x1001763cc		4e0406f7		VDUP V23.S[0], V23.S4							
  other_gen_arm64.go:53		0x1001763d0		4e040718		VDUP V24.S[0], V24.S4							
  kernel_wide_arm64.go:374	0x1001763d4		4e3ecf54		VFMLA V30.S4, V26.S4, V20.S4						
  kernel_wide_arm64.go:375	0x1001763d8		4e35cf50		VFMLA V21.S4, V26.S4, V16.S4						
  kernel_wide_arm64.go:376	0x1001763dc		4e36cf4c		VFMLA V22.S4, V26.S4, V12.S4						
  kernel_wide_arm64.go:377	0x1001763e0		4e37cf48		VFMLA V23.S4, V26.S4, V8.S4						
  kernel_wide_arm64.go:378	0x1001763e4		4e38cf44		VFMLA V24.S4, V26.S4, V4.S4						
  kernel_wide_arm64.go:380	0x1001763e8		4e3ecf73		VFMLA V30.S4, V27.S4, V19.S4						
  kernel_wide_arm64.go:381	0x1001763ec		4e35cf6f		VFMLA V21.S4, V27.S4, V15.S4						
  kernel_wide_arm64.go:382	0x1001763f0		4e36cf6b		VFMLA V22.S4, V27.S4, V11.S4						
  kernel_wide_arm64.go:383	0x1001763f4		4e37cf67		VFMLA V23.S4, V27.S4, V7.S4						
  kernel_wide_arm64.go:384	0x1001763f8		4e38cf63		VFMLA V24.S4, V27.S4, V3.S4						
  kernel_wide_arm64.go:386	0x1001763fc		4e3ecf92		VFMLA V30.S4, V28.S4, V18.S4						
  kernel_wide_arm64.go:387	0x100176400		4e35cf8e		VFMLA V21.S4, V28.S4, V14.S4						
  kernel_wide_arm64.go:388	0x100176404		4e36cf8a		VFMLA V22.S4, V28.S4, V10.S4						
  kernel_wide_arm64.go:389	0x100176408		4e37cf86		VFMLA V23.S4, V28.S4, V6.S4						
  kernel_wide_arm64.go:390	0x10017640c		4e38cf82		VFMLA V24.S4, V28.S4, V2.S4						
  kernel_wide_arm64.go:392	0x100176410		4e3ecfb1		VFMLA V30.S4, V29.S4, V17.S4						
  kernel_wide_arm64.go:393	0x100176414		4e35cfad		VFMLA V21.S4, V29.S4, V13.S4						
  kernel_wide_arm64.go:394	0x100176418		4e36cfa9		VFMLA V22.S4, V29.S4, V9.S4						
  kernel_wide_arm64.go:395	0x10017641c		4e37cfa5		VFMLA V23.S4, V29.S4, V5.S4						
  kernel_wide_arm64.go:396	0x100176420		4e38cfa0		VFMLA V24.S4, V29.S4, V0.S4						
  kernel_wide_arm64.go:366	0x100176424		91000484		ADD $1, R4, R4								
  other_gen_arm64.go:53		0x100176428		4eb91f21		VMOV V25.B16, V1.B16							
  kernel_wide_arm64.go:366	0x10017642c		eb04003f		CMP R4, R1								
  kernel_wide_arm64.go:366	0x100176430		5400038d		BLE 28(PC)								
  kernel_wide_arm64.go:367	0x100176434		bc647815		FMOVS (R0)(R4<<2), F21							
  kernel_wide_arm64.go:368	0x100176438		bc647876		FMOVS (R3)(R4<<2), F22							
  kernel_wide_arm64.go:369	0x10017643c		bc6478d7		FMOVS (R6)(R4<<2), F23							
  kernel_wide_arm64.go:370	0x100176440		bc647938		FMOVS (R9)(R4<<2), F24							
  kernel_wide_arm64.go:371	0x100176444		bc647999		FMOVS (R12)(R4<<2), F25							
  kernel_wide_arm64.go:372	0x100176448		d37cec87		LSL $4, R4, R7								
  kernel_wide_arm64.go:372	0x10017644c		910040e8		ADD $16, R7, R8								
  unsafe.go:24			0x100176450		1e2602aa		FMOVS F21, R10								
  unsafe.go:24			0x100176454		1e2602cb		FMOVS F22, R11								
  unsafe.go:24			0x100176458		1e2602ed		FMOVS F23, R13								
  unsafe.go:24			0x10017645c		1e26030e		FMOVS F24, R14								
  unsafe.go:24			0x100176460		1e26032f		FMOVS F25, R15								
  other_gen_arm64.go:53		0x100176464		4ea11c35		VMOV V1.B16, V21.B16							
  other_gen_arm64.go:53		0x100176468		4e041d41		VMOV R10, V1.S[0]							
  other_gen_arm64.go:53		0x10017646c		4eb51eb6		VMOV V21.B16, V22.B16							
  other_gen_arm64.go:53		0x100176470		4e041d75		VMOV R11, V21.S[0]							
  other_gen_arm64.go:53		0x100176474		4eb61ed7		VMOV V22.B16, V23.B16							
  other_gen_arm64.go:53		0x100176478		4e041db6		VMOV R13, V22.S[0]							
  other_gen_arm64.go:53		0x10017647c		4eb71ef8		VMOV V23.B16, V24.B16							
  other_gen_arm64.go:53		0x100176480		4e041dd7		VMOV R14, V23.S[0]							
  other_gen_arm64.go:53		0x100176484		4eb81f19		VMOV V24.B16, V25.B16							
  other_gen_arm64.go:53		0x100176488		4e041df8		VMOV R15, V24.S[0]							
  kernel_wide_arm64.go:372	0x10017648c		eb01111f		CMP R1<<4, R8								
  kernel_wide_arm64.go:372	0x100176490		540006a8		BHI 53(PC)								
  kernel_wide_arm64.go:372	0x100176494		eb04111f		CMP R4<<4, R8								
  kernel_wide_arm64.go:372	0x100176498		54fff8a2		BCS -59(PC)								
  kernel_wide_arm64.go:372	0x10017649c		14000031		JMP 49(PC)								
  kernel_wide_arm64.go:398	0x1001764a0		f9401fe0		MOVD 56(RSP), R0							
  kernel_wide_arm64.go:398	0x1001764a4		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:398	0x1001764a8		540005a9		BLS 45(PC)								
  kernel_wide_arm64.go:399	0x1001764ac		f9401be0		MOVD 48(RSP), R0							
  kernel_wide_arm64.go:399	0x1001764b0		3d800014		FMOVQ F20, (R0)								
  kernel_wide_arm64.go:400	0x1001764b4		3d800413		FMOVQ F19, 16(R0)							
  kernel_wide_arm64.go:401	0x1001764b8		3d800812		FMOVQ F18, 32(R0)							
  kernel_wide_arm64.go:402	0x1001764bc		3d800c11		FMOVQ F17, 48(R0)							
  kernel_wide_arm64.go:403	0x1001764c0		f9402be0		MOVD 80(RSP), R0							
  kernel_wide_arm64.go:403	0x1001764c4		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:403	0x1001764c8		54000489		BLS 36(PC)								
  kernel_wide_arm64.go:404	0x1001764cc		f94027e0		MOVD 72(RSP), R0							
  kernel_wide_arm64.go:404	0x1001764d0		3d800010		FMOVQ F16, (R0)								
  kernel_wide_arm64.go:405	0x1001764d4		3d80040f		FMOVQ F15, 16(R0)							
  kernel_wide_arm64.go:406	0x1001764d8		3d80080e		FMOVQ F14, 32(R0)							
  kernel_wide_arm64.go:407	0x1001764dc		3d800c0d		FMOVQ F13, 48(R0)							
  kernel_wide_arm64.go:408	0x1001764e0		f94037e0		MOVD 104(RSP), R0							
  kernel_wide_arm64.go:408	0x1001764e4		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:408	0x1001764e8		54000369		BLS 27(PC)								
  kernel_wide_arm64.go:409	0x1001764ec		f94033e0		MOVD 96(RSP), R0							
  kernel_wide_arm64.go:409	0x1001764f0		3d80000c		FMOVQ F12, (R0)								
  kernel_wide_arm64.go:410	0x1001764f4		3d80040b		FMOVQ F11, 16(R0)							
  kernel_wide_arm64.go:411	0x1001764f8		3d80080a		FMOVQ F10, 32(R0)							
  kernel_wide_arm64.go:412	0x1001764fc		3d800c09		FMOVQ F9, 48(R0)							
  kernel_wide_arm64.go:413	0x100176500		f94043e0		MOVD 128(RSP), R0							
  kernel_wide_arm64.go:413	0x100176504		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:413	0x100176508		54000249		BLS 18(PC)								
  kernel_wide_arm64.go:414	0x10017650c		f9403fe0		MOVD 120(RSP), R0							
  kernel_wide_arm64.go:414	0x100176510		3d800008		FMOVQ F8, (R0)								
  kernel_wide_arm64.go:415	0x100176514		3d800407		FMOVQ F7, 16(R0)							
  kernel_wide_arm64.go:416	0x100176518		3d800806		FMOVQ F6, 32(R0)							
  kernel_wide_arm64.go:417	0x10017651c		3d800c05		FMOVQ F5, 48(R0)							
  kernel_wide_arm64.go:418	0x100176520		f9404fe0		MOVD 152(RSP), R0							
  kernel_wide_arm64.go:418	0x100176524		f1003c1f		CMP $15, R0								
  kernel_wide_arm64.go:418	0x100176528		54000129		BLS 9(PC)								
  kernel_wide_arm64.go:419	0x10017652c		f9404be0		MOVD 144(RSP), R0							
  kernel_wide_arm64.go:419	0x100176530		3d800004		FMOVQ F4, (R0)								
  kernel_wide_arm64.go:420	0x100176534		3d800403		FMOVQ F3, 16(R0)							
  kernel_wide_arm64.go:421	0x100176538		3d800802		FMOVQ F2, 32(R0)							
  kernel_wide_arm64.go:422	0x10017653c		3d800c00		FMOVQ F0, 48(R0)							
  kernel_wide_arm64.go:423	0x100176540		f85f83fd		MOVD -8(RSP), R29							
  kernel_wide_arm64.go:423	0x100176544		f84107fe		MOVD.P 16(RSP), R30							
  kernel_wide_arm64.go:423	0x100176548		d65f03c0		RET									
  kernel_wide_arm64.go:418	0x10017654c		97fc3ca5		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:413	0x100176550		97fc3ca4		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:408	0x100176554		97fc3ca3		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:403	0x100176558		97fc3ca2		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:398	0x10017655c		97fc3ca1		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:372	0x100176560		97fc3ca0		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:372	0x100176564		97fc3c9f		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:360	0x100176568		97fc3c9e		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:359	0x10017656c		97fc3c9d		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:358	0x100176570		97fc3c9c		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:357	0x100176574		97fc3c9b		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:356	0x100176578		97fc3c9a		CALL runtime.panicBounds(SB)						
  kernel_wide_arm64.go:356	0x10017657c		d503201f		NOOP									
  kernel_wide_arm64.go:354	0x100176580		a90987e0		STP (R0, R1), 152(RSP)							
  kernel_wide_arm64.go:354	0x100176584		a90a8fe2		STP (R2, R3), 168(RSP)							
  kernel_wide_arm64.go:354	0x100176588		a90b97e4		STP (R4, R5), 184(RSP)							
  kernel_wide_arm64.go:354	0x10017658c		a90c9fe6		STP (R6, R7), 200(RSP)							
  kernel_wide_arm64.go:354	0x100176590		a90da7e8		STP (R8, R9), 216(RSP)							
  kernel_wide_arm64.go:354	0x100176594		a90eafea		STP (R10, R11), 232(RSP)						
  kernel_wide_arm64.go:354	0x100176598		a90fb7ec		STP (R12, R13), 248(RSP)						
  kernel_wide_arm64.go:354	0x10017659c		f90087ee		MOVD R14, 264(RSP)							
  kernel_wide_arm64.go:354	0x1001765a0		aa1e03e3		MOVD R30, R3								
  kernel_wide_arm64.go:354	0x1001765a4		97fc344b		CALL runtime.morestack_noctxt.abi0(SB)					
  kernel_wide_arm64.go:354	0x1001765a8		a94987e0		LDP 152(RSP), (R0, R1)							
  kernel_wide_arm64.go:354	0x1001765ac		a94a8fe2		LDP 168(RSP), (R2, R3)							
  kernel_wide_arm64.go:354	0x1001765b0		a94b97e4		LDP 184(RSP), (R4, R5)							
  kernel_wide_arm64.go:354	0x1001765b4		a94c9fe6		LDP 200(RSP), (R6, R7)							
  kernel_wide_arm64.go:354	0x1001765b8		a94da7e8		LDP 216(RSP), (R8, R9)							
  kernel_wide_arm64.go:354	0x1001765bc		a94eafea		LDP 232(RSP), (R10, R11)						
  kernel_wide_arm64.go:354	0x1001765c0		a94fb7ec		LDP 248(RSP), (R12, R13)						
  kernel_wide_arm64.go:354	0x1001765c4		f94087ee		MOVD 264(RSP), R14							
  kernel_wide_arm64.go:354	0x1001765c8		17ffff4a		JMP github.com/GetStream/gophonic/internal/whispergemm.kernel5x16(SB)	
  kernel_wide_arm64.go:354	0x1001765cc		00000000		?									
