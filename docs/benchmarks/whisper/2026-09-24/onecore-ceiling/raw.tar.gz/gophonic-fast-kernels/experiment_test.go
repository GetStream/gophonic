//go:build goexperiment.simd && arm64
package whispergemm
import("encoding/json";"os";"runtime";"testing";"time")
func TestFastKernelShapes(t *testing.T) {
 runtime.GOMAXPROCS(1)
 type sample struct{Shape string;Mode int;Nanoseconds int64}
 var samples []sample
 for _,s:=range []struct{Name string;M,K,N,Reps int}{
 {"fast_qk",32,64,608,40},{"fast_pv",32,608,64,40},{"fast_projection",608,384,384,2},{"fast_expand",608,384,1536,1},{"fast_contract",608,1536,384,1},{"fast_conv2",608,1152,384,1},{"full_projection",1500,384,384,1},{"full_expand",1500,384,1536,1},{"full_contract",1500,1536,384,1},
 } {
  a,_,dst,b:=benchmarkData(t,s.M,s.K,s.N)
  for cycle:=0;cycle<16;cycle++ {for j:=0;j<4;j++ {
   mode:=(j+cycle)%4;kernelExperimentMode=mode
   if err:=b.Mul(dst,s.N,a,s.K,s.M);err!=nil{t.Fatal(err)}
   start:=time.Now();for r:=0;r<s.Reps;r++ {if err:=b.Mul(dst,s.N,a,s.K,s.M);err!=nil{t.Fatal(err)}}
   samples=append(samples,sample{s.Name,mode,time.Since(start).Nanoseconds()/int64(s.Reps)})
  }}
  benchmarkSink=dst[len(dst)-1]
 }
 data,err:=json.Marshal(samples);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/shapes.json",data,0644);err!=nil{t.Fatal(err)}
}
func TestFastKernelExact(t *testing.T) {
 for _,mode:=range []int{1,2,3} {kernelExperimentMode=mode;t.Run("order",TestWideGEMMPreservesFourRowOrder);t.Run("special",TestWideGEMMSpecialValues)}
}
