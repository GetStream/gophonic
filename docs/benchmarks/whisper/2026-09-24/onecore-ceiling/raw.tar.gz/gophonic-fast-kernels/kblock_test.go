//go:build goexperiment.simd && arm64
package whispergemm
import("encoding/json";"os";"runtime";"testing";"time")
func TestKBlockShapes(t *testing.T) {
 runtime.GOMAXPROCS(1)
 type sample struct{Shape string;Mode int;Nanoseconds int64}
 var samples []sample
 for _,s:=range []struct{Name string;M,K,N,Reps int}{
 {"full_qk",32,64,1500,8},{"full_pv",32,1500,64,8},{"full_conv2",1500,1152,384,1},{"full_projection",1500,384,384,1},{"full_expand",1500,384,1536,1},{"full_contract",1500,1536,384,1},
 } {
  a,_,dst,b:=benchmarkData(t,s.M,s.K,s.N)
  for cycle:=0;cycle<18;cycle++ {for j:=0;j<6;j++ {
   mode:=[]int{0,128,256,384,512,768}[(j+cycle)%6];kBlockExperiment=mode
   if err:=b.Mul(dst,s.N,a,s.K,s.M);err!=nil{t.Fatal(err)}
   start:=time.Now();for r:=0;r<s.Reps;r++ {if err:=b.Mul(dst,s.N,a,s.K,s.M);err!=nil{t.Fatal(err)}}
   samples=append(samples,sample{s.Name,mode,time.Since(start).Nanoseconds()/int64(s.Reps)})
  }}
  benchmarkSink=dst[len(dst)-1]
 }
 data,err:=json.Marshal(samples);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/kblock-shapes.json",data,0644);err!=nil{t.Fatal(err)}
}
func TestKBlockExact(t *testing.T) {
 for _,mode:=range []int{128,256,384,512,768} {kBlockExperiment=mode;t.Run("order",TestWideGEMMPreservesFourRowOrder);t.Run("special",TestWideGEMMSpecialValues)}
}
