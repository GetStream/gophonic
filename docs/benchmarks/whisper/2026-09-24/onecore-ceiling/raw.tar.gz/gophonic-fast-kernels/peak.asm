TEXT github.com/GetStream/gophonic/internal/whispergemm.peakFMA(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/peak_experiment_test.go
  peak_experiment_test.go:4	0x10017c460		f9400b90		MOVD 16(R28), R16							
  peak_experiment_test.go:4	0x10017c464		eb3063ff		CMP R16, RSP								
  peak_experiment_test.go:4	0x10017c468		54001749		BLS 186(PC)								
  peak_experiment_test.go:4	0x10017c46c		f81f0ffe		MOVD.W R30, -16(RSP)							
  peak_experiment_test.go:4	0x10017c470		f81f83fd		MOVD R29, -8(RSP)							
  peak_experiment_test.go:4	0x10017c474		d10023fd		SUB $8, RSP, R29							
  peak_experiment_test.go:4	0x10017c478		f9000fe0		MOVD R0, 24(RSP)							
  peak_experiment_test.go:4	0x10017c47c		f9001be3		MOVD R3, 48(RSP)							
  peak_experiment_test.go:5	0x10017c480		f10010bf		CMP $4, R5								
  peak_experiment_test.go:5	0x10017c484		54001623		BCC 177(PC)								
  peak_experiment_test.go:6	0x10017c488		f10020bf		CMP $8, R5								
  peak_experiment_test.go:6	0x10017c48c		540015c3		BCC 174(PC)								
  peak_experiment_test.go:7	0x10017c490		f10030bf		CMP $12, R5								
  peak_experiment_test.go:7	0x10017c494		54001563		BCC 171(PC)								
  peak_experiment_test.go:8	0x10017c498		f10040bf		CMP $16, R5								
  peak_experiment_test.go:8	0x10017c49c		54001503		BCC 168(PC)								
  peak_experiment_test.go:9	0x10017c4a0		f10050bf		CMP $20, R5								
  peak_experiment_test.go:9	0x10017c4a4		540014a3		BCC 165(PC)								
  peak_experiment_test.go:10	0x10017c4a8		f10060bf		CMP $24, R5								
  peak_experiment_test.go:10	0x10017c4ac		54001443		BCC 162(PC)								
  peak_experiment_test.go:11	0x10017c4b0		f10070bf		CMP $28, R5								
  peak_experiment_test.go:11	0x10017c4b4		540013e3		BCC 159(PC)								
  peak_experiment_test.go:12	0x10017c4b8		f10080bf		CMP $32, R5								
  peak_experiment_test.go:12	0x10017c4bc		54001363		BCC 155(PC)								
  peak_experiment_test.go:13	0x10017c4c0		f10090bf		CMP $36, R5								
  peak_experiment_test.go:13	0x10017c4c4		540012e3		BCC 151(PC)								
  peak_experiment_test.go:14	0x10017c4c8		f100a0bf		CMP $40, R5								
  peak_experiment_test.go:14	0x10017c4cc		54001263		BCC 147(PC)								
  peak_experiment_test.go:15	0x10017c4d0		f100b0bf		CMP $44, R5								
  peak_experiment_test.go:15	0x10017c4d4		540011e3		BCC 143(PC)								
  peak_experiment_test.go:16	0x10017c4d8		f100c0bf		CMP $48, R5								
  peak_experiment_test.go:16	0x10017c4dc		54001163		BCC 139(PC)								
  peak_experiment_test.go:17	0x10017c4e0		f100d0bf		CMP $52, R5								
  peak_experiment_test.go:17	0x10017c4e4		540010e3		BCC 135(PC)								
  peak_experiment_test.go:18	0x10017c4e8		f100e0bf		CMP $56, R5								
  peak_experiment_test.go:18	0x10017c4ec		54001063		BCC 131(PC)								
  peak_experiment_test.go:19	0x10017c4f0		f100f0bf		CMP $60, R5								
  peak_experiment_test.go:19	0x10017c4f4		54000fe3		BCC 127(PC)								
  peak_experiment_test.go:20	0x10017c4f8		f10100bf		CMP $64, R5								
  peak_experiment_test.go:20	0x10017c4fc		54000f63		BCC 123(PC)								
  peak_experiment_test.go:21	0x10017c500		f10110bf		CMP $68, R5								
  peak_experiment_test.go:21	0x10017c504		54000ee3		BCC 119(PC)								
  peak_experiment_test.go:21	0x10017c508		f10120bf		CMP $72, R5								
  peak_experiment_test.go:21	0x10017c50c		54000e63		BCC 115(PC)								
  peak_experiment_test.go:5	0x10017c510		3dc00060		FMOVQ (R3), F0								
  peak_experiment_test.go:6	0x10017c514		3dc00461		FMOVQ 16(R3), F1							
  peak_experiment_test.go:7	0x10017c518		3dc00862		FMOVQ 32(R3), F2							
  peak_experiment_test.go:8	0x10017c51c		3dc00c63		FMOVQ 48(R3), F3							
  peak_experiment_test.go:9	0x10017c520		3dc01064		FMOVQ 64(R3), F4							
  peak_experiment_test.go:10	0x10017c524		3dc01465		FMOVQ 80(R3), F5							
  peak_experiment_test.go:11	0x10017c528		3dc01866		FMOVQ 96(R3), F6							
  peak_experiment_test.go:12	0x10017c52c		3dc01c67		FMOVQ 112(R3), F7							
  peak_experiment_test.go:13	0x10017c530		3dc02068		FMOVQ 128(R3), F8							
  peak_experiment_test.go:14	0x10017c534		3dc02469		FMOVQ 144(R3), F9							
  peak_experiment_test.go:15	0x10017c538		3dc0286a		FMOVQ 160(R3), F10							
  peak_experiment_test.go:16	0x10017c53c		3dc02c6b		FMOVQ 176(R3), F11							
  peak_experiment_test.go:17	0x10017c540		3dc0306c		FMOVQ 192(R3), F12							
  peak_experiment_test.go:18	0x10017c544		3dc0346d		FMOVQ 208(R3), F13							
  peak_experiment_test.go:19	0x10017c548		3dc0386e		FMOVQ 224(R3), F14							
  peak_experiment_test.go:20	0x10017c54c		3dc03c6f		FMOVQ 240(R3), F15							
  peak_experiment_test.go:21	0x10017c550		3dc04070		FMOVQ 256(R3), F16							
  peak_experiment_test.go:21	0x10017c554		3dc04471		FMOVQ 272(R3), F17							
  peak_experiment_test.go:22	0x10017c558		14000012		JMP 18(PC)								
  peak_experiment_test.go:23	0x10017c55c		4e31ce00		VFMLA V17.S4, V16.S4, V0.S4						
  peak_experiment_test.go:24	0x10017c560		4e31ce01		VFMLA V17.S4, V16.S4, V1.S4						
  peak_experiment_test.go:25	0x10017c564		4e31ce02		VFMLA V17.S4, V16.S4, V2.S4						
  peak_experiment_test.go:26	0x10017c568		4e31ce03		VFMLA V17.S4, V16.S4, V3.S4						
  peak_experiment_test.go:27	0x10017c56c		4e31ce04		VFMLA V17.S4, V16.S4, V4.S4						
  peak_experiment_test.go:28	0x10017c570		4e31ce05		VFMLA V17.S4, V16.S4, V5.S4						
  peak_experiment_test.go:29	0x10017c574		4e31ce06		VFMLA V17.S4, V16.S4, V6.S4						
  peak_experiment_test.go:30	0x10017c578		4e31ce07		VFMLA V17.S4, V16.S4, V7.S4						
  peak_experiment_test.go:31	0x10017c57c		4e31ce08		VFMLA V17.S4, V16.S4, V8.S4						
  peak_experiment_test.go:32	0x10017c580		4e31ce09		VFMLA V17.S4, V16.S4, V9.S4						
  peak_experiment_test.go:33	0x10017c584		4e31ce0a		VFMLA V17.S4, V16.S4, V10.S4						
  peak_experiment_test.go:34	0x10017c588		4e31ce0b		VFMLA V17.S4, V16.S4, V11.S4						
  peak_experiment_test.go:35	0x10017c58c		4e31ce0c		VFMLA V17.S4, V16.S4, V12.S4						
  peak_experiment_test.go:36	0x10017c590		4e31ce0d		VFMLA V17.S4, V16.S4, V13.S4						
  peak_experiment_test.go:37	0x10017c594		4e31ce0e		VFMLA V17.S4, V16.S4, V14.S4						
  peak_experiment_test.go:38	0x10017c598		4e31ce0f		VFMLA V17.S4, V16.S4, V15.S4						
  peak_experiment_test.go:22	0x10017c59c		d10004c6		SUB $1, R6, R6								
  peak_experiment_test.go:22	0x10017c5a0		f10000df		CMP $0, R6								
  peak_experiment_test.go:22	0x10017c5a4		54fffdcc		BGT -18(PC)								
  peak_experiment_test.go:40	0x10017c5a8		f100105f		CMP $4, R2								
  peak_experiment_test.go:40	0x10017c5ac		54000943		BCC 74(PC)								
  peak_experiment_test.go:40	0x10017c5b0		3d800000		FMOVQ F0, (R0)								
  peak_experiment_test.go:41	0x10017c5b4		f100205f		CMP $8, R2								
  peak_experiment_test.go:41	0x10017c5b8		540008c3		BCC 70(PC)								
  peak_experiment_test.go:41	0x10017c5bc		3d800401		FMOVQ F1, 16(R0)							
  peak_experiment_test.go:42	0x10017c5c0		f100305f		CMP $12, R2								
  peak_experiment_test.go:42	0x10017c5c4		54000843		BCC 66(PC)								
  peak_experiment_test.go:42	0x10017c5c8		3d800802		FMOVQ F2, 32(R0)							
  peak_experiment_test.go:43	0x10017c5cc		f100405f		CMP $16, R2								
  peak_experiment_test.go:43	0x10017c5d0		540007c3		BCC 62(PC)								
  peak_experiment_test.go:43	0x10017c5d4		3d800c03		FMOVQ F3, 48(R0)							
  peak_experiment_test.go:44	0x10017c5d8		f100505f		CMP $20, R2								
  peak_experiment_test.go:44	0x10017c5dc		54000743		BCC 58(PC)								
  peak_experiment_test.go:44	0x10017c5e0		3d801004		FMOVQ F4, 64(R0)							
  peak_experiment_test.go:45	0x10017c5e4		f100605f		CMP $24, R2								
  peak_experiment_test.go:45	0x10017c5e8		540006c3		BCC 54(PC)								
  peak_experiment_test.go:45	0x10017c5ec		3d801405		FMOVQ F5, 80(R0)							
  peak_experiment_test.go:46	0x10017c5f0		f100705f		CMP $28, R2								
  peak_experiment_test.go:46	0x10017c5f4		54000643		BCC 50(PC)								
  peak_experiment_test.go:46	0x10017c5f8		3d801806		FMOVQ F6, 96(R0)							
  peak_experiment_test.go:47	0x10017c5fc		f100805f		CMP $32, R2								
  peak_experiment_test.go:47	0x10017c600		540005a3		BCC 45(PC)								
  peak_experiment_test.go:47	0x10017c604		3d801c07		FMOVQ F7, 112(R0)							
  peak_experiment_test.go:48	0x10017c608		f100905f		CMP $36, R2								
  peak_experiment_test.go:48	0x10017c60c		54000503		BCC 40(PC)								
  peak_experiment_test.go:48	0x10017c610		3d802008		FMOVQ F8, 128(R0)							
  peak_experiment_test.go:49	0x10017c614		f100a05f		CMP $40, R2								
  peak_experiment_test.go:49	0x10017c618		54000463		BCC 35(PC)								
  peak_experiment_test.go:49	0x10017c61c		3d802409		FMOVQ F9, 144(R0)							
  peak_experiment_test.go:50	0x10017c620		f100b05f		CMP $44, R2								
  peak_experiment_test.go:50	0x10017c624		540003c3		BCC 30(PC)								
  peak_experiment_test.go:50	0x10017c628		3d80280a		FMOVQ F10, 160(R0)							
  peak_experiment_test.go:51	0x10017c62c		f100c05f		CMP $48, R2								
  peak_experiment_test.go:51	0x10017c630		54000323		BCC 25(PC)								
  peak_experiment_test.go:51	0x10017c634		3d802c0b		FMOVQ F11, 176(R0)							
  peak_experiment_test.go:52	0x10017c638		f100d05f		CMP $52, R2								
  peak_experiment_test.go:52	0x10017c63c		54000283		BCC 20(PC)								
  peak_experiment_test.go:52	0x10017c640		3d80300c		FMOVQ F12, 192(R0)							
  peak_experiment_test.go:53	0x10017c644		f100e05f		CMP $56, R2								
  peak_experiment_test.go:53	0x10017c648		540001e3		BCC 15(PC)								
  peak_experiment_test.go:53	0x10017c64c		3d80340d		FMOVQ F13, 208(R0)							
  peak_experiment_test.go:54	0x10017c650		f100f05f		CMP $60, R2								
  peak_experiment_test.go:54	0x10017c654		54000143		BCC 10(PC)								
  peak_experiment_test.go:54	0x10017c658		3d80380e		FMOVQ F14, 224(R0)							
  peak_experiment_test.go:55	0x10017c65c		f101005f		CMP $64, R2								
  peak_experiment_test.go:55	0x10017c660		540000a3		BCC 5(PC)								
  peak_experiment_test.go:55	0x10017c664		3d803c0f		FMOVQ F15, 240(R0)							
  peak_experiment_test.go:56	0x10017c668		f85f83fd		MOVD -8(RSP), R29							
  peak_experiment_test.go:56	0x10017c66c		f84107fe		MOVD.P 16(RSP), R30							
  peak_experiment_test.go:56	0x10017c670		d65f03c0		RET									
  peak_experiment_test.go:55	0x10017c674		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:55	0x10017c678		97fc245a		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:54	0x10017c67c		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:54	0x10017c680		97fc2458		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:53	0x10017c684		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:53	0x10017c688		97fc2456		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:52	0x10017c68c		d2800680		MOVD $52, R0								
  peak_experiment_test.go:52	0x10017c690		97fc2454		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:51	0x10017c694		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:51	0x10017c698		97fc2452		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:50	0x10017c69c		d2800580		MOVD $44, R0								
  peak_experiment_test.go:50	0x10017c6a0		97fc2450		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:49	0x10017c6a4		d2800500		MOVD $40, R0								
  peak_experiment_test.go:49	0x10017c6a8		97fc244e		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:48	0x10017c6ac		d2800480		MOVD $36, R0								
  peak_experiment_test.go:48	0x10017c6b0		97fc244c		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:47	0x10017c6b4		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:47	0x10017c6b8		97fc244a		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:46	0x10017c6bc		97fc2449		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:45	0x10017c6c0		97fc2448		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:44	0x10017c6c4		97fc2447		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:43	0x10017c6c8		97fc2446		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:42	0x10017c6cc		97fc2445		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:41	0x10017c6d0		97fc2444		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:40	0x10017c6d4		97fc2443		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:21	0x10017c6d8		d2800900		MOVD $72, R0								
  peak_experiment_test.go:21	0x10017c6dc		97fc2441		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:21	0x10017c6e0		d2800880		MOVD $68, R0								
  peak_experiment_test.go:21	0x10017c6e4		97fc243f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:20	0x10017c6e8		b27a03e0		ORR $64, ZR, R0								
  peak_experiment_test.go:20	0x10017c6ec		97fc243d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:19	0x10017c6f0		b27e0fe0		ORR $60, ZR, R0								
  peak_experiment_test.go:19	0x10017c6f4		97fc243b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:18	0x10017c6f8		b27d0be0		ORR $56, ZR, R0								
  peak_experiment_test.go:18	0x10017c6fc		97fc2439		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:17	0x10017c700		d2800680		MOVD $52, R0								
  peak_experiment_test.go:17	0x10017c704		97fc2437		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:16	0x10017c708		b27c07e0		ORR $48, ZR, R0								
  peak_experiment_test.go:16	0x10017c70c		97fc2435		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:15	0x10017c710		d2800580		MOVD $44, R0								
  peak_experiment_test.go:15	0x10017c714		97fc2433		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:14	0x10017c718		d2800500		MOVD $40, R0								
  peak_experiment_test.go:14	0x10017c71c		97fc2431		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:13	0x10017c720		d2800480		MOVD $36, R0								
  peak_experiment_test.go:13	0x10017c724		97fc242f		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:12	0x10017c728		b27b03e0		ORR $32, ZR, R0								
  peak_experiment_test.go:12	0x10017c72c		97fc242d		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:11	0x10017c730		97fc242c		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:10	0x10017c734		97fc242b		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:9	0x10017c738		97fc242a		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:8	0x10017c73c		97fc2429		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:7	0x10017c740		97fc2428		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:6	0x10017c744		97fc2427		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:5	0x10017c748		97fc2426		CALL runtime.panicBounds(SB)						
  peak_experiment_test.go:5	0x10017c74c		d503201f		NOOP									
  peak_experiment_test.go:4	0x10017c750		a90087e0		STP (R0, R1), 8(RSP)							
  peak_experiment_test.go:4	0x10017c754		a9018fe2		STP (R2, R3), 24(RSP)							
  peak_experiment_test.go:4	0x10017c758		a90297e4		STP (R4, R5), 40(RSP)							
  peak_experiment_test.go:4	0x10017c75c		f9001fe6		MOVD R6, 56(RSP)							
  peak_experiment_test.go:4	0x10017c760		aa1e03e3		MOVD R30, R3								
  peak_experiment_test.go:4	0x10017c764		97fc1bdb		CALL runtime.morestack_noctxt.abi0(SB)					
  peak_experiment_test.go:4	0x10017c768		a94087e0		LDP 8(RSP), (R0, R1)							
  peak_experiment_test.go:4	0x10017c76c		a9418fe2		LDP 24(RSP), (R2, R3)							
  peak_experiment_test.go:4	0x10017c770		a94297e4		LDP 40(RSP), (R4, R5)							
  peak_experiment_test.go:4	0x10017c774		f9401fe6		MOVD 56(RSP), R6							
  peak_experiment_test.go:4	0x10017c778		17ffff3a		JMP github.com/GetStream/gophonic/internal/whispergemm.peakFMA(SB)	
  peak_experiment_test.go:4	0x10017c77c		00000000		?									
