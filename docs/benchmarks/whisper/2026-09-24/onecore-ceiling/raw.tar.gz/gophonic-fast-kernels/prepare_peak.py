from pathlib import Path
import json
r=Path('/Users/thesyncim/Documents/ChatGPT/goinfer');d=Path('/private/tmp/gophonic-fast-kernels')
s='//go:build goexperiment.simd && arm64\npackage whispergemm\nimport("simd/archsimd";"time";"os";"encoding/json";"testing";"runtime")\n'
s+='func peakFMA(dst,a []float32,iterations int) {\n'
for i in range(16):s+=f'c{i}:=archsimd.LoadFloat32x4Array((*[4]float32)(a[{i*4}:{i*4+4}]))\n'
s+='x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[64:68]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(a[68:72]))\n for i:=0;i<iterations;i++ {\n'
for i in range(16):s+=f'c{i}=x.MulAdd(y,c{i})\n'
s+='}\n'
for i in range(16):s+=f'c{i}.StoreArray((*[4]float32)(dst[{i*4}:{i*4+4}]))\n'
s+='}\n'
s+='''
func TestPeakFMA(t *testing.T) {
 runtime.GOMAXPROCS(1);a:=make([]float32,72);dst:=make([]float32,64);seed:=uint32(0xc001cafe);for i:=range a{a[i]=nextValue(&seed)}
 const iterations=5000000
 var ns []int64
 for i:=-5;i<40;i++{start:=time.Now();peakFMA(dst,a,iterations);duration:=time.Since(start).Nanoseconds();if i>=0{ns=append(ns,duration)}}
 report:=struct{Iterations int;FLOPs int;Nanoseconds []int64;Result []float32}{iterations,iterations*16*4*2,ns,dst}
 data,err:=json.Marshal(report);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/peak.json",data,0644);err!=nil{t.Fatal(err)}
}
'''
(d/'peak_test.go').write_text(s)
(d/'peak-overlay.json').write_text(json.dumps({'Replace':{str(r/'internal/whispergemm/peak_experiment_test.go'):str(d/'peak_test.go')}},indent=2))
