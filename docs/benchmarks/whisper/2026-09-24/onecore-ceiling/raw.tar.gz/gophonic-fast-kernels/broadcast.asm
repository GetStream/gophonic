TEXT github.com/GetStream/gophonic/internal/whispergemm.kernel5x16Broadcast(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/kernel_wide_arm64.go
  kernel_wide_arm64.go:194	0x100175a30		f9400b90		MOVD 16(R28), R16								
  kernel_wide_arm64.go:194	0x100175a34		eb3063ff		CMP R16, RSP									
  kernel_wide_arm64.go:194	0x100175a38		54001a49		BLS 210(PC)									
  kernel_wide_arm64.go:194	0x100175a3c		f81f0ffe		MOVD.W R30, -16(RSP)								
  kernel_wide_arm64.go:194	0x100175a40		f81f83fd		MOVD R29, -8(RSP)								
  kernel_wide_arm64.go:194	0x100175a44		d10023fd		SUB $8, RSP, R29								
  kernel_wide_arm64.go:194	0x100175a48		f90057e0		MOVD R0, 168(RSP)								
  kernel_wide_arm64.go:194	0x100175a4c		f90063e3		MOVD R3, 192(RSP)								
  kernel_wide_arm64.go:194	0x100175a50		f9006fe6		MOVD R6, 216(RSP)								
  kernel_wide_arm64.go:194	0x100175a54		f9007be9		MOVD R9, 240(RSP)								
  kernel_wide_arm64.go:194	0x100175a58		f90087ec		MOVD R12, 264(RSP)								
  kernel_wide_arm64.go:196	0x100175a5c		eb05003f		CMP R5, R1									
  kernel_wide_arm64.go:196	0x100175a60		540018c8		BHI 198(PC)									
  kernel_wide_arm64.go:197	0x100175a64		eb08003f		CMP R8, R1									
  kernel_wide_arm64.go:197	0x100175a68		54001868		BHI 195(PC)									
  kernel_wide_arm64.go:198	0x100175a6c		eb0b003f		CMP R11, R1									
  kernel_wide_arm64.go:198	0x100175a70		54001808		BHI 192(PC)									
  kernel_wide_arm64.go:199	0x100175a74		eb0e003f		CMP R14, R1									
  kernel_wide_arm64.go:199	0x100175a78		540017a8		BHI 189(PC)									
  kernel_wide_arm64.go:200	0x100175a7c		d37ef424		LSL $2, R1, R4									
  kernel_wide_arm64.go:200	0x100175a80		f94017e5		MOVD 40(RSP), R5								
  kernel_wide_arm64.go:200	0x100175a84		eb0108bf		CMP R1<<2, R5									
  kernel_wide_arm64.go:200	0x100175a88		54001703		BCC 184(PC)									
  kernel_wide_arm64.go:201	0x100175a8c		4f00e400		VMOVI $0, V0.B16								
  kernel_wide_arm64.go:206	0x100175a90		3600054f		TBZ $0, R15, 42(PC)								
  kernel_wide_arm64.go:207	0x100175a94		f9401fe5		MOVD 56(RSP), R5								
  kernel_wide_arm64.go:207	0x100175a98		f1003cbf		CMP $15, R5									
  kernel_wide_arm64.go:207	0x100175a9c		54001649		BLS 178(PC)									
  kernel_wide_arm64.go:212	0x100175aa0		f9402be7		MOVD 80(RSP), R7								
  kernel_wide_arm64.go:212	0x100175aa4		f1003cff		CMP $15, R7									
  kernel_wide_arm64.go:212	0x100175aa8		540015c9		BLS 174(PC)									
  kernel_wide_arm64.go:217	0x100175aac		f94037e8		MOVD 104(RSP), R8								
  kernel_wide_arm64.go:217	0x100175ab0		f1003d1f		CMP $15, R8									
  kernel_wide_arm64.go:217	0x100175ab4		54001549		BLS 170(PC)									
  kernel_wide_arm64.go:222	0x100175ab8		f94043ea		MOVD 128(RSP), R10								
  kernel_wide_arm64.go:222	0x100175abc		f1003d5f		CMP $15, R10									
  kernel_wide_arm64.go:222	0x100175ac0		540014c9		BLS 166(PC)									
  kernel_wide_arm64.go:227	0x100175ac4		f9404feb		MOVD 152(RSP), R11								
  kernel_wide_arm64.go:227	0x100175ac8		f1003d7f		CMP $15, R11									
  kernel_wide_arm64.go:227	0x100175acc		54001449		BLS 162(PC)									
  kernel_wide_arm64.go:208	0x100175ad0		f9401bed		MOVD 48(RSP), R13								
  kernel_wide_arm64.go:208	0x100175ad4		3dc001a0		FMOVQ (R13), F0									
  kernel_wide_arm64.go:209	0x100175ad8		3dc005a1		FMOVQ 16(R13), F1								
  kernel_wide_arm64.go:210	0x100175adc		3dc009a2		FMOVQ 32(R13), F2								
  kernel_wide_arm64.go:211	0x100175ae0		3dc00da3		FMOVQ 48(R13), F3								
  kernel_wide_arm64.go:213	0x100175ae4		f94027ee		MOVD 72(RSP), R14								
  kernel_wide_arm64.go:213	0x100175ae8		3dc001c4		FMOVQ (R14), F4									
  kernel_wide_arm64.go:214	0x100175aec		3dc005c5		FMOVQ 16(R14), F5								
  kernel_wide_arm64.go:215	0x100175af0		3dc009c6		FMOVQ 32(R14), F6								
  kernel_wide_arm64.go:216	0x100175af4		3dc00dc7		FMOVQ 48(R14), F7								
  kernel_wide_arm64.go:218	0x100175af8		f94033ef		MOVD 96(RSP), R15								
  kernel_wide_arm64.go:218	0x100175afc		3dc001e8		FMOVQ (R15), F8									
  kernel_wide_arm64.go:219	0x100175b00		3dc005e9		FMOVQ 16(R15), F9								
  kernel_wide_arm64.go:220	0x100175b04		3dc009ea		FMOVQ 32(R15), F10								
  kernel_wide_arm64.go:221	0x100175b08		3dc00deb		FMOVQ 48(R15), F11								
  kernel_wide_arm64.go:223	0x100175b0c		f9403ff0		MOVD 120(RSP), R16								
  kernel_wide_arm64.go:223	0x100175b10		3dc0020c		FMOVQ (R16), F12								
  kernel_wide_arm64.go:224	0x100175b14		3dc0060d		FMOVQ 16(R16), F13								
  kernel_wide_arm64.go:225	0x100175b18		3dc00a0e		FMOVQ 32(R16), F14								
  kernel_wide_arm64.go:226	0x100175b1c		3dc00e0f		FMOVQ 48(R16), F15								
  kernel_wide_arm64.go:228	0x100175b20		f9404bf1		MOVD 144(RSP), R17								
  kernel_wide_arm64.go:228	0x100175b24		3dc00230		FMOVQ (R17), F16								
  kernel_wide_arm64.go:229	0x100175b28		3dc00631		FMOVQ 16(R17), F17								
  kernel_wide_arm64.go:230	0x100175b2c		3dc00a32		FMOVQ 32(R17), F18								
  kernel_wide_arm64.go:231	0x100175b30		3dc00e33		FMOVQ 48(R17), F19								
  kernel_wide_arm64.go:231	0x100175b34		1400001e		JMP 30(PC)									
  kernel_wide_arm64.go:265	0x100175b38		f9401fe5		MOVD 56(RSP), R5								
  kernel_wide_arm64.go:270	0x100175b3c		f9402be7		MOVD 80(RSP), R7								
  kernel_wide_arm64.go:275	0x100175b40		f94037e8		MOVD 104(RSP), R8								
  kernel_wide_arm64.go:280	0x100175b44		f94043ea		MOVD 128(RSP), R10								
  kernel_wide_arm64.go:285	0x100175b48		f9404feb		MOVD 152(RSP), R11								
  kernel_wide_arm64.go:266	0x100175b4c		f9401bed		MOVD 48(RSP), R13								
  kernel_wide_arm64.go:271	0x100175b50		f94027ee		MOVD 72(RSP), R14								
  kernel_wide_arm64.go:276	0x100175b54		f94033ef		MOVD 96(RSP), R15								
  kernel_wide_arm64.go:281	0x100175b58		f9403ff0		MOVD 120(RSP), R16								
  kernel_wide_arm64.go:286	0x100175b5c		f9404bf1		MOVD 144(RSP), R17								
  kernel_wide_arm64.go:233	0x100175b60		4ea01c12		VMOV V0.B16, V18.B16								
  kernel_wide_arm64.go:233	0x100175b64		4eb21e51		VMOV V18.B16, V17.B16								
  kernel_wide_arm64.go:233	0x100175b68		4eb11e30		VMOV V17.B16, V16.B16								
  kernel_wide_arm64.go:233	0x100175b6c		4eb01e0f		VMOV V16.B16, V15.B16								
  kernel_wide_arm64.go:233	0x100175b70		4eaf1dee		VMOV V15.B16, V14.B16								
  kernel_wide_arm64.go:233	0x100175b74		4eae1dcd		VMOV V14.B16, V13.B16								
  kernel_wide_arm64.go:233	0x100175b78		4ead1dac		VMOV V13.B16, V12.B16								
  kernel_wide_arm64.go:233	0x100175b7c		4eac1d8b		VMOV V12.B16, V11.B16								
  kernel_wide_arm64.go:233	0x100175b80		4eab1d6a		VMOV V11.B16, V10.B16								
  kernel_wide_arm64.go:233	0x100175b84		4eaa1d49		VMOV V10.B16, V9.B16								
  kernel_wide_arm64.go:233	0x100175b88		4ea91d28		VMOV V9.B16, V8.B16								
  kernel_wide_arm64.go:233	0x100175b8c		4ea81d07		VMOV V8.B16, V7.B16								
  kernel_wide_arm64.go:233	0x100175b90		4ea71ce6		VMOV V7.B16, V6.B16								
  kernel_wide_arm64.go:233	0x100175b94		4ea61cc5		VMOV V6.B16, V5.B16								
  kernel_wide_arm64.go:233	0x100175b98		4ea51ca4		VMOV V5.B16, V4.B16								
  kernel_wide_arm64.go:233	0x100175b9c		4ea41c83		VMOV V4.B16, V3.B16								
  kernel_wide_arm64.go:233	0x100175ba0		4ea31c62		VMOV V3.B16, V2.B16								
  kernel_wide_arm64.go:233	0x100175ba4		4ea21c41		VMOV V2.B16, V1.B16								
  kernel_wide_arm64.go:233	0x100175ba8		4ea11c33		VMOV V1.B16, V19.B16								
  kernel_wide_arm64.go:233	0x100175bac		aa1f03f3		MOVD ZR, R19									
  kernel_wide_arm64.go:233	0x100175bb0		f9400ff4		MOVD 24(RSP), R20								
  kernel_wide_arm64.go:233	0x100175bb4		14000021		JMP 33(PC)									
  kernel_wide_arm64.go:234	0x100175bb8		3dc002d4		FMOVQ (R22), F20								
  kernel_wide_arm64.go:235	0x100175bbc		3dc00335		FMOVQ (R25), F21								
  kernel_wide_arm64.go:236	0x100175bc0		3dc00356		FMOVQ (R26), F22								
  kernel_wide_arm64.go:237	0x100175bc4		3dc003d7		FMOVQ (R30), F23								
  kernel_wide_arm64.go:238	0x100175bc8		3dc00238		FMOVQ (R17), F24								
  kernel_wide_arm64.go:239	0x100175bcc		8b131296		ADD R19<<4, R20, R22								
  kernel_wide_arm64.go:240	0x100175bd0		3dc002d9		FMOVQ (R22), F25								
  kernel_wide_arm64.go:246	0x100175bd4		3dc006da		FMOVQ 16(R22), F26								
  kernel_wide_arm64.go:252	0x100175bd8		3dc00adb		FMOVQ 32(R22), F27								
  kernel_wide_arm64.go:258	0x100175bdc		3dc00edc		FMOVQ 48(R22), F28								
  kernel_wide_arm64.go:241	0x100175be0		4e34cf20		VFMLA V20.S4, V25.S4, V0.S4							
  kernel_wide_arm64.go:242	0x100175be4		4e35cf24		VFMLA V21.S4, V25.S4, V4.S4							
  kernel_wide_arm64.go:243	0x100175be8		4e36cf28		VFMLA V22.S4, V25.S4, V8.S4							
  kernel_wide_arm64.go:244	0x100175bec		4e37cf2c		VFMLA V23.S4, V25.S4, V12.S4							
  kernel_wide_arm64.go:245	0x100175bf0		4e38cf30		VFMLA V24.S4, V25.S4, V16.S4							
  kernel_wide_arm64.go:247	0x100175bf4		4e34cf41		VFMLA V20.S4, V26.S4, V1.S4							
  kernel_wide_arm64.go:248	0x100175bf8		4e35cf45		VFMLA V21.S4, V26.S4, V5.S4							
  kernel_wide_arm64.go:249	0x100175bfc		4e36cf49		VFMLA V22.S4, V26.S4, V9.S4							
  kernel_wide_arm64.go:250	0x100175c00		4e37cf4d		VFMLA V23.S4, V26.S4, V13.S4							
  kernel_wide_arm64.go:251	0x100175c04		4e38cf51		VFMLA V24.S4, V26.S4, V17.S4							
  kernel_wide_arm64.go:253	0x100175c08		4e34cf62		VFMLA V20.S4, V27.S4, V2.S4							
  kernel_wide_arm64.go:254	0x100175c0c		4e35cf66		VFMLA V21.S4, V27.S4, V6.S4							
  kernel_wide_arm64.go:255	0x100175c10		4e36cf6a		VFMLA V22.S4, V27.S4, V10.S4							
  kernel_wide_arm64.go:256	0x100175c14		4e37cf6e		VFMLA V23.S4, V27.S4, V14.S4							
  kernel_wide_arm64.go:257	0x100175c18		4e38cf72		VFMLA V24.S4, V27.S4, V18.S4							
  kernel_wide_arm64.go:259	0x100175c1c		4e34cf83		VFMLA V20.S4, V28.S4, V3.S4							
  kernel_wide_arm64.go:260	0x100175c20		4e35cf87		VFMLA V21.S4, V28.S4, V7.S4							
  kernel_wide_arm64.go:261	0x100175c24		4e36cf8b		VFMLA V22.S4, V28.S4, V11.S4							
  kernel_wide_arm64.go:262	0x100175c28		4e37cf8f		VFMLA V23.S4, V28.S4, V15.S4							
  kernel_wide_arm64.go:263	0x100175c2c		4e38cf93		VFMLA V24.S4, V28.S4, V19.S4							
  kernel_wide_arm64.go:286	0x100175c30		f9404bf1		MOVD 144(RSP), R17								
  kernel_wide_arm64.go:233	0x100175c34		aa1503f3		MOVD R21, R19									
  kernel_wide_arm64.go:233	0x100175c38		eb13003f		CMP R19, R1									
  kernel_wide_arm64.go:233	0x100175c3c		5400028d		BLE 20(PC)									
  kernel_wide_arm64.go:234	0x100175c40		91001275		ADD $4, R19, R21								
  kernel_wide_arm64.go:234	0x100175c44		eb15005f		CMP R21, R2									
  kernel_wide_arm64.go:234	0x100175c48		54000823		BCC 65(PC)									
  kernel_wide_arm64.go:234	0x100175c4c		eb15027f		CMP R21, R19									
  kernel_wide_arm64.go:234	0x100175c50		54000788		BHI 60(PC)									
  kernel_wide_arm64.go:234	0x100175c54		8b130816		ADD R19<<2, R0, R22								
  kernel_wide_arm64.go:235	0x100175c58		eb15003f		CMP R21, R1									
  kernel_wide_arm64.go:235	0x100175c5c		540006e3		BCC 55(PC)									
  kernel_wide_arm64.go:234	0x100175c60		d37ef677		LSL $2, R19, R23								
  kernel_wide_arm64.go:239	0x100175c64		910042f8		ADD $16, R23, R24								
  kernel_wide_arm64.go:235	0x100175c68		8b130879		ADD R19<<2, R3, R25								
  kernel_wide_arm64.go:236	0x100175c6c		8b1308da		ADD R19<<2, R6, R26								
  kernel_wide_arm64.go:237	0x100175c70		8b13093e		ADD R19<<2, R9, R30								
  kernel_wide_arm64.go:238	0x100175c74		8b130991		ADD R19<<2, R12, R17								
  kernel_wide_arm64.go:239	0x100175c78		eb010b1f		CMP R1<<2, R24									
  kernel_wide_arm64.go:239	0x100175c7c		540005a8		BHI 45(PC)									
  kernel_wide_arm64.go:239	0x100175c80		eb130b1f		CMP R19<<2, R24									
  kernel_wide_arm64.go:239	0x100175c84		54fff9a2		BCS -51(PC)									
  kernel_wide_arm64.go:239	0x100175c88		14000027		JMP 39(PC)									
  kernel_wide_arm64.go:265	0x100175c8c		f1003cbf		CMP $15, R5									
  kernel_wide_arm64.go:265	0x100175c90		54000489		BLS 36(PC)									
  kernel_wide_arm64.go:266	0x100175c94		3d8001a0		FMOVQ F0, (R13)									
  kernel_wide_arm64.go:267	0x100175c98		3d8005a1		FMOVQ F1, 16(R13)								
  kernel_wide_arm64.go:268	0x100175c9c		3d8009a2		FMOVQ F2, 32(R13)								
  kernel_wide_arm64.go:269	0x100175ca0		3d800da3		FMOVQ F3, 48(R13)								
  kernel_wide_arm64.go:270	0x100175ca4		f1003cff		CMP $15, R7									
  kernel_wide_arm64.go:270	0x100175ca8		540003a9		BLS 29(PC)									
  kernel_wide_arm64.go:271	0x100175cac		3d8001c4		FMOVQ F4, (R14)									
  kernel_wide_arm64.go:272	0x100175cb0		3d8005c5		FMOVQ F5, 16(R14)								
  kernel_wide_arm64.go:273	0x100175cb4		3d8009c6		FMOVQ F6, 32(R14)								
  kernel_wide_arm64.go:274	0x100175cb8		3d800dc7		FMOVQ F7, 48(R14)								
  kernel_wide_arm64.go:275	0x100175cbc		f1003d1f		CMP $15, R8									
  kernel_wide_arm64.go:275	0x100175cc0		540002c9		BLS 22(PC)									
  kernel_wide_arm64.go:276	0x100175cc4		3d8001e8		FMOVQ F8, (R15)									
  kernel_wide_arm64.go:277	0x100175cc8		3d8005e9		FMOVQ F9, 16(R15)								
  kernel_wide_arm64.go:278	0x100175ccc		3d8009ea		FMOVQ F10, 32(R15)								
  kernel_wide_arm64.go:279	0x100175cd0		3d800deb		FMOVQ F11, 48(R15)								
  kernel_wide_arm64.go:280	0x100175cd4		f1003d5f		CMP $15, R10									
  kernel_wide_arm64.go:280	0x100175cd8		540001e9		BLS 15(PC)									
  kernel_wide_arm64.go:281	0x100175cdc		3d80020c		FMOVQ F12, (R16)								
  kernel_wide_arm64.go:282	0x100175ce0		3d80060d		FMOVQ F13, 16(R16)								
  kernel_wide_arm64.go:283	0x100175ce4		3d800a0e		FMOVQ F14, 32(R16)								
  kernel_wide_arm64.go:284	0x100175ce8		3d800e0f		FMOVQ F15, 48(R16)								
  kernel_wide_arm64.go:285	0x100175cec		f1003d7f		CMP $15, R11									
  kernel_wide_arm64.go:285	0x100175cf0		54000109		BLS 8(PC)									
  kernel_wide_arm64.go:286	0x100175cf4		3d800230		FMOVQ F16, (R17)								
  kernel_wide_arm64.go:287	0x100175cf8		3d800631		FMOVQ F17, 16(R17)								
  kernel_wide_arm64.go:288	0x100175cfc		3d800a32		FMOVQ F18, 32(R17)								
  kernel_wide_arm64.go:289	0x100175d00		3d800e33		FMOVQ F19, 48(R17)								
  kernel_wide_arm64.go:290	0x100175d04		f85f83fd		MOVD -8(RSP), R29								
  kernel_wide_arm64.go:290	0x100175d08		f84107fe		MOVD.P 16(RSP), R30								
  kernel_wide_arm64.go:290	0x100175d0c		d65f03c0		RET										
  kernel_wide_arm64.go:285	0x100175d10		97fc3eb4		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:280	0x100175d14		97fc3eb3		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:275	0x100175d18		97fc3eb2		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:270	0x100175d1c		97fc3eb1		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:265	0x100175d20		97fc3eb0		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:239	0x100175d24		aa1703e0		MOVD R23, R0									
  kernel_wide_arm64.go:239	0x100175d28		aa1803e1		MOVD R24, R1									
  kernel_wide_arm64.go:239	0x100175d2c		97fc3ead		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:239	0x100175d30		aa1803e0		MOVD R24, R0									
  kernel_wide_arm64.go:239	0x100175d34		97fc3eab		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:235	0x100175d38		aa1503e0		MOVD R21, R0									
  kernel_wide_arm64.go:235	0x100175d3c		97fc3ea9		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:234	0x100175d40		aa1303e0		MOVD R19, R0									
  kernel_wide_arm64.go:234	0x100175d44		aa1503e1		MOVD R21, R1									
  kernel_wide_arm64.go:234	0x100175d48		97fc3ea6		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:234	0x100175d4c		aa1503e0		MOVD R21, R0									
  kernel_wide_arm64.go:234	0x100175d50		97fc3ea4		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:227	0x100175d54		97fc3ea3		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:222	0x100175d58		97fc3ea2		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:217	0x100175d5c		97fc3ea1		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:212	0x100175d60		97fc3ea0		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:207	0x100175d64		97fc3e9f		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:200	0x100175d68		97fc3e9e		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:199	0x100175d6c		97fc3e9d		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:198	0x100175d70		97fc3e9c		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:197	0x100175d74		97fc3e9b		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:196	0x100175d78		97fc3e9a		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:196	0x100175d7c		d503201f		NOOP										
  kernel_wide_arm64.go:194	0x100175d80		a90987e0		STP (R0, R1), 152(RSP)								
  kernel_wide_arm64.go:194	0x100175d84		a90a8fe2		STP (R2, R3), 168(RSP)								
  kernel_wide_arm64.go:194	0x100175d88		a90b97e4		STP (R4, R5), 184(RSP)								
  kernel_wide_arm64.go:194	0x100175d8c		a90c9fe6		STP (R6, R7), 200(RSP)								
  kernel_wide_arm64.go:194	0x100175d90		a90da7e8		STP (R8, R9), 216(RSP)								
  kernel_wide_arm64.go:194	0x100175d94		a90eafea		STP (R10, R11), 232(RSP)							
  kernel_wide_arm64.go:194	0x100175d98		a90fb7ec		STP (R12, R13), 248(RSP)							
  kernel_wide_arm64.go:194	0x100175d9c		f90087ee		MOVD R14, 264(RSP)								
  kernel_wide_arm64.go:194	0x100175da0		390443ef		MOVB R15, 272(RSP)								
  kernel_wide_arm64.go:194	0x100175da4		aa1e03e3		MOVD R30, R3									
  kernel_wide_arm64.go:194	0x100175da8		97fc364a		CALL runtime.morestack_noctxt.abi0(SB)						
  kernel_wide_arm64.go:194	0x100175dac		a94987e0		LDP 152(RSP), (R0, R1)								
  kernel_wide_arm64.go:194	0x100175db0		a94a8fe2		LDP 168(RSP), (R2, R3)								
  kernel_wide_arm64.go:194	0x100175db4		a94b97e4		LDP 184(RSP), (R4, R5)								
  kernel_wide_arm64.go:194	0x100175db8		a94c9fe6		LDP 200(RSP), (R6, R7)								
  kernel_wide_arm64.go:194	0x100175dbc		a94da7e8		LDP 216(RSP), (R8, R9)								
  kernel_wide_arm64.go:194	0x100175dc0		a94eafea		LDP 232(RSP), (R10, R11)							
  kernel_wide_arm64.go:194	0x100175dc4		a94fb7ec		LDP 248(RSP), (R12, R13)							
  kernel_wide_arm64.go:194	0x100175dc8		f94087ee		MOVD 264(RSP), R14								
  kernel_wide_arm64.go:194	0x100175dcc		394443ef		MOVBU 272(RSP), R15								
  kernel_wide_arm64.go:194	0x100175dd0		17ffff18		JMP github.com/GetStream/gophonic/internal/whispergemm.kernel5x16Broadcast(SB)	
  kernel_wide_arm64.go:194	0x100175dd4		00000000		?										
  kernel_wide_arm64.go:194	0x100175dd8		00000000		?										
  kernel_wide_arm64.go:194	0x100175ddc		00000000		?										
