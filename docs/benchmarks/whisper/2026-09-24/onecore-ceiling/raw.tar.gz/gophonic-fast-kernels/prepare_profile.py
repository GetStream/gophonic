from pathlib import Path
import json
r=Path('/Users/thesyncim/Documents/ChatGPT/goinfer');d=Path('/private/tmp/gophonic-fast-kernels')
repl={}
def get(f):return (r/'whisper'/f).read_text().replace('import (','import (\n"time"',1)
def save(f,s):
 p=d/('profile-'+f);p.write_text(s);repl[str(r/'whisper'/f)]=str(p)
def mark(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b,1)
def tick(i,var):return f'\nfastProfileStages[{i}]+=time.Since({var});{var}=time.Now()\n'
s=get('transcriber.go')
s=mark(s,'\tif err := FeaturesInto(pcm, t.mel, t.frontend);','stageStart:=time.Now()\n\tif err := FeaturesInto(pcm, t.mel, t.frontend);')
for i,needle in enumerate(['\tif err := t.model.encodeContextInto','\tif err := t.model.BeginDecode','\tpromptLen, err := t.policy.PromptInto','\tstart := len(dst)']):s=mark(s,needle,tick(i,'stageStart')+needle)
save('transcriber.go',s)
s=get('encoder.go');s=mark(s,'\t// Whisper\'s audio stem','stageStart:=time.Now()\n\t// Whisper\'s audio stem')
s=mark(s,'\tfor i := 0; i < AudioLayers; i++ {\n\t\tif err := encodeBlock',tick(4,'stageStart')+'\tfor i := 0; i < AudioLayers; i++ {\n\t\tif err := encodeBlock')
s=mark(s,'func encodeBlock(dst []float32, block encoderBlockWeights, packed packedEncoderBlock, w *EncoderWorkspace, audioFrames int) error {','func encodeBlock(dst []float32, block encoderBlockWeights, packed packedEncoderBlock, w *EncoderWorkspace, audioFrames int) error {\nstageStart:=time.Now()')
for i,needle in [(5,'\tif err := w.gemm.Mul(packed.query,'),(6,'\t// Each query tile consumes'),(7,'\tif err := w.gemm.Mul(packed.out,'),(8,'\tfor t := 0; t < audioFrames; t++ {\n\t\tstart := t * AudioState\n\t\trow := dst[start : start+AudioState]\n\t\tlayerNormRow(row, w.normalized[start:start+AudioState], block.mlpNormW, block.mlpNormB)'),(9,'\tif err := w.gemm.Mul(packed.mlpIn,'),(10,'\tif err := w.activate(w.feedForward,'),(11,'\tif err := w.gemm.Mul(packed.mlpOut,'),(12,'\taddRowBias(w.normalized, block.mlpOutB,')]:s=mark(s,needle,tick(i,'stageStart')+needle)
save('encoder.go',s)
s=get('encoder_attention.go')
s=mark(s,'func (a *audioAttention) run(q, k, v, dst []float32, executor *whispergemm.Executor) error {','func (a *audioAttention) run(q, k, v, dst []float32, executor *whispergemm.Executor) error {\nstageStart:=time.Now()')
s=mark(s,'\ta.q, a.dst = q, dst',tick(13,'stageStart')+'\ta.q, a.dst = q, dst')
s=mark(s,'\t\t\tif err := a.keys[head].Mul','stageStart:=time.Now()\n\t\t\tif err := a.keys[head].Mul')
s=mark(s,'\t\t\tsoftmaxRows(scores, rows, a.rows)',tick(14,'stageStart')+'\t\t\tsoftmaxRows(scores, rows, a.rows)'+tick(15,'stageStart'))
s=mark(s,'\t\t\tif err := a.values[head].Mul(a.dst[offset:], a.state, scores, a.rows, rows); err != nil {\n\t\t\t\ta.errors[worker] = err\n\t\t\t\treturn\n\t\t\t}','\t\t\tif err := a.values[head].Mul(a.dst[offset:], a.state, scores, a.rows, rows); err != nil {\n\t\t\t\ta.errors[worker] = err\n\t\t\t\treturn\n\t\t\t}'+tick(16,'stageStart'))
save('encoder_attention.go',s)
test='''package whisper
import("testing";"time";"runtime";"runtime/pprof";"os";"slices";"encoding/json")
var fastProfileStages [17]time.Duration
func TestFastStageProfile(t *testing.T) {
 runtime.GOMAXPROCS(1);m,pcm:=loadFastContextJFK(t);w,err:=NewTranscriberWithWorkers(m,1);if err!=nil{t.Fatal(err)};defer w.Close()
 dst:=make([]byte,0,2048);var tokens []int;var transcript string
 type sample struct{Total time.Duration;Stages [17]time.Duration};var samples []sample
 for i:=-5;i<16;i++ {
  if i==0 {f,err:=os.Create("/private/tmp/gophonic-fast-kernels/cpu.pprof");if err!=nil{t.Fatal(err)};defer f.Close();if err:=pprof.StartCPUProfile(f);err!=nil{t.Fatal(err)}}
  fastProfileStages=[17]time.Duration{};start:=time.Now();text,err:=w.TranscribeWindowFastInto(pcm,dst);elapsed:=time.Since(start)
  if err!=nil{t.Fatal(err)};if tokens==nil{tokens=slices.Clone(w.tokens);transcript=string(text)};if !slices.Equal(tokens,w.tokens)||string(text)!=transcript{t.Fatal("tokens changed")};if i>=0{samples=append(samples,sample{elapsed,fastProfileStages})}
 }
 pprof.StopCPUProfile()
 report:=struct{Names []string;Samples []sample;Text string;Tokens []int}{[]string{"frontend","encoder","cross_kv","tokens","encoder_stem","encoder_attn_norm","encoder_qkv","encoder_attention","encoder_out","encoder_mlp_norm","encoder_mlp_expand","encoder_mlp_gelu","encoder_mlp_contract","attention_pack","attention_qk","attention_softmax","attention_pv"},samples,transcript,tokens}
 data,err:=json.Marshal(report);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/profile.json",data,0644);err!=nil{t.Fatal(err)}
}
'''
save('fast_profile_test.go',test)
(d/'profile-overlay.json').write_text(json.dumps({'Replace':repl},indent=2))
s=(r/'tools/benchmark_whisper_fast_cpp.cpp').read_text().replace('auto start = std::chrono::steady_clock::now();','whisper_reset_timings(ctx);\n        auto start = std::chrono::steady_clock::now();').replace('if (rc) return 3;','if (rc) return 3;\n        if(i>=0) whisper_print_timings(ctx);')
(d/'cpp-stage.cpp').write_text(s)
