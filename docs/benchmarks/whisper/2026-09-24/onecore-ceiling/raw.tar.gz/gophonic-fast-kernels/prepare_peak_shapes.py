from pathlib import Path
p=Path('/private/tmp/gophonic-fast-kernels/peak_test.go')
s='//go:build goexperiment.simd && arm64\npackage whispergemm\nimport("simd/archsimd";"time";"os";"encoding/json";"testing";"runtime")\n'
shapes=[(2,8),(4,4),(5,4),(3,6),(7,3)]
for rows,cols in shapes:
 name=f'peak{rows}x{cols}'
 s+=f'func {name}(dst,a []float32,iterations int) {{\n'
 for i in range(rows*cols):s+=f'c{i}:=archsimd.LoadFloat32x4Array((*[4]float32)(a[{i*4}:{i*4+4}]))\n'
 base=rows*cols*4
 for i in range(cols):s+=f'w{i}:=archsimd.LoadFloat32x4Array((*[4]float32)(a[{base+i*4}:{base+i*4+4}]))\n'
 base+=cols*4
 for i in range(rows):s+=f'x{i}:=archsimd.LoadFloat32x4Array((*[4]float32)(a[{base+i*4}:{base+i*4+4}]))\n'
 s+='for i:=0;i<iterations;i++ {\n'
 for row in range(rows):
  for col in range(cols):i=row*cols+col;s+=f'c{i}=w{col}.MulAdd(x{row},c{i})\n'
 s+='}\n'
 for i in range(rows*cols):s+=f'c{i}.StoreArray((*[4]float32)(dst[{i*4}:{i*4+4}]))\n'
 s+='}\n'
s+='''
func TestPeakFMAShapes(t *testing.T) {
 runtime.GOMAXPROCS(1);a:=make([]float32,128);dst:=make([]float32,96);seed:=uint32(0xc001cafe);for i:=range a{a[i]=nextValue(&seed)}
 const iterations=3000000
 type sample struct{Name string;FLOPs int;Nanoseconds int64};var samples []sample
'''
for rows,cols in shapes:
 s+=f'''for i:=-5;i<30;i++{{start:=time.Now();peak{rows}x{cols}(dst,a,iterations);duration:=time.Since(start).Nanoseconds();if i>=0{{samples=append(samples,sample{{"{rows}x{cols*4}",iterations*{rows*cols*8},duration}})}}}}
'''
s+='''data,err:=json.Marshal(samples);if err!=nil{t.Fatal(err)};if err:=os.WriteFile("/private/tmp/gophonic-fast-kernels/peak-shapes.json",data,0644);err!=nil{t.Fatal(err)};benchmarkSink=dst[0]
}
'''
p.write_text(s)
