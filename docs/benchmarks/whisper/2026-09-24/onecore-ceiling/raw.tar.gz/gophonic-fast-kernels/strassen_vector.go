//go:build goexperiment.simd && arm64
package whispergemm
import "simd/archsimd"
func strassenAdd(dst,a,b []float32) {
 n:=len(dst);a=a[:n];b=b[:n];i:=0
 for ;i+4<=n;i+=4 {x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[i:i+4]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(b[i:i+4]));x.Add(y).StoreArray((*[4]float32)(dst[i:i+4]))}
 for ;i<n;i++{dst[i]=a[i]+b[i]}
}
func strassenSub(dst,a,b []float32) {
 n:=len(dst);a=a[:n];b=b[:n];i:=0
 for ;i+4<=n;i+=4 {x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[i:i+4]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(b[i:i+4]));x.Sub(y).StoreArray((*[4]float32)(dst[i:i+4]))}
 for ;i<n;i++{dst[i]=a[i]-b[i]}
}
func strassenAddPair(a,b,src []float32) {
 n:=len(src);a=a[:n];b=b[:n];i:=0
 for ;i+4<=n;i+=4 {v:=archsimd.LoadFloat32x4Array((*[4]float32)(src[i:i+4]));x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[i:i+4]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(b[i:i+4]));x.Add(v).StoreArray((*[4]float32)(a[i:i+4]));y.Add(v).StoreArray((*[4]float32)(b[i:i+4]))}
 for ;i<n;i++{a[i]+=src[i];b[i]+=src[i]}
}
func strassenSubAddPair(a,b,src []float32) {
 n:=len(src);a=a[:n];b=b[:n];i:=0
 for ;i+4<=n;i+=4 {v:=archsimd.LoadFloat32x4Array((*[4]float32)(src[i:i+4]));x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[i:i+4]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(b[i:i+4]));x.Sub(v).StoreArray((*[4]float32)(a[i:i+4]));y.Add(v).StoreArray((*[4]float32)(b[i:i+4]))}
 for ;i<n;i++{a[i]-=src[i];b[i]+=src[i]}
}

func strassenSumDifference(sum,diff,a,b,c []float32) {
 n:=len(sum);diff=diff[:n];a=a[:n];b=b[:n];c=c[:n];i:=0
 for ;i+4<=n;i+=4 {x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[i:i+4]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(b[i:i+4]));z:=archsimd.LoadFloat32x4Array((*[4]float32)(c[i:i+4]));v:=x.Add(y);v.StoreArray((*[4]float32)(sum[i:i+4]));v.Sub(z).StoreArray((*[4]float32)(diff[i:i+4]))}
 for ;i<n;i++{sum[i]=a[i]+b[i];diff[i]=sum[i]-c[i]}
}
