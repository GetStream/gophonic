from pathlib import Path
p=Path('/private/tmp/gophonic-fast-kernels/strassen.go')
s=p.read_text().replace('input, product [3][]float32','input, second, product [3][]float32').replace('s.input[level]=make([]float32,size);','s.input[level]=make([]float32,size);s.second[level]=make([]float32,size);')
s=s.replace('switch block {case 0:v=b11+b22;case 1:v=b11;case 2:v=b12-b22;case 3:v=b21-b11;case 4:v=b22;case 5:v=b11+b12;case 6:v=b21+b22}','t1:=b12-b11;t2:=b22-t1\n   switch block {case 0:v=b11;case 1:v=b21;case 2:v=t2;case 3:v=t1;case 4:v=b22-b12;case 5:v=b22;case 6:v=t2-b21}')
start=s.index(' input:=s.input[level]')
s=s[:start]+''' input:=s.input[level][:mh*kh]
 second:=s.second[level][:mh*kh]
 prod:=s.product[level][:mh*nh]
 for block:=0;block<7;block++ {
  source,sourceStride:=input,kh
  switch block {
  case 0:source,sourceStride=a,as
  case 1:source,sourceStride=a[kh:],as
  case 2:
   for r:=0;r<mh;r++ {a11:=a[r*as:r*as+kh];a21,a22:=a[(r+mh)*as:(r+mh)*as+kh],a[(r+mh)*as+kh:(r+mh)*as+b.k];lo,hi:=r*kh,(r+1)*kh;strassenSumDifference(second[lo:hi],input[lo:hi],a21,a22,a11)}
  case 3:source=second
  case 4:
   for r:=0;r<mh;r++ {strassenSub(second[r*kh:(r+1)*kh],a[r*as:r*as+kh],a[(r+mh)*as:(r+mh)*as+kh])};source=second
  case 5:
   for r:=0;r<mh;r++ {row:=input[r*kh:(r+1)*kh];strassenSub(row,a[r*as+kh:r*as+b.k],row)}
  case 6:source,sourceStride=a[mh*as+kh:],as
  }
  if level+1 < strassenExperimentMode && mh>=64 && kh>=64 && nh>=64 && kh%2==0 && nh%32==0 {s.mulLevel(weights.blocks[block],prod,nh,source,sourceStride,mh,level+1)} else {weights.blocks[block].mul(prod,nh,source,sourceStride,mh)}
  for r:=0;r<mh;r++ {
   c11,c12:=dst[r*ds:r*ds+nh],dst[r*ds+nh:r*ds+b.n]
   c21,c22:=dst[(r+mh)*ds:(r+mh)*ds+nh],dst[(r+mh)*ds+nh:(r+mh)*ds+b.n]
   row:=prod[r*nh:(r+1)*nh]
   switch block {
   case 0:copy(c11,row);copy(c12,row)
   case 1:strassenAdd(c11,c11,row)
   case 2:strassenAdd(c12,c12,row);copy(c21,c12)
   case 3:strassenAdd(c12,c12,row);copy(c22,row)
   case 4:strassenAdd(c21,c21,row);strassenAdd(c22,c22,c21)
   case 5:strassenAdd(c12,c12,row)
   case 6:strassenSub(c21,c21,row)
   }
  }
 }
 if tail:=m-2*mh;tail>0 {b.mul(dst[2*mh*ds:],ds,a[2*mh*as:],as,tail)}
}
'''
p.write_text(s)
p=Path('/private/tmp/gophonic-fast-kernels/strassen_vector.go');s=p.read_text();s+='''
func strassenSumDifference(sum,diff,a,b,c []float32) {
 n:=len(sum);diff=diff[:n];a=a[:n];b=b[:n];c=c[:n];i:=0
 for ;i+4<=n;i+=4 {x:=archsimd.LoadFloat32x4Array((*[4]float32)(a[i:i+4]));y:=archsimd.LoadFloat32x4Array((*[4]float32)(b[i:i+4]));z:=archsimd.LoadFloat32x4Array((*[4]float32)(c[i:i+4]));v:=x.Add(y);v.StoreArray((*[4]float32)(sum[i:i+4]));v.Sub(z).StoreArray((*[4]float32)(diff[i:i+4]))}
 for ;i<n;i++{sum[i]=a[i]+b[i];diff[i]=sum[i]-c[i]}
}
''';p.write_text(s)
p=Path('/private/tmp/gophonic-fast-kernels/strassen_window_test.go');s=p.read_text().replace('TranscribeWindowFastInto','TranscribeWindowInto').replace('strassen-window.json','strassen-full-window.json').replace('cycle<24','cycle<16');p.write_text(s)
