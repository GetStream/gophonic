// Copyright 2026 The gophonic authors
// SPDX-License-Identifier: BSD-2-Clause

//go:build goexperiment.simd && arm64

package whispergemm

import "simd/archsimd"

// Two rows share each broadcast across thirty-two columns. Compared with
// kernel4x16, this halves table lookups per output while retaining sixteen
// independent accumulators. Both packed panels retain their existing layout,
// and each output accumulates in increasing K order.
func kernel2x32(a0, a1, weights0, weights1, d0, d1 []float32) {
	k := len(a0)
	a1 = a1[:k:k]
	weights0 = weights0[: k*16 : k*16]
	weights1 = weights1[: k*16 : k*16]
	var c00, c01, c02, c03, c04, c05, c06, c07 archsimd.Float32x4
	var c10, c11, c12, c13, c14, c15, c16, c17 archsimd.Float32x4
	index0 := archsimd.LoadUint8x16Array(&[16]uint8{0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3})
	index1 := archsimd.LoadUint8x16Array(&[16]uint8{4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7})
	index2 := archsimd.LoadUint8x16Array(&[16]uint8{8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11, 8, 9, 10, 11})
	index3 := archsimd.LoadUint8x16Array(&[16]uint8{12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15, 12, 13, 14, 15})
	p := 0
	for ; p+4 <= k; p += 4 {
		v0 := archsimd.LoadFloat32x4Array((*[4]float32)(a0[p : p+4])).ToBits().ReshapeToUint8s()
		v1 := archsimd.LoadFloat32x4Array((*[4]float32)(a1[p : p+4])).ToBits().ReshapeToUint8s()
		wb0 := (*[64]float32)(weights0[p*16 : p*16+64])
		wb1 := (*[64]float32)(weights1[p*16 : p*16+64])
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[0:4]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[4:8]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[8:12]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[12:16]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[0:4]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[4:8]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[8:12]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[12:16]))
			x0 := v0.LookupOrZero(index0).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index0).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[16:20]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[20:24]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[24:28]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[28:32]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[16:20]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[20:24]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[24:28]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[28:32]))
			x0 := v0.LookupOrZero(index1).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index1).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[32:36]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[36:40]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[40:44]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[44:48]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[32:36]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[36:40]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[40:44]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[44:48]))
			x0 := v0.LookupOrZero(index2).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index2).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
		{
			w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[48:52]))
			w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[52:56]))
			w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[56:60]))
			w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[60:64]))
			w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[48:52]))
			w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[52:56]))
			w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[56:60]))
			w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[60:64]))
			x0 := v0.LookupOrZero(index3).ReshapeToUint32s().BitsToFloat32()
			c00 = w0.MulAdd(x0, c00)
			c01 = w1.MulAdd(x0, c01)
			c02 = w2.MulAdd(x0, c02)
			c03 = w3.MulAdd(x0, c03)
			c04 = w4.MulAdd(x0, c04)
			c05 = w5.MulAdd(x0, c05)
			c06 = w6.MulAdd(x0, c06)
			c07 = w7.MulAdd(x0, c07)
			x1 := v1.LookupOrZero(index3).ReshapeToUint32s().BitsToFloat32()
			c10 = w0.MulAdd(x1, c10)
			c11 = w1.MulAdd(x1, c11)
			c12 = w2.MulAdd(x1, c12)
			c13 = w3.MulAdd(x1, c13)
			c14 = w4.MulAdd(x1, c14)
			c15 = w5.MulAdd(x1, c15)
			c16 = w6.MulAdd(x1, c16)
			c17 = w7.MulAdd(x1, c17)
		}
	}
	for ; p < k; p++ {
		wb0 := (*[16]float32)(weights0[p*16 : p*16+16])
		wb1 := (*[16]float32)(weights1[p*16 : p*16+16])
		w0 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[0:4]))
		w1 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[4:8]))
		w2 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[8:12]))
		w3 := archsimd.LoadFloat32x4Array((*[4]float32)(wb0[12:16]))
		w4 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[0:4]))
		w5 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[4:8]))
		w6 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[8:12]))
		w7 := archsimd.LoadFloat32x4Array((*[4]float32)(wb1[12:16]))
		x0 := archsimd.BroadcastFloat32x4(a0[p])
		c00 = w0.MulAdd(x0, c00)
		c01 = w1.MulAdd(x0, c01)
		c02 = w2.MulAdd(x0, c02)
		c03 = w3.MulAdd(x0, c03)
		c04 = w4.MulAdd(x0, c04)
		c05 = w5.MulAdd(x0, c05)
		c06 = w6.MulAdd(x0, c06)
		c07 = w7.MulAdd(x0, c07)
		x1 := archsimd.BroadcastFloat32x4(a1[p])
		c10 = w0.MulAdd(x1, c10)
		c11 = w1.MulAdd(x1, c11)
		c12 = w2.MulAdd(x1, c12)
		c13 = w3.MulAdd(x1, c13)
		c14 = w4.MulAdd(x1, c14)
		c15 = w5.MulAdd(x1, c15)
		c16 = w6.MulAdd(x1, c16)
		c17 = w7.MulAdd(x1, c17)
	}
	_ = d0[31]
	c00.StoreArray((*[4]float32)(d0[0:4]))
	c01.StoreArray((*[4]float32)(d0[4:8]))
	c02.StoreArray((*[4]float32)(d0[8:12]))
	c03.StoreArray((*[4]float32)(d0[12:16]))
	c04.StoreArray((*[4]float32)(d0[16:20]))
	c05.StoreArray((*[4]float32)(d0[20:24]))
	c06.StoreArray((*[4]float32)(d0[24:28]))
	c07.StoreArray((*[4]float32)(d0[28:32]))
	_ = d1[31]
	c10.StoreArray((*[4]float32)(d1[0:4]))
	c11.StoreArray((*[4]float32)(d1[4:8]))
	c12.StoreArray((*[4]float32)(d1[8:12]))
	c13.StoreArray((*[4]float32)(d1[12:16]))
	c14.StoreArray((*[4]float32)(d1[16:20]))
	c15.StoreArray((*[4]float32)(d1[20:24]))
	c16.StoreArray((*[4]float32)(d1[24:28]))
	c17.StoreArray((*[4]float32)(d1[28:32]))
}

func kernel5x16Broadcast(a0,a1,a2,a3,a4,weights,d0,d1,d2,d3,d4 []float32, accumulate bool) {
 k:=len(a0)
a1=a1[:k:k]
a2=a2[:k:k]
a3=a3[:k:k]
a4=a4[:k:k]
weights=weights[:k*4:k*4]
var c00,c01,c02,c03 archsimd.Float32x4
var c10,c11,c12,c13 archsimd.Float32x4
var c20,c21,c22,c23 archsimd.Float32x4
var c30,c31,c32,c33 archsimd.Float32x4
var c40,c41,c42,c43 archsimd.Float32x4
if accumulate {
_ = d0[15]
c00=archsimd.LoadFloat32x4Array((*[4]float32)(d0[0:4]))
c01=archsimd.LoadFloat32x4Array((*[4]float32)(d0[4:8]))
c02=archsimd.LoadFloat32x4Array((*[4]float32)(d0[8:12]))
c03=archsimd.LoadFloat32x4Array((*[4]float32)(d0[12:16]))
_ = d1[15]
c10=archsimd.LoadFloat32x4Array((*[4]float32)(d1[0:4]))
c11=archsimd.LoadFloat32x4Array((*[4]float32)(d1[4:8]))
c12=archsimd.LoadFloat32x4Array((*[4]float32)(d1[8:12]))
c13=archsimd.LoadFloat32x4Array((*[4]float32)(d1[12:16]))
_ = d2[15]
c20=archsimd.LoadFloat32x4Array((*[4]float32)(d2[0:4]))
c21=archsimd.LoadFloat32x4Array((*[4]float32)(d2[4:8]))
c22=archsimd.LoadFloat32x4Array((*[4]float32)(d2[8:12]))
c23=archsimd.LoadFloat32x4Array((*[4]float32)(d2[12:16]))
_ = d3[15]
c30=archsimd.LoadFloat32x4Array((*[4]float32)(d3[0:4]))
c31=archsimd.LoadFloat32x4Array((*[4]float32)(d3[4:8]))
c32=archsimd.LoadFloat32x4Array((*[4]float32)(d3[8:12]))
c33=archsimd.LoadFloat32x4Array((*[4]float32)(d3[12:16]))
_ = d4[15]
c40=archsimd.LoadFloat32x4Array((*[4]float32)(d4[0:4]))
c41=archsimd.LoadFloat32x4Array((*[4]float32)(d4[4:8]))
c42=archsimd.LoadFloat32x4Array((*[4]float32)(d4[8:12]))
c43=archsimd.LoadFloat32x4Array((*[4]float32)(d4[12:16]))
}
for p:=0;p<k;p+=4 {
x0:=archsimd.LoadFloat32x4Array((*[4]float32)(a0[p:p+4]))
x1:=archsimd.LoadFloat32x4Array((*[4]float32)(a1[p:p+4]))
x2:=archsimd.LoadFloat32x4Array((*[4]float32)(a2[p:p+4]))
x3:=archsimd.LoadFloat32x4Array((*[4]float32)(a3[p:p+4]))
x4:=archsimd.LoadFloat32x4Array((*[4]float32)(a4[p:p+4]))
wb:=(*[16]float32)(weights[p*4:p*4+16])
w0:=archsimd.LoadFloat32x4Array((*[4]float32)(wb[0:4]))
c00=w0.MulAdd(x0,c00)
c10=w0.MulAdd(x1,c10)
c20=w0.MulAdd(x2,c20)
c30=w0.MulAdd(x3,c30)
c40=w0.MulAdd(x4,c40)
w1:=archsimd.LoadFloat32x4Array((*[4]float32)(wb[4:8]))
c01=w1.MulAdd(x0,c01)
c11=w1.MulAdd(x1,c11)
c21=w1.MulAdd(x2,c21)
c31=w1.MulAdd(x3,c31)
c41=w1.MulAdd(x4,c41)
w2:=archsimd.LoadFloat32x4Array((*[4]float32)(wb[8:12]))
c02=w2.MulAdd(x0,c02)
c12=w2.MulAdd(x1,c12)
c22=w2.MulAdd(x2,c22)
c32=w2.MulAdd(x3,c32)
c42=w2.MulAdd(x4,c42)
w3:=archsimd.LoadFloat32x4Array((*[4]float32)(wb[12:16]))
c03=w3.MulAdd(x0,c03)
c13=w3.MulAdd(x1,c13)
c23=w3.MulAdd(x2,c23)
c33=w3.MulAdd(x3,c33)
c43=w3.MulAdd(x4,c43)
}
_ = d0[15]
c00.StoreArray((*[4]float32)(d0[0:4]))
c01.StoreArray((*[4]float32)(d0[4:8]))
c02.StoreArray((*[4]float32)(d0[8:12]))
c03.StoreArray((*[4]float32)(d0[12:16]))
_ = d1[15]
c10.StoreArray((*[4]float32)(d1[0:4]))
c11.StoreArray((*[4]float32)(d1[4:8]))
c12.StoreArray((*[4]float32)(d1[8:12]))
c13.StoreArray((*[4]float32)(d1[12:16]))
_ = d2[15]
c20.StoreArray((*[4]float32)(d2[0:4]))
c21.StoreArray((*[4]float32)(d2[4:8]))
c22.StoreArray((*[4]float32)(d2[8:12]))
c23.StoreArray((*[4]float32)(d2[12:16]))
_ = d3[15]
c30.StoreArray((*[4]float32)(d3[0:4]))
c31.StoreArray((*[4]float32)(d3[4:8]))
c32.StoreArray((*[4]float32)(d3[8:12]))
c33.StoreArray((*[4]float32)(d3[12:16]))
_ = d4[15]
c40.StoreArray((*[4]float32)(d4[0:4]))
c41.StoreArray((*[4]float32)(d4[4:8]))
c42.StoreArray((*[4]float32)(d4[8:12]))
c43.StoreArray((*[4]float32)(d4[12:16]))
}
