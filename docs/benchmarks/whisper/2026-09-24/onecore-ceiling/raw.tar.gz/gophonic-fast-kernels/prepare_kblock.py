from pathlib import Path
import json
r=Path('/Users/thesyncim/Documents/ChatGPT/goinfer');d=Path('/private/tmp/gophonic-fast-kernels')
s=(r/'internal/whispergemm/kernel_wide_arm64.go').read_text();candidate=s[s.index('func kernel2x32('):].replace('func kernel2x32(','func kernel2x32Accumulate(',1).replace('d0, d1 []float32) {','d0, d1 []float32, accumulate bool) {',1)
needle='\tindex0 := '
insert='\tif accumulate {\n'
for row in range(2):
 insert+=f'\t\t_ = d{row}[31]\n'
 for col in range(8):insert+=f'\t\tc{row}{col} = archsimd.LoadFloat32x4Array((*[4]float32)(d{row}[{col*4}:{col*4+4}]))\n'
insert+='\t}\n'
candidate=candidate.replace(needle,insert+needle,1)
(d/'kblock-wide.go').write_text(s+candidate)
s=(r/'internal/whispergemm/kernel_arm64.go').read_text().replace('func mulPacked(', 'func mulPackedBaseline(',1)
s+='''
var kBlockExperiment int
func SetKBlockExperiment(block int) {kBlockExperiment=block}
func mulPacked(dst []float32, ds int, a []float32, as int, packed []float32, m,k,n int) {
 if kBlockExperiment==0 || k<1024 || m<16 || n<32 {mulPackedBaseline(dst,ds,a,as,packed,m,k,n);return}
 rows:=m/4*4;c:=0
 for ;c+32<=n;c+=32 {
  w0,w1:=packed[c*k:(c+16)*k],packed[(c+16)*k:(c+32)*k]
  for first:=0;first<k;first+=kBlockExperiment {
   end:=min(first+kBlockExperiment,k);p0,p1:=w0[first*16:end*16],w1[first*16:end*16]
   for row:=0;row<rows;row+=2 {
    kernel2x32Accumulate(a[row*as+first:row*as+end],a[(row+1)*as+first:(row+1)*as+end],p0,p1,dst[row*ds+c:row*ds+c+32],dst[(row+1)*ds+c:(row+1)*ds+c+32],first!=0)
   }
  }
 }
 if c<n {mulPackedBaseline(dst[c:],ds,a,as,packed[c*k:],rows,k,n-c)}
 if rows<m {mulPackedBaseline(dst[rows*ds:],ds,a[rows*as:],as,packed,m-rows,k,n)}
}
'''
(d/'kblock-kernel.go').write_text(s)
s=(d/'experiment_test.go').read_text().replace('TestFastKernelShapes','TestKBlockShapes').replace('TestFastKernelExact','TestKBlockExact').replace('kernelExperimentMode','kBlockExperiment').replace('shapes.json','kblock-shapes.json')
s=s.replace('cycle<16','cycle<18').replace('j<4','j<6').replace('mode:=(j+cycle)%4','mode:=[]int{0,128,256,384,512,768}[(j+cycle)%6]').replace('[]int{1,2,3}','[]int{128,256,384,512,768}')
s=s.replace('{"fast_qk",32,64,608,40},{"fast_pv",32,608,64,40},{"fast_projection",608,384,384,2},{"fast_expand",608,384,1536,1},{"fast_contract",608,1536,384,1},{"fast_conv2",608,1152,384,1},','{"full_qk",32,64,1500,8},{"full_pv",32,1500,64,8},{"full_conv2",1500,1152,384,1},')
(d/'kblock_test.go').write_text(s)
repl={str(r/'internal/whispergemm/kernel_arm64.go'):str(d/'kblock-kernel.go'),str(r/'internal/whispergemm/kernel_wide_arm64.go'):str(d/'kblock-wide.go'),str(r/'internal/whispergemm/kblock_experiment_test.go'):str(d/'kblock_test.go')}
(d/'kblock-overlay.json').write_text(json.dumps({'Replace':repl},indent=2))
