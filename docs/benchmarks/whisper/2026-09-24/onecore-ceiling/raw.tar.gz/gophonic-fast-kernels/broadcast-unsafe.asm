TEXT github.com/GetStream/gophonic/internal/whispergemm.kernel5x16Broadcast(SB) /Users/thesyncim/Documents/ChatGPT/goinfer/internal/whispergemm/kernel_wide_arm64.go
  kernel_wide_arm64.go:194	0x100175a30		f9400b90		MOVD 16(R28), R16								
  kernel_wide_arm64.go:194	0x100175a34		eb3063ff		CMP R16, RSP									
  kernel_wide_arm64.go:194	0x100175a38		540017c9		BLS 190(PC)									
  kernel_wide_arm64.go:194	0x100175a3c		f81e0ffe		MOVD.W R30, -32(RSP)								
  kernel_wide_arm64.go:194	0x100175a40		f81f83fd		MOVD R29, -8(RSP)								
  kernel_wide_arm64.go:194	0x100175a44		d10023fd		SUB $8, RSP, R29								
  kernel_wide_arm64.go:194	0x100175a48		f9005fe0		MOVD R0, 184(RSP)								
  kernel_wide_arm64.go:194	0x100175a4c		f9006be3		MOVD R3, 208(RSP)								
  kernel_wide_arm64.go:194	0x100175a50		f90077e6		MOVD R6, 232(RSP)								
  kernel_wide_arm64.go:194	0x100175a54		f90083e9		MOVD R9, 256(RSP)								
  kernel_wide_arm64.go:194	0x100175a58		f9008fec		MOVD R12, 280(RSP)								
  kernel_wide_arm64.go:196	0x100175a5c		eb05003f		CMP R5, R1									
  kernel_wide_arm64.go:196	0x100175a60		54001648		BHI 178(PC)									
  kernel_wide_arm64.go:197	0x100175a64		eb08003f		CMP R8, R1									
  kernel_wide_arm64.go:197	0x100175a68		540015e8		BHI 175(PC)									
  kernel_wide_arm64.go:198	0x100175a6c		eb0b003f		CMP R11, R1									
  kernel_wide_arm64.go:198	0x100175a70		54001588		BHI 172(PC)									
  kernel_wide_arm64.go:199	0x100175a74		eb0e003f		CMP R14, R1									
  kernel_wide_arm64.go:199	0x100175a78		54001528		BHI 169(PC)									
  kernel_wide_arm64.go:200	0x100175a7c		f9401fe2		MOVD 56(RSP), R2								
  kernel_wide_arm64.go:200	0x100175a80		eb01085f		CMP R1<<2, R2									
  kernel_wide_arm64.go:200	0x100175a84		54001483		BCC 164(PC)									
  kernel_wide_arm64.go:201	0x100175a88		f240043f		TST $3, R1									
  kernel_wide_arm64.go:201	0x100175a8c		540013a1		BNE 157(PC)									
  kernel_wide_arm64.go:202	0x100175a90		4f00e400		VMOVI $0, V0.B16								
  kernel_wide_arm64.go:207	0x100175a94		3600054f		TBZ $0, R15, 42(PC)								
  kernel_wide_arm64.go:208	0x100175a98		f94027e2		MOVD 72(RSP), R2								
  kernel_wide_arm64.go:208	0x100175a9c		f1003c5f		CMP $15, R2									
  kernel_wide_arm64.go:208	0x100175aa0		540012e9		BLS 151(PC)									
  kernel_wide_arm64.go:213	0x100175aa4		f94033e4		MOVD 96(RSP), R4								
  kernel_wide_arm64.go:213	0x100175aa8		f1003c9f		CMP $15, R4									
  kernel_wide_arm64.go:213	0x100175aac		54001269		BLS 147(PC)									
  kernel_wide_arm64.go:218	0x100175ab0		f9403fe5		MOVD 120(RSP), R5								
  kernel_wide_arm64.go:218	0x100175ab4		f1003cbf		CMP $15, R5									
  kernel_wide_arm64.go:218	0x100175ab8		540011e9		BLS 143(PC)									
  kernel_wide_arm64.go:223	0x100175abc		f9404be7		MOVD 144(RSP), R7								
  kernel_wide_arm64.go:223	0x100175ac0		f1003cff		CMP $15, R7									
  kernel_wide_arm64.go:223	0x100175ac4		54001169		BLS 139(PC)									
  kernel_wide_arm64.go:228	0x100175ac8		f94057e8		MOVD 168(RSP), R8								
  kernel_wide_arm64.go:228	0x100175acc		f1003d1f		CMP $15, R8									
  kernel_wide_arm64.go:228	0x100175ad0		540010e9		BLS 135(PC)									
  kernel_wide_arm64.go:209	0x100175ad4		f94023ea		MOVD 64(RSP), R10								
  kernel_wide_arm64.go:209	0x100175ad8		3dc00140		FMOVQ (R10), F0									
  kernel_wide_arm64.go:210	0x100175adc		3dc00541		FMOVQ 16(R10), F1								
  kernel_wide_arm64.go:211	0x100175ae0		3dc00942		FMOVQ 32(R10), F2								
  kernel_wide_arm64.go:212	0x100175ae4		3dc00d43		FMOVQ 48(R10), F3								
  kernel_wide_arm64.go:214	0x100175ae8		f9402feb		MOVD 88(RSP), R11								
  kernel_wide_arm64.go:214	0x100175aec		3dc00164		FMOVQ (R11), F4									
  kernel_wide_arm64.go:215	0x100175af0		3dc00565		FMOVQ 16(R11), F5								
  kernel_wide_arm64.go:216	0x100175af4		3dc00966		FMOVQ 32(R11), F6								
  kernel_wide_arm64.go:217	0x100175af8		3dc00d67		FMOVQ 48(R11), F7								
  kernel_wide_arm64.go:219	0x100175afc		f9403bed		MOVD 112(RSP), R13								
  kernel_wide_arm64.go:219	0x100175b00		3dc001a8		FMOVQ (R13), F8									
  kernel_wide_arm64.go:220	0x100175b04		3dc005a9		FMOVQ 16(R13), F9								
  kernel_wide_arm64.go:221	0x100175b08		3dc009aa		FMOVQ 32(R13), F10								
  kernel_wide_arm64.go:222	0x100175b0c		3dc00dab		FMOVQ 48(R13), F11								
  kernel_wide_arm64.go:224	0x100175b10		f94047ee		MOVD 136(RSP), R14								
  kernel_wide_arm64.go:224	0x100175b14		3dc001cc		FMOVQ (R14), F12								
  kernel_wide_arm64.go:225	0x100175b18		3dc005cd		FMOVQ 16(R14), F13								
  kernel_wide_arm64.go:226	0x100175b1c		3dc009ce		FMOVQ 32(R14), F14								
  kernel_wide_arm64.go:227	0x100175b20		3dc00dcf		FMOVQ 48(R14), F15								
  kernel_wide_arm64.go:229	0x100175b24		f94053ef		MOVD 160(RSP), R15								
  kernel_wide_arm64.go:229	0x100175b28		3dc001f0		FMOVQ (R15), F16								
  kernel_wide_arm64.go:230	0x100175b2c		3dc005f1		FMOVQ 16(R15), F17								
  kernel_wide_arm64.go:231	0x100175b30		3dc009f2		FMOVQ 32(R15), F18								
  kernel_wide_arm64.go:232	0x100175b34		3dc00df3		FMOVQ 48(R15), F19								
  kernel_wide_arm64.go:232	0x100175b38		1400001e		JMP 30(PC)									
  kernel_wide_arm64.go:266	0x100175b3c		f94027e2		MOVD 72(RSP), R2								
  kernel_wide_arm64.go:271	0x100175b40		f94033e4		MOVD 96(RSP), R4								
  kernel_wide_arm64.go:276	0x100175b44		f9403fe5		MOVD 120(RSP), R5								
  kernel_wide_arm64.go:281	0x100175b48		f9404be7		MOVD 144(RSP), R7								
  kernel_wide_arm64.go:286	0x100175b4c		f94057e8		MOVD 168(RSP), R8								
  kernel_wide_arm64.go:267	0x100175b50		f94023ea		MOVD 64(RSP), R10								
  kernel_wide_arm64.go:272	0x100175b54		f9402feb		MOVD 88(RSP), R11								
  kernel_wide_arm64.go:277	0x100175b58		f9403bed		MOVD 112(RSP), R13								
  kernel_wide_arm64.go:282	0x100175b5c		f94047ee		MOVD 136(RSP), R14								
  kernel_wide_arm64.go:287	0x100175b60		f94053ef		MOVD 160(RSP), R15								
  kernel_wide_arm64.go:234	0x100175b64		4ea01c12		VMOV V0.B16, V18.B16								
  kernel_wide_arm64.go:234	0x100175b68		4eb21e51		VMOV V18.B16, V17.B16								
  kernel_wide_arm64.go:234	0x100175b6c		4eb11e30		VMOV V17.B16, V16.B16								
  kernel_wide_arm64.go:234	0x100175b70		4eb01e0f		VMOV V16.B16, V15.B16								
  kernel_wide_arm64.go:234	0x100175b74		4eaf1dee		VMOV V15.B16, V14.B16								
  kernel_wide_arm64.go:234	0x100175b78		4eae1dcd		VMOV V14.B16, V13.B16								
  kernel_wide_arm64.go:234	0x100175b7c		4ead1dac		VMOV V13.B16, V12.B16								
  kernel_wide_arm64.go:234	0x100175b80		4eac1d8b		VMOV V12.B16, V11.B16								
  kernel_wide_arm64.go:234	0x100175b84		4eab1d6a		VMOV V11.B16, V10.B16								
  kernel_wide_arm64.go:234	0x100175b88		4eaa1d49		VMOV V10.B16, V9.B16								
  kernel_wide_arm64.go:234	0x100175b8c		4ea91d28		VMOV V9.B16, V8.B16								
  kernel_wide_arm64.go:234	0x100175b90		4ea81d07		VMOV V8.B16, V7.B16								
  kernel_wide_arm64.go:234	0x100175b94		4ea71ce6		VMOV V7.B16, V6.B16								
  kernel_wide_arm64.go:234	0x100175b98		4ea61cc5		VMOV V6.B16, V5.B16								
  kernel_wide_arm64.go:234	0x100175b9c		4ea51ca4		VMOV V5.B16, V4.B16								
  kernel_wide_arm64.go:234	0x100175ba0		4ea41c83		VMOV V4.B16, V3.B16								
  kernel_wide_arm64.go:234	0x100175ba4		4ea31c62		VMOV V3.B16, V2.B16								
  kernel_wide_arm64.go:234	0x100175ba8		4ea21c41		VMOV V2.B16, V1.B16								
  kernel_wide_arm64.go:234	0x100175bac		4ea11c33		VMOV V1.B16, V19.B16								
  kernel_wide_arm64.go:234	0x100175bb0		aa1f03f0		MOVD ZR, R16									
  kernel_wide_arm64.go:234	0x100175bb4		f94017f1		MOVD 40(RSP), R17								
  kernel_wide_arm64.go:234	0x100175bb8		14000025		JMP 37(PC)									
  kernel_wide_arm64.go:235	0x100175bbc		8b100813		ADD R16<<2, R0, R19								
  kernel_wide_arm64.go:235	0x100175bc0		3dc00274		FMOVQ (R19), F20								
  kernel_wide_arm64.go:236	0x100175bc4		8b100873		ADD R16<<2, R3, R19								
  kernel_wide_arm64.go:236	0x100175bc8		3dc00275		FMOVQ (R19), F21								
  kernel_wide_arm64.go:237	0x100175bcc		8b1008d3		ADD R16<<2, R6, R19								
  kernel_wide_arm64.go:237	0x100175bd0		3dc00276		FMOVQ (R19), F22								
  kernel_wide_arm64.go:238	0x100175bd4		8b100933		ADD R16<<2, R9, R19								
  kernel_wide_arm64.go:238	0x100175bd8		3dc00277		FMOVQ (R19), F23								
  kernel_wide_arm64.go:239	0x100175bdc		8b100993		ADD R16<<2, R12, R19								
  kernel_wide_arm64.go:239	0x100175be0		3dc00278		FMOVQ (R19), F24								
  kernel_wide_arm64.go:240	0x100175be4		8b101233		ADD R16<<4, R17, R19								
  kernel_wide_arm64.go:241	0x100175be8		3dc00279		FMOVQ (R19), F25								
  kernel_wide_arm64.go:247	0x100175bec		3dc0067a		FMOVQ 16(R19), F26								
  kernel_wide_arm64.go:253	0x100175bf0		3dc00a7b		FMOVQ 32(R19), F27								
  kernel_wide_arm64.go:259	0x100175bf4		3dc00e7c		FMOVQ 48(R19), F28								
  kernel_wide_arm64.go:242	0x100175bf8		4e34cf20		VFMLA V20.S4, V25.S4, V0.S4							
  kernel_wide_arm64.go:243	0x100175bfc		4e35cf24		VFMLA V21.S4, V25.S4, V4.S4							
  kernel_wide_arm64.go:244	0x100175c00		4e36cf28		VFMLA V22.S4, V25.S4, V8.S4							
  kernel_wide_arm64.go:245	0x100175c04		4e37cf2c		VFMLA V23.S4, V25.S4, V12.S4							
  kernel_wide_arm64.go:246	0x100175c08		4e38cf30		VFMLA V24.S4, V25.S4, V16.S4							
  kernel_wide_arm64.go:248	0x100175c0c		4e34cf41		VFMLA V20.S4, V26.S4, V1.S4							
  kernel_wide_arm64.go:249	0x100175c10		4e35cf45		VFMLA V21.S4, V26.S4, V5.S4							
  kernel_wide_arm64.go:250	0x100175c14		4e36cf49		VFMLA V22.S4, V26.S4, V9.S4							
  kernel_wide_arm64.go:251	0x100175c18		4e37cf4d		VFMLA V23.S4, V26.S4, V13.S4							
  kernel_wide_arm64.go:252	0x100175c1c		4e38cf51		VFMLA V24.S4, V26.S4, V17.S4							
  kernel_wide_arm64.go:254	0x100175c20		4e34cf62		VFMLA V20.S4, V27.S4, V2.S4							
  kernel_wide_arm64.go:255	0x100175c24		4e35cf66		VFMLA V21.S4, V27.S4, V6.S4							
  kernel_wide_arm64.go:256	0x100175c28		4e36cf6a		VFMLA V22.S4, V27.S4, V10.S4							
  kernel_wide_arm64.go:257	0x100175c2c		4e37cf6e		VFMLA V23.S4, V27.S4, V14.S4							
  kernel_wide_arm64.go:258	0x100175c30		4e38cf72		VFMLA V24.S4, V27.S4, V18.S4							
  kernel_wide_arm64.go:260	0x100175c34		4e34cf83		VFMLA V20.S4, V28.S4, V3.S4							
  kernel_wide_arm64.go:261	0x100175c38		4e35cf87		VFMLA V21.S4, V28.S4, V7.S4							
  kernel_wide_arm64.go:262	0x100175c3c		4e36cf8b		VFMLA V22.S4, V28.S4, V11.S4							
  kernel_wide_arm64.go:263	0x100175c40		4e37cf8f		VFMLA V23.S4, V28.S4, V15.S4							
  kernel_wide_arm64.go:264	0x100175c44		4e38cf93		VFMLA V24.S4, V28.S4, V19.S4							
  kernel_wide_arm64.go:234	0x100175c48		91001210		ADD $4, R16, R16								
  kernel_wide_arm64.go:234	0x100175c4c		eb10003f		CMP R16, R1									
  kernel_wide_arm64.go:234	0x100175c50		54fffb6c		BGT -37(PC)									
  kernel_wide_arm64.go:266	0x100175c54		f1003c5f		CMP $15, R2									
  kernel_wide_arm64.go:266	0x100175c58		54000489		BLS 36(PC)									
  kernel_wide_arm64.go:267	0x100175c5c		3d800140		FMOVQ F0, (R10)									
  kernel_wide_arm64.go:268	0x100175c60		3d800541		FMOVQ F1, 16(R10)								
  kernel_wide_arm64.go:269	0x100175c64		3d800942		FMOVQ F2, 32(R10)								
  kernel_wide_arm64.go:270	0x100175c68		3d800d43		FMOVQ F3, 48(R10)								
  kernel_wide_arm64.go:271	0x100175c6c		f1003c9f		CMP $15, R4									
  kernel_wide_arm64.go:271	0x100175c70		540003a9		BLS 29(PC)									
  kernel_wide_arm64.go:272	0x100175c74		3d800164		FMOVQ F4, (R11)									
  kernel_wide_arm64.go:273	0x100175c78		3d800565		FMOVQ F5, 16(R11)								
  kernel_wide_arm64.go:274	0x100175c7c		3d800966		FMOVQ F6, 32(R11)								
  kernel_wide_arm64.go:275	0x100175c80		3d800d67		FMOVQ F7, 48(R11)								
  kernel_wide_arm64.go:276	0x100175c84		f1003cbf		CMP $15, R5									
  kernel_wide_arm64.go:276	0x100175c88		540002c9		BLS 22(PC)									
  kernel_wide_arm64.go:277	0x100175c8c		3d8001a8		FMOVQ F8, (R13)									
  kernel_wide_arm64.go:278	0x100175c90		3d8005a9		FMOVQ F9, 16(R13)								
  kernel_wide_arm64.go:279	0x100175c94		3d8009aa		FMOVQ F10, 32(R13)								
  kernel_wide_arm64.go:280	0x100175c98		3d800dab		FMOVQ F11, 48(R13)								
  kernel_wide_arm64.go:281	0x100175c9c		f1003cff		CMP $15, R7									
  kernel_wide_arm64.go:281	0x100175ca0		540001e9		BLS 15(PC)									
  kernel_wide_arm64.go:282	0x100175ca4		3d8001cc		FMOVQ F12, (R14)								
  kernel_wide_arm64.go:283	0x100175ca8		3d8005cd		FMOVQ F13, 16(R14)								
  kernel_wide_arm64.go:284	0x100175cac		3d8009ce		FMOVQ F14, 32(R14)								
  kernel_wide_arm64.go:285	0x100175cb0		3d800dcf		FMOVQ F15, 48(R14)								
  kernel_wide_arm64.go:286	0x100175cb4		f1003d1f		CMP $15, R8									
  kernel_wide_arm64.go:286	0x100175cb8		54000109		BLS 8(PC)									
  kernel_wide_arm64.go:287	0x100175cbc		3d8001f0		FMOVQ F16, (R15)								
  kernel_wide_arm64.go:288	0x100175cc0		3d8005f1		FMOVQ F17, 16(R15)								
  kernel_wide_arm64.go:289	0x100175cc4		3d8009f2		FMOVQ F18, 32(R15)								
  kernel_wide_arm64.go:290	0x100175cc8		3d800df3		FMOVQ F19, 48(R15)								
  kernel_wide_arm64.go:291	0x100175ccc		f85f83fd		MOVD -8(RSP), R29								
  kernel_wide_arm64.go:291	0x100175cd0		f84207fe		MOVD.P 32(RSP), R30								
  kernel_wide_arm64.go:291	0x100175cd4		d65f03c0		RET										
  kernel_wide_arm64.go:286	0x100175cd8		97fc3ec2		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:281	0x100175cdc		97fc3ec1		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:276	0x100175ce0		97fc3ec0		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:271	0x100175ce4		97fc3ebf		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:266	0x100175ce8		97fc3ebe		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:228	0x100175cec		97fc3ebd		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:223	0x100175cf0		97fc3ebc		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:218	0x100175cf4		97fc3ebb		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:213	0x100175cf8		97fc3eba		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:208	0x100175cfc		97fc3eb9		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:201	0x100175d00		90000dc0		ADRP 1802240(PC), R0								
  kernel_wide_arm64.go:201	0x100175d04		9121a000		ADD $2152, R0, R0								
  kernel_wide_arm64.go:201	0x100175d08		f0000c21		ADRP 1601536(PC), R1								
  kernel_wide_arm64.go:201	0x100175d0c		91114021		ADD $1104, R1, R1								
  kernel_wide_arm64.go:201	0x100175d10		97fc220c		CALL runtime.gopanic(SB)							
  kernel_wide_arm64.go:200	0x100175d14		d37ef420		LSL $2, R1, R0									
  kernel_wide_arm64.go:200	0x100175d18		97fc3eb2		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:199	0x100175d1c		97fc3eb1		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:198	0x100175d20		97fc3eb0		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:197	0x100175d24		97fc3eaf		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:196	0x100175d28		97fc3eae		CALL runtime.panicBounds(SB)							
  kernel_wide_arm64.go:196	0x100175d2c		d503201f		NOOP										
  kernel_wide_arm64.go:194	0x100175d30		a90987e0		STP (R0, R1), 152(RSP)								
  kernel_wide_arm64.go:194	0x100175d34		a90a8fe2		STP (R2, R3), 168(RSP)								
  kernel_wide_arm64.go:194	0x100175d38		a90b97e4		STP (R4, R5), 184(RSP)								
  kernel_wide_arm64.go:194	0x100175d3c		a90c9fe6		STP (R6, R7), 200(RSP)								
  kernel_wide_arm64.go:194	0x100175d40		a90da7e8		STP (R8, R9), 216(RSP)								
  kernel_wide_arm64.go:194	0x100175d44		a90eafea		STP (R10, R11), 232(RSP)							
  kernel_wide_arm64.go:194	0x100175d48		a90fb7ec		STP (R12, R13), 248(RSP)							
  kernel_wide_arm64.go:194	0x100175d4c		f90087ee		MOVD R14, 264(RSP)								
  kernel_wide_arm64.go:194	0x100175d50		390443ef		MOVB R15, 272(RSP)								
  kernel_wide_arm64.go:194	0x100175d54		aa1e03e3		MOVD R30, R3									
  kernel_wide_arm64.go:194	0x100175d58		97fc365e		CALL runtime.morestack_noctxt.abi0(SB)						
  kernel_wide_arm64.go:194	0x100175d5c		a94987e0		LDP 152(RSP), (R0, R1)								
  kernel_wide_arm64.go:194	0x100175d60		a94a8fe2		LDP 168(RSP), (R2, R3)								
  kernel_wide_arm64.go:194	0x100175d64		a94b97e4		LDP 184(RSP), (R4, R5)								
  kernel_wide_arm64.go:194	0x100175d68		a94c9fe6		LDP 200(RSP), (R6, R7)								
  kernel_wide_arm64.go:194	0x100175d6c		a94da7e8		LDP 216(RSP), (R8, R9)								
  kernel_wide_arm64.go:194	0x100175d70		a94eafea		LDP 232(RSP), (R10, R11)							
  kernel_wide_arm64.go:194	0x100175d74		a94fb7ec		LDP 248(RSP), (R12, R13)							
  kernel_wide_arm64.go:194	0x100175d78		f94087ee		MOVD 264(RSP), R14								
  kernel_wide_arm64.go:194	0x100175d7c		394443ef		MOVBU 272(RSP), R15								
  kernel_wide_arm64.go:194	0x100175d80		17ffff2c		JMP github.com/GetStream/gophonic/internal/whispergemm.kernel5x16Broadcast(SB)	
  kernel_wide_arm64.go:194	0x100175d84		00000000		?										
  kernel_wide_arm64.go:194	0x100175d88		00000000		?										
  kernel_wide_arm64.go:194	0x100175d8c		00000000		?										
