// Copyright 2026 The gophonic authors
// SPDX-License-Identifier: BSD-2-Clause

// CPU-only single-window experiment. Unlike the exact helper, this uses an
// explicit audio context and records the resulting text/tokens without assuming
// that shortening model context preserves the full-context transcript.
#include "whisper.h"
#include <algorithm>
#include <chrono>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

static std::string trim(std::string s) {
    const auto begin = s.find_first_not_of(" \t\r\n");
    const auto end = s.find_last_not_of(" \t\r\n");
    return begin == std::string::npos ? "" : s.substr(begin, end - begin + 1);
}
static void print_json_string(const std::string & s) {
    std::putchar('"');
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') std::printf("\\%c", c);
        else if (c < 32) std::printf("\\u%04x", c);
        else std::putchar(c);
    }
    std::putchar('"');
}
int main(int argc, char ** argv) {
    if (argc != 6) {
        std::fprintf(stderr, "usage: %s model pcm-f32le threads iterations audio-context\n", argv[0]);
        return 2;
    }
    const int threads = std::atoi(argv[3]), iterations = std::atoi(argv[4]), audio_ctx = std::atoi(argv[5]);
    if (threads < 1 || iterations < 1 || audio_ctx < 1 || audio_ctx > 1500) return 2;
    std::ifstream file(argv[2], std::ios::binary);
    std::vector<char> bytes((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    if (bytes.empty() || bytes.size() % sizeof(float) || bytes.size()/sizeof(float) > 480000) return 2;
    std::vector<float> pcm(bytes.size()/sizeof(float));
    std::copy(bytes.begin(), bytes.end(), reinterpret_cast<char *>(pcm.data()));
    if (audio_ctx < std::min(1500, static_cast<int>((pcm.size()+200+319)/320))) {
        std::fprintf(stderr, "audio context would omit input frames\n");
        return 2;
    }
    auto cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    auto * ctx = whisper_init_from_file_with_params(argv[1], cparams);
    if (!ctx) return 2;
    auto params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.n_threads = threads;
    params.audio_ctx = audio_ctx;
    params.language = "en";
    params.no_timestamps = true;
    params.no_context = true;
    params.temperature = 0.0f;
    params.temperature_inc = 0.0f;
    params.greedy.best_of = 1;
    params.beam_search.beam_size = 1;
    params.print_realtime = params.print_progress = params.print_timestamps = params.print_special = false;
    std::string transcript;
    std::vector<int> token_ids;
    std::vector<long long> durations;
    for (int i = -5; i < iterations; ++i) {
        whisper_reset_timings(ctx);
        const std::clock_t cpu_start=std::clock();
        auto start = std::chrono::steady_clock::now();
        const int rc = whisper_full(ctx, params, pcm.data(), static_cast<int>(pcm.size()));
        auto end = std::chrono::steady_clock::now();
        if (rc) return 3;
        if(i>=0) {whisper_print_timings(ctx);std::fprintf(stderr,"PROCESS_CPU_MS %.3f\n",1000.0*(std::clock()-cpu_start)/CLOCKS_PER_SEC);}
        std::string text;
        std::vector<int> tokens;
        for (int segment = 0; segment < whisper_full_n_segments(ctx); ++segment) {
            text += whisper_full_get_segment_text(ctx, segment);
            for (int token = 0; token < whisper_full_n_tokens(ctx, segment); ++token)
                tokens.push_back(whisper_full_get_token_id(ctx, segment, token));
        }
        text = trim(text);
        if (i == -5) { transcript = text; token_ids = tokens; }
        else if (text != transcript || tokens != token_ids) {
            std::fprintf(stderr, "text/tokens changed across warm calls\n");
            return 4;
        }
        if (i >= 0) durations.push_back(std::chrono::duration_cast<std::chrono::nanoseconds>(end-start).count());
    }
    std::printf("{\"audio_context\":%d,\"samples\":%zu,\"warm_calls\":5,\"flash_attention\":%s,\"durations_ns\":[", audio_ctx, pcm.size(), cparams.flash_attn ? "true":"false");
    for (size_t i = 0; i < durations.size(); ++i) std::printf("%s%lld", i ? ",":"", durations[i]);
    std::printf("],\"transcript\":"); print_json_string(transcript);
    std::printf(",\"segment_token_ids\":[");
    for (size_t i = 0; i < token_ids.size(); ++i) std::printf("%s%d", i ? ",":"", token_ids[i]);
    std::printf("],\"text_token_ids\":[");
    bool comma = false;
    for (const int id : token_ids) if (id < whisper_token_eot(ctx)) {
        std::printf("%s%d", comma ? ",":"", id); comma = true;
    }
    std::printf("]}\n");
    whisper_free(ctx);
}
